#!/usr/bin/env node
const program = require('commander');
const request = require('request');
const _ = require('lodash');
const fs = require('fs');
require('colors');
const jsdiff = require('diff');

const urls = {
  prod:'https://api.lb.content-platform.viacom.com/globalentry',
  stg: 'https://stg2.api.lb.content-platform.viacom.com/globalentry',
  uat: 'https://uat1.api.lb.content-platform.viacom.com/globalentry',
  dev: 'https://dev.api.lb.content-platform.viacom.com/globalentry',
  qa: 'https://qa.api.lb.content-platform.viacom.com/globalentry'
};

const types = {
  'fieldSchema': '/api/v1/field/schema',
  'layoutSchema': '/api/v1/layout/schema'
};

function displayDiff(remote, local) {
  diff = jsdiff.diffWords(remote, local);
  diff.forEach(function(part){
     // green for additions, red for deletions
    if(part.added || part.removed) {
       const color = part.added ? 'green' :
       part.removed ? 'red' : 'grey';
       process.stderr.write(part.value[color]);
    }
    else {
      process.stderr.write(part.value);
    }
  });
  console.log();
}


function getAllJSONFiles(dirPath) {
  console.log(dirPath);
  const JSONFiles = [];
  const files = fs.readdirSync(dirPath);
  for (var i=0; i<files.length; i++) {
    const fileContents = fs.readFileSync(dirPath+'/'+files[i], 'utf8');
    JSONFiles.push(JSON.parse(fileContents));
  }
  return JSONFiles;
}

function getJSONFile(filePath) {
  console.log(filePath);
  const JSONFile = [];
  const fileContents = fs.readFileSync(filePath, 'utf8');
  JSONFile.push(JSON.parse(fileContents));
  return JSONFile;
}


function saveLocalFile(serverData, localData, type) {
  const key = program.type === 'fieldSchema' ? 'fieldKey' : 'contentType';
  if (!_.isEqual(serverData[type], localData[type])) {
    if(program.verbose) {
      // new data is server data
      console.log(`${localData[key]} diff (changes in green):`)
      displayDiff(JSON.stringify(localData[type]), JSON.stringify(serverData[type]))
    }
    if(program.dryRun) {
      // Dont do any updates
      console.log("Dry run: skipping updates")
      return Promise.resolve();
    }
    localData[type] = serverData[type];
    fs.writeFileSync(program.path+'/'+localData[key]+".json", JSON.stringify(localData, null, '  '),  'utf8');
    console.log(`Successfully saved ${ serverData[key]} locally from ${program.env}`);
    return Promise.resolve();

  }
  console.log(`${localData[key]} is the same as on ${program.env}`)
  return Promise.resolve();
}


function updateDataIfSame(oldData, newData, type, env, userId) {
  const key = program.type === 'fieldSchema' ? 'fieldKey' : 'contentType';

  if (!_.isEqual(oldData[type], newData[type])) {
    if(program.verbose) {
      console.log(`${newData[key]} diff (changes in green):`)
      // new data is local data
      displayDiff(JSON.stringify(oldData[type]), JSON.stringify(newData[type]))
    }

    if(program.dryRun) {
      // Dont do any updates
      console.log("Dry run: skipping updates")
      return Promise.resolve();
    }

    // update
    oldData[type] = newData[type];
    oldData.updatedBy = userId;
    const options = {
      url: urls[env] + types[type] + '/'+ oldData.id,
      json: true,
      body: oldData,
      timeout: 3000
    };
    return new Promise((Resolve, Reject) => {
      request.put(options, (error, response) => {
        if (error) {
          console.error(`Failed to update ${newData[key]} on ${program.env} with error:`);
          console.error(error);
          Reject(error);
        } else if (response.statusCode >= 400 && response.body && response.body.errorCode) {
          console.error(`Failed to update ${newData[key]} on ${program.env} with error: ${response.body.description}`);
          Resolve();
        } else {
          console.log(`Successfully updated ${ newData[key]} on ${program.env}`);
          Resolve();
        }
      });
    })
  }
  console.log(`${newData[key]} the same on ${program.env}`)
  return Promise.resolve();
}

function createData(data, type, env, userId) {
  const key = program.type === 'fieldSchema' ? 'fieldKey' : 'contentType';
  if (!data[key]) {
    console.error(`${key} does not exist in data`);
    return;
  }
  data.createdBy = userId;
  const options = {
    url: urls[env] + types[type],
    headers: {},
    body: data,
    json: true,
    timeout: 3000
  };
  return new Promise((Resolve, Reject) => {
    request.post(options, (error, response) => {
      if (error) {
        console.error(`Failed to create ${data[key]} on ${program.env} with error:`);
        console.error(error);
        Reject(error);
      } else if (response.statusCode >= 500) {
        console.error(`Failed to create ${data[key]} on ${program.env} with error: ${response.body}`);
        Resolve();
      } else if (response.statusCode >= 400 && response.body && response.body.errorCode) {
        console.error(`Failed to create ${data[key]} on ${program.env} with error: ${response.body.description}`);
        Resolve();
      } else {
        console.log(response.statusCode);
        console.log(`Successfully created ${ data[key]} on ${program.env}`);
        Resolve();
      }
    });
  })
}

function getData(data, type, env) {
  const key = program.type === 'fieldSchema' ? 'fieldKey' : 'contentType';
  if (!data[key]) {
    console.error(`${key} does not exist in data`);
    return;
  }
  const options = {
    url: urls[env] + types[type],
    qs: {[key]: data[key]},
    json: true,
    timeout: 3000
  };
  return new Promise((Resolve, Reject) => {
    request.get(options, (error, response) => {
      if (response.statusCode === 404) {
        Resolve();
      } else if (error) {
        console.error(`Failed to get ${data[key]} on ${program.env} with error:`);
        console.error(error);
        Reject(error);
      } else if (response.statusCode >= 300) {
        console.error(`Failed to get ${data[key]} on ${program.env} with error:`);
        console.error(response.body);
        Reject(error);
      } else {
        Resolve(response.body);
      }
    });
  })
}

function createOrUpdateAllData(jsonData, index = 0) {
  if (jsonData.length > 0 && jsonData[index]) {
    getData(jsonData[index], program.type, program.env).then((body) => {
      if (!body || body.length === 0) {
        // doesn't exist
        createData(jsonData[index], program.type, program.env, program.userId)
          .then(() => {
            createOrUpdateAllData(jsonData, ++index);
          })
          .catch(_error => {});
      } else {
        // exists
        updateDataIfSame(body[0], jsonData[index], program.type, program.env, program.userId)
          .then(() => {
            createOrUpdateAllData(jsonData, ++index);
          })
          .catch(_error => { });
      }
    })
    .catch(error => console.log(error));
  }
}

function updateAllLocalData(jsonData, index = 0) {
  if (jsonData.length > 0 && jsonData[index]) {
    getData(jsonData[index], program.type, program.env).then((body) => {
      if (!body || body.length === 0) {
        // doesn't exist
        console.warn(`Unable to get ${jsonData[index]} from server`)
        updateAllLocalData(jsonData, ++index);

      } else {
        // exists
        saveLocalFile(body[0], jsonData[index], program.type, program.env, program.userId)
          .then(() => {
            updateAllLocalData(jsonData, ++index);
          })
          .catch(_error => { });
      }
    })
    .catch(error => console.log(error));
  }
}

program
  .version('1.1.0')
  .option('-t, --type <type>', 'Data Type')
  .option('-p, --path <pathOfFolder>', 'Path Of Folder of local data')
  .option('-u, --userId <userId>', 'User Id')
  .option('-e, --env <env>', 'Environment')
  .option('-v, --verbose', 'Verbose: display diff')
  .option('-d, --dryRun', 'Dry run - dont update')
  .option('-f, --fetch', 'Download data from server and save it locally')
  .option('-s, --single', 'Specified path is for a single file')


program.on('--help', function(){
  console.log('')
  console.log('Examples:');
  console.log('  $ node ./scripts/create-form-data.js -p ./data/reggie-dynamic-form-data/layout-schemas --userId <userId> -e prod' +
    ' -t layoutSchema');
  console.log('  $ node ./scripts/create-form-data.js -p ./data/reggie-dynamic-form-data/layout-schemas/<layout-schema-file-name> -s --userId <userId> -e prod' +
    ' -t layoutSchema');
});

program.parse(process.argv);

if (!program.type || !types[program.type]) {
  console.error('Please set the type to: ' + Object.keys(types).join(', '));
  process.exit(1);
}
const argTypes = ['path', 'userId', 'env']
for (const argType of argTypes) {
  if (!program[argType]) {
    console.error(argType + ' is missing');
    process.exit(1);
  }
}

const jsonData = (program.single) ? getJSONFile(program.path) : getAllJSONFiles(program.path);
if (jsonData.length === 0) {
  const error = (program.single) ? 'No JSON file with that name' : 'No JSON files in directory';
  console.error(error);
  process.exit(1);
}
if(program.fetch) {
  updateAllLocalData(jsonData);
}
else {
  createOrUpdateAllData(jsonData);
}
