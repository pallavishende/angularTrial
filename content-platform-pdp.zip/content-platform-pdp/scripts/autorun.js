#!/usr/bin/env node

const {
  spawn
} = require('child_process');
const program = require('commander');

program
  .version('1.1.0')
  .usage('[options]')
  .option('-a, --app <app>', '<Deprecated> App to Run')
  .option('-p, --project <appname>', 'App to Run')
  .option('-e, --env <env>', 'Environment; Default: dev')
  .option('--username <username>', '<Optional> Username to login with')
  .option('--password <password>', '<Optional> Password for username')
  .parse(process.argv);

const env = program.env || process.env.ENV || 'dev';
const app = program.project ||  program.app || process.env.FRONTEND_APP;

let options = ['serve', `--host`, `0.0.0.0`, `--project=${app}`];
if (env !== 'dev' && env !== 'prod') {
  options = options.concat([`--configuration=${env}`]);
} else if (env === 'prod') {
  options = options.concat(['--prod']);
}

spawn('yarn ng', options, {
  shell: true,
  stdio: 'inherit'
});
