#!/usr/bin/env node

const { spawn, fork } = require('child_process');
const program = require('commander');
const fs = require('fs');

program
  .version('1.0.0')
  .option('-a, -app <app> ', 'App to Run')
  .option('-e, --env <env> ', 'Environment; Default: e2e')
  .parseOptions(process.argv);

const env = program.env || process.env.ENV || 'e2e';
const app = program.App || process.env.FRONTEND_APP;
let url;

const ng = spawn('yarn ng', ['serve', ' -H', '0.0.0.0', `--app=${app}`, `--env=${env}`, ' > ./target/ngLogs.txt'], { shell: true, stdio: 'inherit', detached: true });

waitForFile().then(path => {
  return new Promise((resolve, reject) => {
    fs.watchFile(path, (curr, prev) => {
      fs.createReadStream(path, {
        start: prev.size,
        end: curr.size
      }).on('data', data => {
        const dataStr = data.toString();
        console.log(dataStr);
        if (dataStr.includes('** NG Live Development Server is listening on')) {
          url = dataStr.match('http://.+/')[0];
        }
        if (data.toString().includes('Compiled')) {
          resolve();
        }
      });
    });
  });
}).then(() => {
  return new Promise((resolve, reject) => {
    fork('./scripts/jasmine.conf.js', [app, url]).on('exit', () => {
      resolve();
    });
  })
}).then(() => {
  fs.unlinkSync('./target/ngLogs.txt');
  process.exit();
});

process.on('exit', (code) => {
  console.log(`About to exit with code: ${code}`);
  process.kill(-ng.pid);
});

function waitForFile(path = './target/ngLogs.txt', timeout = 5000) {
  return new Promise((resolve, reject) => {
    const timeoutTimerId = setTimeout(handleTimeout, timeout);
    const interval = timeout / 6;
    let intervalTimerId;

    function handleTimeout() {
      clearTimeout(timerId);

      const error = new Error('path check timed out');
      error.name = 'PATH_CHECK_TIMED_OUT';
      reject(error);
    }

    function handleInterval() {
      fs.access(path, (err) => {
        if (err) {
          intervalTimerId = setTimeout(handleInterval, interval);
        } else {
          clearTimeout(timeoutTimerId)
          resolve(path);
        }
      })
    }

    intervalTimerId = setTimeout(handleInterval, interval);
  });
}
