#!/usr/bin/env node
const CoreManagerHelper = require('../libs/e2e-test-helpers/src/lib/core-manager').CoreManagerHelper;
const ConsoleReporters = require('../libs/e2e-test-helpers/src/lib/jasmine/reporters/console-reporters');
const Jasmine = require('jasmine');
const jasmine = new Jasmine();
const programm = require('commander');
const AllureReporter = require('jasmine-allure-reporter');
const { report } = require('@viacom/mqe-core-js');
const fs = require('fs');
const path = require('path');

programm
  .option('-a, --appName <appName>', 'Application name')
  .option('-u, --baseUrl <baseUrl>', 'Base URL')
  .option('-s, --singleApp', 'Is single application')
  .option('-b, --browser <browser>', 'Browser') // chrome, firefox, ie, safari, MicrosoftEdge
  .option('-o, --operatingSystem <operatingSystem>', 'Operating system') // MAC, WINDOWS
  .option('-l, --login <login>', 'User email')
  .option('-p, --password <password>', 'User password')
  .option('-t, --testCases <testCases>', 'Test cases') // first part of the file name
  .parse(process.argv);

const specConf = {
  spec_dir: `**/apps/${programm.appName ? programm.appName : '**'}-e2e`,
  spec_files: [
    `**/${programm.testCases ? programm.testCases : '*'}.e2e-spec.ts`
  ],
  stopSpecOnExpectationFailure: false,
  random: false
};

global.singleApp = programm.singleApp;
global.baseUrl = programm.baseUrl;
global.appName = programm.appName;
global.browser = programm.browser;
global.platform = programm.operatingSystem;
global.REPORT_DIR = path.join(__dirname, '../allure-results');

jasmine.env.clearReporters();
jasmine.addReporter(ConsoleReporters.SPEC_REPORTER);
jasmine.addReporter(ConsoleReporters.CUSTOM_REPORTER);

(async function () {
  await report.GlobalReportDir.setReportDir(global.REPORT_DIR);
}());

jasmine.addReporter(new AllureReporter({
  resultsDir: global.REPORT_DIR
}));

jasmine.env.afterEach(async function(){
  const browser = CoreManagerHelper.getBrowser();
  await browser.getScreenshot().then(function (png) {
    console.log('Screenshot name: ' + png);
    allure.createAttachment('Screenshot', fs.readFileSync(png), 'image/png');
  });
});

jasmine.env.afterEach(async function(){
  const browser = CoreManagerHelper.getBrowser();
  await browser.getScreenRecording().then(function (screenRecording) {
    console.log('ScreenRecording name: ' + screenRecording)
    allure.createAttachment(
      'screenRecording',
      fs.readFileSync(screenRecording),
      'video/mp4'
    );
  });
});

jasmine.env.afterEach(async function(){
  const browser = CoreManagerHelper.getBrowser();
  await browser.getWebDriverLogs().then(function (webDriverLogs) {
    console.log('WebdriverLog name: ' + webDriverLogs)
    allure.createAttachment(
      'WebdriverLogs',
      fs.readFileSync(webDriverLogs),
      'text/plain'
    );
  });
});

global.allure = allure;

jasmine.addHelperFiles([
  '**/e2e-test-helpers/src/lib/jasmine/helpers/*.ts'
]);
jasmine.loadHelpers();
jasmine.loadConfig(specConf);
jasmine.onComplete(async () => {
  //  All commented methods are needed for debugging only.
  // fs.readdir(global.REPORT_DIR + "/..", (err, files) => {
  //   files.forEach(file => {
  //     console.log(file);
  //   });
  // });
  // console.log(__dirname);
  // console.log(await report.GlobalReportDir.getReportDir());
  if (!!process.env.EC2_SUBNET) {
    console.log(`Generating reports`)
    await report.AllureManager.generateReport();
    const reportUrl = await report.UploadManager.uploadReportToS3();
    if (!reportUrl || reportUrl === 'Unknown') {
      console.log(`Local execution, report wasn't uploaded`)
    } else {
      console.log(`Url of uploaded report: ${reportUrl}`)
    }
  }
  console.log(`Stop driver`)
  await CoreManagerHelper.stopDriver();
});

const caps = Object.assign({}, CoreManagerHelper.DEFAULT_CAPS);
if (global.browser) caps.MQEDesktopBrowserName = global.browser;
if (global.browser === 'ie') caps.MQEDesktopBrowserName = "internet explorer";
if (global.platform) caps.MQEDesktopOSPlatform = global.platform;

if (programm.login && programm.password) {
  CoreManagerHelper.initiateDriver(caps, programm.login, programm.password).then(() => {
    jasmine.execute();
  });
} else {
  CoreManagerHelper.initiateDriver(caps).then(() => {
    jasmine.execute();
  });
}
