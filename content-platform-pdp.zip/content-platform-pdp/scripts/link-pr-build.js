#!/usr/bin/env node
const { spawn } = require('child_process');
const program = require('commander');
const request = require('request');

program
  .version('1.0.0')
  .usage('<pr> [options]')
  .option('-p, --projectKey <projectKey>', 'Project Key')
  .option('-r, --repositorySlug <repositorySlug>', 'Repository Slug')
  .option('-a, --auth <auth>', 'Encoded auth string')
  .parse(process.argv);

if (program.args.length !== 1) {
  console.error('Invalid arguments');
  process.exit(1);
}
const pr = program.args.shift();

if (!program.projectKey) {
  console.error('Project Key is missing');
  process.exit(1);
}
if (!program.repositorySlug) {
  console.error('Repository Slug is missing');
  process.exit(1);
}
if (!program.auth) {
  console.error('Encoded auth string missing');
  process.exit(1);
}
const postMessage = {
  text: `A new build has started for #${pr}.\n\nFind current and past progress here: \nhttps://bamboo.vmn.io/browse/label/pr-${pr}\n\nIf successful, you will find the deployed build here: https://${pr}.qa.contentplatform.viacom.com/`
};
const options = {
  url: `https://stash.mtvi.com/rest/api/1.0/projects/${program.projectKey}/repos/${program.repositorySlug}/pull-requests/${pr}/comments`,
  headers: {
    'Authorization': `Basic ${program.auth}`
  },
  body: postMessage,
  json: true
};
request.post(options, (error) => {
  if (error) {
    console.error(error);
    process.exit(1);
  }
  process.exit(0);
});
