#!/usr/bin/env node

const ngCLI = require('../angular.json');
const { spawn, execSync } = require('child_process');
const program = require('commander');
const async = require('async');
const nxShared = require('@nrwl/schematics/src/command-line/shared');

function buildApp(app, env, baseHrefPrefix) {
  return new Promise((Resolve, Reject) => {
    const appDir = app.architect.build.options.outputPath.replace('dist', '').concat('/').replace('//', '/');
    const baseHREF = `${baseHrefPrefix ? '/' + baseHrefPrefix : ''}${appDir}`;
    let options = ['build', '--aot', '--build-optimizer', `--project=${app.name}`, '--delete-output-path=false', `--base-href=${baseHREF}`, '--output-hashing=all', '--progress=false'];
    if (env === 'dev' || env === 'qa') {
      options = options.concat(['--extractCss', '--source-map']);
    } else  {
      options = options.concat(['--prod']);
    }
    const build = spawn('yarn ng-high-memory', options, { shell: true, stdio: 'inherit' });
    build.on('exit', (code) => {
      if (code !== 0) {
        Reject(`Error building ${app.name} Code: ${code}`);
      }
      Resolve();
    })
  })
}

function triggerBuild(apps) {
  if (concurrent === 'off' || !!!concurrent) {
    async.mapSeries(apps, async app => await buildApp(app, env, baseHrefPrefix), handleDone);
  } else {
    async.map(apps, app => buildApp(app, env, baseHrefPrefix), handleDone);
  }
}

function handleDone(error, results) {
  if (error) {
    console.error(error);
    process.exit(1);
    return Promise.reject();
  }
  if (results.some(i => typeof i === 'string')) {
    console.error('Error during compile');
    process.exit(1);
    return Promise.reject();
  }
  process.exit(0);
  return Promise.resolve();
}

program
  .version('1.3.0')
  .usage('[options]')
  .option('-e, --env <env>', 'Environment; Default: dev')
  .option('-af, --affected', 'Build affected: Default: false')
  .option('-c, --concurrent', 'For speedy builds, use locally only; Default: off')
  .option('-a, --app <appname>', '<Deprecated> Only build a single app leave blank to build everything; Default: <empty>')
  .option('-p, --project <appname>', 'Only build a single app leave blank to build everything; Default: <empty>')
  .option('-b, --base <base>', 'base git branch to compare changes to; Default: next')
  .option('-h, --head <head>', 'Git branch head; Default: HEAD')
  .option('--base-href-prefix <baseHrefPrefix>', 'baseHREF Prefix')
  .parse(process.argv);

const env = program.env || 'dev';
const base = program.base || 'next';
const head = program.head || 'HEAD';
const buildAffected = program.affected || false;
const baseHrefPrefix = program.baseHrefPrefix || false;
const concurrent = program.concurrent || false;
const singleApp = program.project || program.app;
const apps = Object.entries(ngCLI.projects).filter(([key, project]) => {
    return !project.architect.build ?
      false :
      project.architect.build.options.main.startsWith('apps') ?
      true :
      false;
  })
  .filter(([key, project]) => {
    if (env !== 'dev') {
      const configuration = env === 'prod' ? 'production' : env;
      return !!project.architect.serve.configurations[configuration]
    }
    return true;
  })
  .filter(([key, project]) => {
    return !singleApp || key === singleApp
  })
  .map(([key, project]) => {
    return {...project, name: key };
  });

  if(buildAffected) {
    const affectedApps = nxShared.getAffectedApps(nxShared.parseFiles({base: base, head: head}).files);
    if(affectedApps.length > 0) {
      console.log(`Building affected apps : ${affectedApps}`);
      const filteredApps = apps.filter(r => affectedApps.includes(r.name));
      triggerBuild(filteredApps);
    }
    else {
      console.log('There are no affected apps');
    }
  }
  else {
    triggerBuild(apps);
  }
