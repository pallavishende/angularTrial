#!/usr/bin/env node
const { spawn } = require('child_process');
const program = require('commander');
const request = require('request');

function setBuildStatus(sha, auth, body) {
  const options = {
    url: `https://stash.mtvi.com/rest/build-status/1.0/commits/${sha}`,
    headers: {
      'Authorization': `Basic ${auth}`
    },
    body,
    json: true
  }
  return new Promise((Resolve, Reject) => {
    request.post(options, (error, response) => {
      if (error) {
        Reject(error);
      }
      Resolve();
    });
  })
}

function getBuildStatus(buildKey, auth) {
  const options = {
    url: `https://bamboo.vmn.io/rest/api/latest/result/${buildKey}`,
    headers: {
      'Authorization': `Basic ${auth}`
    },
    json: true
  }
  return new Promise((Resolve, Reject) => {
    request.get(options, (error, { body, ...response }) => {
      if (error) {
        Reject(error);
      }
      Resolve(body);
    });
  })
}

program
  .version('1.0.0')
  .usage('[status] INPROGRESS|FAILED|SUCCESSFUL [options]')
  .option('-s, --sha <sha>', 'Commit SHA to report to')
  .option('-p, --planName <planName>', 'Plan Name')
  .option('-b, --buildNum <buildNum>', 'Build number')
  .option('-a, --auth <auth>', 'Encoded auth string')
  .parse(process.argv);

if (program.args.length > 1) {
  console.error('Invalid arguments');
  process.exit(1);
}
const status = program.args.shift();

if (!program.sha) {
  console.error('Commit SHA missing');
  process.exit(1);
}
if (!program.planName) {
  console.error('Plan Name missing');
  process.exit(1);
}
if (!program.buildNum) {
  console.error('Build ID missing');
  process.exit(1);
}
if (!program.auth) {
  console.error('Encoded auth string missing');
  process.exit(1);
}

const buildKey = `${program.planName.toUpperCase()}-${program.buildNum}`;
if (!!status) {
  const postMessage = {
    state: status.toUpperCase(),
    key: program.planName.toUpperCase(),
    name: buildKey,
    url: `https://bamboo.vmn.io/browse/${program.planName.toUpperCase()}-${program.buildNum}`
  }
  setBuildStatus(program.sha, program.auth, postMessage)
    .then(() => {
      process.exit(0)
    })
    .catch(error => {
      console.error(error)
      process.exit(1);
    })
} else {
  getBuildStatus(buildKey, program.auth)
    .then(({ buildState, ...response }) => {
      console.log('Auto reporting status:', buildState);
      const postMessage = {
        state: buildState.toUpperCase(),
        key: program.planName.toUpperCase(),
        name: buildKey,
        url: `https://bamboo.vmn.io/browse/${program.planName.toUpperCase()}-${program.buildNum}`
      }
      return setBuildStatus(program.sha, program.auth, postMessage);
    })
    .then(() => process.exit(0))
    .catch(error => {
      console.error(error);
      process.exit(1);
    })
}
