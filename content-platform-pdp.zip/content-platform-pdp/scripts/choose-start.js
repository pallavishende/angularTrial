#!/usr/bin/env node
const ngCLI = require('../.angular-cli.json');
const { spawn } = require('child_process');
const program = require('commander');
const co = require('co');
const prompt = require('co-prompt');

program
  .version('1.0.0')
  .parse(process.argv);

const apps = ngCLI.apps.filter(app => !!app.index);
const appNames = apps.map(app => app.name).join(', ');
co(function* () {
  console.log('Available apps: ', appNames)
  const app = yield prompt('Choose app: ');
  spawn('yarn ng', ['serve', ' -H', '0.0.0.0', `--app=${app}`], { shell: true, stdio: 'inherit' });
});
