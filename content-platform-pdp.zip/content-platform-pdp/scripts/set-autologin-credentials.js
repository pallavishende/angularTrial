#!/usr/bin/env node
const program = require('commander');
const co = require('co');
const request = require('request-promise');
const fs = require('fs');

program
  .version('1.0.0')
  .usage('[options]')
  .option('-e, --env <env>', 'Environment; Default: e2e')
  .option('--username <username>', 'Username to login with')
  .option('--password <password>', 'Password for username')
  .parse(process.argv);

/**
 * Create POST request for the login.windows.net to get the auth tokens using the users credentials.
 *
 * @returns promise from the request-promise library.
 */
function createAuthTokenRequest(username, password, resource) {
  const env = program.env || process.env.ENV || 'e2e';
  const envFileName = env === 'dev' ? 'environment' : `environment.${env}`;
  const globalEnvironment = fs.readFileSync(`./environments/${envFileName}.ts`).toString();
  const clientMatches = globalEnvironment.match(/clientId: '(.*)'/);
  const clientSecretMatches = globalEnvironment.match(/appClientSecret: '(.*)'/);
  if (clientMatches.length > 1 && clientSecretMatches.length > 1) {
    const clientId = clientMatches[1];
    const clientSecretId = clientSecretMatches[1];
    resource = resource || clientId;
  
    const options = {
      method: 'POST',
      url: 'https://login.windows.net/viacom.onmicrosoft.com/oauth2/token',
      headers: 
       {
         'Cache-Control': 'no-cache',
         'content-type': 'multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW' },
      formData: 
       { grant_type: 'password',
         client_id: clientId,
         username: username,
         password: password,
         resource: resource,
         client_secret: clientSecretId 
        },
        transform: function (body) {
          return JSON.parse(body);
        }
      };

      return request(options);
    }
}

co(function* () {
  const username = program.username || process.env.USERNAME;
  const password = program.password || process.env.PASSWORD;
  
  if (username && password) {
    const request_data = yield [ createAuthTokenRequest(username, password), createAuthTokenRequest(username, password, 'https://graph.windows.net/')];
    if (request_data[0].access_token) {
      if (!fs.existsSync('./qa-data')){
        fs.mkdirSync('./qa-data');
      }
      const data = {
        token: {
          'c7ffc668-076c-465a-bd66-5d478a61fee3': request_data[0].access_token,
          'https://graph.windows.net/': request_data[1].access_token
        }
      };
      fs.writeFileSync('./qa-data/azure-token.json', JSON.stringify(data), 'utf8');
    }
  }
});
