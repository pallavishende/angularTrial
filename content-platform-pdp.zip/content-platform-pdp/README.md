# Developer guide: getting your environment set up

## Prerequisites
* [docker](https://docs.docker.com/engine/installation/#desktop)
* [docker-compose](https://docs.docker.com/compose/install/)
* [node](https://nodejs.org/en/download/package-manager/)
* [yarn](https://yarnpkg.com/en/docs/install)

## Table of Contents
* [Installation](#installation)
* [Docker Usage](#docker-usage)

## Installation
BEFORE YOU INSTALL: please read the [prerequisites](#prerequisites)

Create `.env` file:
```
## Local Environment Vars
FRONTEND_APP=content-view ## <-- set this to the front-end application you wish to develop for
ENV=dev
```
"content-view" should be replaced with one of the following depending on what app you are working on:
- administration
- global-entry
- home
- arc-config

MacOS/Windows:
```bash
$ yarn install
$ yarn docker:fresh
```

## Docker Usage

MacOS/Windows:
```bash
$ yarn docker:start
$ yarn docker:stop
```


## Package updates

Use this command if you change a dependency version number in package.json
`yarn install:fresh`

Otherwise, you would use `yarn add <package-name>` for new packages

Then use `yarn docker:fresh` for a reinstall on the docker image

and `yarn remove` if it doesn’t work out


For continued help, please visit us in the [Content Platform](https://vmndigital.hipchat.com/chat/room/4339342) hipchat, or get more documentation on our [Confluence](https://confluence.mtvi.com/display/TCP/Local+Development+Environment) page.

## generating new apps, libraries or components
To generate a new app:
```
$ yarn g app <app name>
```
To generate a new library:
```
$ yarn g lib <lib name> --tags=<tags>
```
To generate a lib inside of an existing lib
```
yarn g lib <new-child-lib> --tags=ui --directory=<parent-lib-name>
```

For the above you can use any of the angular [cli options](https://github.com/angular/angular-cli/wiki/generate-library).

To generate a new component (this format can also be used for generating any of the other files within a app).
```
$ ng g component <component name> --project=<app or lib name> --styleext=scss
```

To generate a new component inside of another compoents folder (and the dry-run flag to not actually make the changes but to just see what will be affected)
```
ng g component /parent-folder/<new component> --project=<project> --styleext=scss --dry-run
```

When you generate a new library the following files are added automatically:
```
jest.config
src/test-setup.ts
tsconfig.lib.json
tsconfig.spec.json
tslint.json
```

## Commiting process
- Pull from `next` branch, and cut your feature branch from there
- When making a Pull Request, checkout next, and `git pull origin next`
- Point PR from your project (admin, global entry, etc), to content-platform-primary/next (your project/branch points to primary's next branch in PRs)
- Then checkout your feature branch and `git rebase next`
- Then if it's successful git push origin your_branch --force-with-lease

## unit tests
To run a single library or app:
```
$ ng test <app/lib name>
```
To run all of the library and apps:
```
yarn affected:test --all --pass-with-no-tests
```
or
```
yarn test:ci
```

## e2e tests
Steps to run e2e tests:
1. Install and run [mqe-core-server](https://stash.mtvi.com/projects/DTE/repos/mqe-core-server/browse).
2. Install dependencies in `content-platform-global-entry` using:
```
$ yarn install 
```
3. To run tests use command in terminal: 
```
$ yarn jasmine -u <baseUrl> -a <appName> -s -b <browser> -p <platform>
```
The command line has the following parameters:
* -u - the entry point for the e2e tests. For example, if you want to run tests for TCP on UAT environment, use parameter `-u https://uat.contentplatform.viacom.com`
* -a - optional parameter that defines what application suite of tests we need to execute. In `content-platform-global-entry` this parameter is set to `-a global-entry`
* -s - optional boolean. If it's present it means that `-u` is already pointed to the particular application in the TCP set of applications. 
* -b - optional parameter to specify the browser for tests running. Possible options: chrome, firefox, safari, ie, MicrosoftEdge. Uses chrome by default.
* -p - optional parameter to specify the platform for tests running. Possible options: MAC, WINDOWS. Uses WINDOWS by default.

Examples:
```
$ yarn jasmine --u https://uat.contentplatform.viacom.com -a global-entry ## All e2e suites for Global Entry application in UAT environment using Chrome on Windows
$ yarn jasmine -u https://uat.contentplatform.viacom.com --a global-entry -b safari -p MAC ## For browser and platform specification
$ yarn jasmine -u https://uat.contentplatform.viacom.com/global-entry -a global-entry -s ## If application was already written in URL
```
4. In configuration file `jasmine.conf.js` you can set the folders or file names of test specs to run. It can be done in `specConf` object, e.g.:
```
const specConf = {
  spec_dir: `**/apps/global-entry-e2e/src/specs`,
  spec_files: [
    "**/*.e2e-spec.ts"
  ]
};
```
Working forders for E2E testing configuration are `apps/${app name}-e2e` and `libs/e2e-test-helpers`. The first is used for tests and utils for particular application. E2E test helpers are for general utils, that can be used for all applications, for example FTP listener helper or API helper.

All other apps and tests are contained in [content-platform-primary](https://stash.mtvi.com/projects/VCP/repos/content-platform-primary/browse), so the current version of the apps suite is presented in the 'next' branch of this project. All the changes made in tests need to be merged as pull requests to this branch.
E2E tests use [Jasmine](https://jasmine.github.io/) and [mqe-core-js](https://stash.mtvi.com/projects/DTE/repos/mqe-core-js/browse) API. The following is the basic example of E2E test (opening the Google page and checking the logo presence):
```
describe('Google test', () => {
  let googleLogo: WebInteract;

  beforeAll(async () => {
    await CoreManagerHelper.initiateDriver(); // start browser session
    googleLogo = new WebInteractExt(
        LocType.XPATH, // type of element locator on the web page. Can be xpath or css
        ".//img[@alt='Google']", // xpath locator of the google logo on the page
        "Google logo" // Short name for locator. Used in tests logs
    );
  });

  afterAll(async () => {
    await CoreManagerHelper.stopDriver(); // end browser session
  });

  it('should contain the logo when opening the page', async () => {
    await new WebInteractExt(null, null, null).openUrl("http://google.com").execute(); // Opens URL in current browser session 
    expect(await googleLogo.isPresented(3)).toBeTruthy( // Checks that google logo is currently on the page with 3 seconds time-out
        "Google logo is not presented" // Error message if failed
    ) 
  });
```
The whole set of actions with web interacts is specified in `web-interact.ts`. Web elements are set in the Page Object folders for every application. 
## Viewing Test Results

Install [Http Server][1] globally: `npm install http-server -g`

From the root of `content-platform-home`, run the following:
`http-server -c-1 -o -p 9875 ./coverage`

The `-c-1` disables caching, the `-o` opens a browser window after starting
the server, the `-p` is the port and will default to 8080 if not specified)

You can then drill into the `/apps` or `/libs` directories to view the code
coverage test results


[1]: https://www.npmjs.com/package/http-server

## Content Platform Technologies*

### Front End:

- Angular - https://angular.io/
- Angular Material - https://material.angular.io/
- NgRX - https://github.com/ngrx/platform
- Nrwl NX - https://nrwl.io/nx/
- Yarn - https://yarnpkg.com/en/
- Docker - https://www.docker.com/
- Jasmine - https://jasmine.github.io/
- Jest - https://jestjs.io/
- TsLint - https://github.com/palantir/tslint
- Prettier - https://github.com/prettier/prettier

### Back End:

- Java Spring - https://spring.io/
- JHipster - https://www.jhipster.tech/
- Liquibase - https://www.liquibase.org/
- PostgreSQL
- DynamoDB

### Auth:
- Adal - https://docs.microsoft.com/en-us/azure/active-directory/develop/active-directory-authentication-libraries
- Azure Graph - https://docs.microsoft.com/en-us/azure/active-directory/develop/active-directory-graph-api
