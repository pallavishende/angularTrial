import { Tree, SchematicContext } from '@angular-devkit/schematics';
import { getProjectConfig, offsetFromRoot } from './utils';

export function updateJestConfig(options) {
  return (host: Tree, _context: SchematicContext) => {
    const project = getProjectConfig(host, options.name);
    const projectRoot = project.root.replace(/\/$/, '');
    const offset = offsetFromRoot(projectRoot);
    host.overwrite(
      `${options.projectRoot}/jest.config.js`,
      `
        module.exports = {
          name: '${options.name}',
          preset: '${offset}jest.config.js',
          coverageDirectory: '${offset}coverage/${projectRoot}',
          reporters: [
            'default',
            [
              'jest-junit',
              { output: 'test-reports/${options.name}.xml', suiteName: '${options.name} tests' }
            ]
          ]
        };
        `
    );
    host.overwrite(
      `${options.projectRoot}/src/test-setup.ts`,
      `
      import 'jest-preset-angular';
      import '${offset}../jestGlobalMocks';
      `
    );
    return host;
  };
}
