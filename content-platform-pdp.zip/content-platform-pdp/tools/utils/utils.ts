import { Rule, Tree } from '@angular-devkit/schematics';
import { normalize } from '@angular-devkit/core';
// Alot of these util functions I took from the nrwl utils: https://github.com/nrwl/nx/tree/master/packages/schematics/src/utils

/**
 * Upper camelCase to lowercase, hypenated
 */
export function toFileName(s: string): string {
  return s
    .replace(/([a-z\d])([A-Z])/g, '$1_$2')
    .toLowerCase()
    .replace(/[ _]/g, '-');
}

/**
 * hypenated to UpperCamelCase
 */
export function toClassName(str: string): string {
  return toCapitalCase(toPropertyName(str));
}

function toCapitalCase(s: string): string {
  return s.charAt(0).toUpperCase() + s.substr(1);
}

/**
 * Hypenated to lowerCamelCase
 */
export function toPropertyName(s: string): string {
  return s
    .replace(/(-|_|\.|\s)+(.)?/g, (_, __, chr) => (chr ? chr.toUpperCase() : ''))
    .replace(/^([A-Z])/, m => m.toLowerCase());
}

export function getNpmScope(host: Tree) {
  // tslint:disable-next-line:no-non-null-assertion
  return JSON.parse(host.read('nx.json')!.toString('utf-8')).npmScope;
}

/**
 * This method is specifically for updating JSON in a Tree
 * @param path Path of JSON file in the Tree
 * @param callback Manipulation of the JSON data
 * @returns A rule which updates a JSON file file in a Tree
 */
export function updateJsonInTree<T = any, O = T>(path: string, callback: (json: T) => O): Rule {
  return (host: Tree): Tree => {
    host.overwrite(path, serializeJson(callback(readJsonInTree(host, path))));
    return host;
  };
}

/**
 * This method is specifically for reading JSON files in a Tree
 * @param host The host tree
 * @param path The path to the JSON file
 * @returns The JSON data in the file.
 */
export function readJsonInTree<T = any>(host: Tree, path: string): T {
  if (!host.exists(path)) {
    throw new Error(`Cannot find ${path}`);
  }

  // tslint:disable-next-line:no-non-null-assertion
  return JSON.parse(host.read(path)!.toString('utf-8'));
}

export function serializeJson(json: any): string {
  return `${JSON.stringify(json, null, 2)}\n`;
}

export function offsetFromRoot(fullPathToSourceDir: string): string {
  const parts = normalize(fullPathToSourceDir).split('/');
  let offset = '';
  for (let i = 0; i < parts.length; ++i) {
    offset += '../';
  }
  return offset;
}

export function getProjectConfig(host: Tree, name: string): any {
  const angularJson = readJsonInTree(host, '/angular.json');
  const projectConfig = angularJson.projects[name];
  if (!projectConfig) {
    throw new Error(`Cannot find project '${name}'`);
  } else {
    return projectConfig;
  }
}

export function getWorkspacePath(host: Tree) {
  const possibleFiles = ['/angular.json', '/.angular.json'];
  return possibleFiles.filter(path => host.exists(path))[0];
}
