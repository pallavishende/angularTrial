import { chain, externalSchematic, Rule, Tree, SchematicContext } from '@angular-devkit/schematics';
import {
  updateJsonInTree,
  toFileName,
  toClassName,
  getNpmScope,
  getWorkspacePath
} from '../../utils/utils';
import { updateJestConfig } from '../../utils/update-jest-config';

export default function(schema: any): Rule {
  return (host: Tree, _context: SchematicContext) => {
    const options = normalizeOptions(host, schema);
    return chain([
      externalSchematic('@nrwl/schematics', 'app', {
        ...schema,
        prefix: 'app',
        unitTestRunner: 'jest'
      }),
      updateJsonInTree(`${options.projectRoot}/tsconfig.app.json`, json => {
        json.exclude = json.exclude || [];
        return {
          ...json,
          exclude: ['src/test-setup.ts', '**/*.spec.ts']
        };
      }),
      addFrameRedirectAssets(options),
      updateJestConfig(options)
    ]);
  };
}

function normalizeOptions(host: Tree, options) {
  const projectDirectory = options.directory
    ? `${toFileName(options.directory)}/${toFileName(options.name)}`
    : toFileName(options.name);

  const projectName = projectDirectory.replace(new RegExp('/', 'g'), '-');
  const projectRoot = `apps/${projectDirectory}`;
  const moduleName = `${toClassName(projectName)}Module`;
  const parsedTags = options.tags ? options.tags.split(',').map(s => s.trim()) : [];
  const modulePath = `${projectRoot}/src/app/${projectName}.module.ts`;
  const defaultPrefix = getNpmScope(host);

  return {
    ...options,
    prefix: options.prefix ? options.prefix : defaultPrefix,
    name: projectName,
    projectRoot,
    entryFile: 'index',
    moduleName,
    projectDirectory,
    modulePath,
    parsedTags
  };
}

function addFrameRedirectAssets(options): Rule {
  return (host: Tree) => {
    return chain([
      updateJsonInTree(getWorkspacePath(host), json => {
        const project = json.projects[options.name];
        if (
          project.architect.build &&
          project.architect.build.options &&
          project.architect.build.options.assets
        ) {
          project.architect.build.options.assets.push(
            {
              input: 'libs/configuration/src/lib',
              glob: 'frameRedirect.html',
              output: '/'
            },
            {
              input: 'node_modules/adal-angular/dist',
              glob: 'adal.min.js',
              output: '/'
            }
          );
          project.architect.build.options.scripts = project.architect.build.options.scripts || [];
          project.architect.build.options.scripts.push('node_modules/adal-angular/lib/adal.js');
          json.projects[options.name] = project;
        }
        return json;
      })
    ]);
  };
}
