#!/bin/sh

#1. get environment variable and create config.json file
echo "{ \"config\": $config}" > /usr/share/nginx/html/config.json

#2.start nginx server
nginx -g "daemon off;"
exec "$@"