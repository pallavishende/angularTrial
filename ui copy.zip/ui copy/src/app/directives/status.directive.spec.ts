import { StatusDirective } from './status.directive';

describe('StatusDirective', () => {
  it('should create an instance', () => {
    const directive = new StatusDirective(null);
    expect(directive).toBeTruthy();
  });
});
