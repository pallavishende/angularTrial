import { Directive, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[html-format-directive]'
})
export class HtmlFormatDirective {
  @Input() text: string;

  constructor(private elRef: ElementRef) {
  }

  ngOnInit() {
    /* this gets called first time. however there is no data so we need to use ngChanges */
  }

  /* this directive defines the base styling for the statuses.
     the colors etc are defined by the css classes that correspond to status name
     since this is supposed to be a global sharable component, all the status styles will be in styles.scss
  */
  ngOnChanges(c) {
    if(this.text){
      // this.elRef.nativeElement.innerHTML =  this.text.replace(/\r?\n/g, '<br />');
      this.text = this.convert(this.text);
      this.elRef.nativeElement.innerHTML =  this.text.replace(/\r?\n/g, '');
    }
  }

  public convert(value) {
    let text = value.toString();
    if(text.match( /(href)|(src)/i )) {
      return text; // text already has a hyper link in it
    }
    let exp = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
    let text1 = text.replace( exp , '<a target="_blank" href="$1">$1</a>');
    let exp2 = /(^|[^\/])(www\.[\S]+(\b|$))/gim;
    return text1.replace(exp2, '$1<a target="_blank" href="http://$2">$2</a>');
  }
}
