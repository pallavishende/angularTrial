import { Directive, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[status-directive]'
})
export class StatusDirective {
  @Input() status: string;

  constructor(private elRef: ElementRef) {
  }

  ngOnInit() {
    /* this gets called first time. however there is no data so we need to use ngChanges */
  }

  /* this directive defines the base styling for the statuses.
     the colors etc are defined by the css classes that correspond to status name
     since this is supposed to be a global sharable component, all the status styles will be in styles.scss
  */
  ngOnChanges(c) {
    this.status = this.status || '';
    this.elRef.nativeElement.className = this.status + ' status-styles';
    this.elRef.nativeElement.innerHTML =  this.status.replace('_', ' ');
  }
}
