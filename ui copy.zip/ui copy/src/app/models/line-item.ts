import { CustomConfig } from './custom-config';
import { Metadata } from './metadata';
import { Activity } from './activity';

export class LineItem {
  id: any;
  activities: Array<Activity>;
  customConfig: CustomConfig;
  currentState?: Object;
  metadata: Array<Metadata>;
}
