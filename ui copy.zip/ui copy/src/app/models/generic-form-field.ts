export class OrderInstructionFormFields {
    formFiels: Array<GenericFormField>;
}

class GenericFormField {
    label: string;
    key: string;
    value: Array<string>;
    defaultValue: string;
    multiSelection: boolean;
    isRequiredField: boolean;
    charLimit: number;
}
