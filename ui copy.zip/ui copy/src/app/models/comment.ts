export class Comment {
  body: string;
  postedBy: string;
  activityId: any;
}