export class SubActivity {
  activityId?: string;
  description: string;
  typeId: number;
  assignedUserEmail: string;
  required: boolean;
  generationMode: string;
  previousTypeId?: number;
  previousUserEmail?: string;
  status?: string;
  // activity_ref?: Activity;
}
