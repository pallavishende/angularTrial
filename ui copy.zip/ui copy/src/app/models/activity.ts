import { SubActivity } from './sub-activity';

export class Activity {
  typeId: number;
  quantity: number;
  description: string;
  generationMode: string;
  subActivities: Array<SubActivity>;
  assignedUserEmail?: string;
  currentState?: Object;
  instructions?: Array<Instructions>;
  input?: { attachments?: Array<Object>, isUploading?: boolean };
}

export class Instructions {
  label: string;
  values: Array<any>;
}
