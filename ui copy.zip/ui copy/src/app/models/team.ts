export class Team {
  name: string;
  description?: string;
  memberEmails: Array<string>;
  createdBy: string;
  id?: number;
}
