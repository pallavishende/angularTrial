import { SubActivity } from './sub-activity';
import { Schedule } from './schedule';

export class CustomConfig {
  approvals: Array<SubActivity>;
  endpoint: string;
  version: string;
  schedule: Schedule
}
