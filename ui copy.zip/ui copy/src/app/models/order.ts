import * as _ from 'lodash';
import { Metadata } from './metadata';
import { Milestone } from './milestone';

export class Order {
    id?: number;
    to: number;
    order_for: number;
    creator: string;
    lineItems: any = [];
    lineItemsClipId: any = [];
    name: string;
    metadata: Metadata = new Metadata();
    dsid: string;
    currentMilestone: Milestone;
    milestones: Array<Milestone>;

    constructor(orderData: any) {
    }
}
