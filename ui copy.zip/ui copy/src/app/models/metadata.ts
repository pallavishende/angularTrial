export class Metadata {
  metadata: {};
}
