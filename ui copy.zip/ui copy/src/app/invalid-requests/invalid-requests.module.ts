import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { InvalidRequestsRoutesModule } from './invalid-requests-routes.module';
import { SharedModule } from '../shared/shared.module';
import { InvalidRequestsBaseComponent } from './invalid-requests-base/invalid-requests-base.component';

@NgModule({
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    InvalidRequestsRoutesModule,
    SharedModule
  ],
  declarations: [ PageNotFoundComponent, InvalidRequestsBaseComponent]
})
export class InvalidRequestsModule {}