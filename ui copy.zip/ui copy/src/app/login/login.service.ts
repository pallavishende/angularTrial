import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Title } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { AdalService } from 'ng2-adal/dist/core';
import { HttpClient } from '@angular/common/http';

import { Router } from '@angular/router';
import { SecretService } from '../services/secret.service';
import { ConfigurationManagerService } from '../configuration/configuration-manager.service';
import { ConfigService } from '../services/config.service';
import { UserService } from '../services/user.service';
import { StorageService } from '../services/storage.service';
import { EnvironmentService, RuntimeEnvironments } from '../services/environment.service';

@Injectable()
export class LoginService {

  private userInfo: any;

  initialize() {
    this.adalService.init(this.secretService.adalConfig);
  }

  handleWindowCallback() {
    this.adalService.handleWindowCallback();
  }

  isAuthenticated() {
    return this.adalService.userInfo.isAuthenticated;
  }

  constructor(
    private adalService: AdalService,
    private router: Router,
    private secretService: SecretService,
    private authHttp: HttpClient,
    private title: Title,
    private configService: ConfigService,
    private configurationManagerService: ConfigurationManagerService,
    private storageService: StorageService,
    private environmentService: EnvironmentService
  ) {
  }

  login() {
    this.adalService.config.extraQueryParameter = 'prompt=login&domain_hint=viacom.com';
    // if (
    //     this.environmentService.isRuntimeEnvironmentLowerThan(RuntimeEnvironments.DEV) ||
    //     this.environmentService.isRuntimeEnvironment(RuntimeEnvironments.PROD)) {
      console.log('Remove SSO hints');
      this.adalService.config.extraQueryParameter = '';
    // }
    this.adalService.login();
    this.adalService.config.extraQueryParameter = '';
  }

  logout() {
    this.configurationManagerService.removeConfigurationFromCache();
    if (this.storageService.getOrdersObjFromLocal() !== null) {
      this.storageService.resetOrdersObjInLocal();
    }
    if (this.storageService.getActivitesObjFromLocal() !== null) {
      this.storageService.resetActivitiesObjInLocal();
    }
    if (this.storageService.getCatalogObjFromLocal() !== null) {
      this.storageService.resetCatalogObjInLocal();
    }
    this.adalService.logOut();
    return true;
  }

  redirectIfAuthenticated(path: string) {
    if (this.isAuthenticated()) {
      this.authenticateIdentity()
      .then(response => {
         this.getUserInfo();
         if (this.userInfo.id === response) {
          this.router.navigateByUrl(path);
          } else {
            console.log(response);
            console.log(this.userInfo.id);
            console.log('User authentication rejected. token invalid.');
          }
      }).catch((error) => {
        console.log('Error: logging in.', error);
      });
    }
  }

  getUserInfo() {
    // if (this.isAuthenticated()) {
      this.userInfo = {
        id: this.adalService.userInfo.profile.oid,
        displayName: this.adalService.userInfo.profile.name,
        email: this.adalService.userInfo.userName,
        firstName: this.adalService.userInfo.profile.given_name,
        familyName: this.adalService.userInfo.profile.family_name,
        uniqueName: this.adalService.userInfo.profile.unique_name,
      };
     // }
    return this.userInfo;
  }

  private authenticateIdentity() {
    console.log('User authenticaiton in progress....');

    const idToken = this.adalService.getCachedToken(this.adalService.config.clientId);
    const securityUrl = this.configService.securityUrl;
    if (securityUrl !== undefined) {
      const serviceUrl =  securityUrl + 'authenticateToken?token=' + idToken;
      return this.authHttp.get(serviceUrl, {responseType: 'text'})
      .map((res:any) => res)
      .toPromise();
    } else {
      // this.logout();
    }
  }

  setLoginPageTitle(title: string) {
    this.title.setTitle(title);
  }
}
