import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { LoginService } from './login.service';
import { LoadingMaskService } from '../shared/loading-mask/loading-mask.service';
import { ConfigurationManagerService} from '../configuration/configuration-manager.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [ LoginService ]
})

export class LoginComponent implements OnInit, OnDestroy {
  model: any = {};
  isAuthenticated = false;
  @ViewChild('browserModal') browserModal;

  constructor(
    private route: ActivatedRoute,
    private loginService: LoginService,
    private loadingMask: LoadingMaskService,
    private configurationManagerService: ConfigurationManagerService,
  ) {
  }

  login() {
    this.loginService.login();
  }

  logout() {
    this.loginService.logout();
  }

  ngOnInit() {
    this.loginService.setLoginPageTitle('Viacom Bridge');
    if (this.loginService.isAuthenticated()) {
        this.loadingMask.enableLoadingMask();
    }
    this.isAuthenticated = this.loginService.isAuthenticated();
    this.loginService.redirectIfAuthenticated(this.route.snapshot.queryParams['returnUrl']);
    this.verifyUserBrowser();
  }

  verifyUserBrowser () {
    // check to if user is either not using Chrome or is using a small screen regardless of browser
    if (navigator.userAgent.indexOf('Chrome') === -1 || window.innerWidth < 1200 ) {
      this.browserModal.open();
    }
  }

  ngOnDestroy() {
    this.loadingMask.disableLoadingMask();
  }
}
