import { ConfigurationManagerService } from './configuration-manager.service';

export function configurationLoader(configurationManagerService: ConfigurationManagerService){
    return () =>  { return configurationManagerService.loadConfiguration(); } ;
}