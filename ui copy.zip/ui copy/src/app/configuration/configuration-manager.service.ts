import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { localhostConfiguration } from './localhostConfiguration';

const localStorageKey: string = 'bridge.config';
const localStorageKeyUserPhoto: string = 'bridge.userPhoto';

@Injectable()
export class ConfigurationManagerService {

    private isRunningInLocalhost: boolean;

    constructor(private http: HttpClient) {
        this.isRunningInLocalhost = document.URL.toString().includes('localhost');
    }

    public isRunningLocally() {
        return this.isRunningInLocalhost;
    }

    public loadConfiguration(): Promise<any> {
        console.log('Loading configuration...');
        let promise;
        if (this.isConfigurationLoaded()) {
            promise = new Promise((resolve) => { resolve(); });
            promise.then(res => {
                const config = this.getRawConfiguration();
                this.saveConfigurationInCache(config);
                console.log('Configuration loaded from cache.');
            });
        } else if (!this.isRunningLocally()) {
            promise =  this.http.get('/config.json').toPromise();
            promise.then(res =>  {
                    const config = JSON.stringify(res);
                    // this.addAliasAzureEndpoint(config);
                    this.saveConfigurationInCache(config);
                    console.log('Configuration loaded from server.');
                });
        } else {
            promise = new Promise((resolve) => { resolve(); });
            promise.then(res => {
                const config = JSON.stringify(localhostConfiguration);
                this.saveConfigurationInCache(config);
                console.log('Default configuration loaded.');
            });
        }
        return promise;
    }

    private getRawConfiguration() {
        return sessionStorage.getItem(localStorageKey);
    }

    public getConfiguration() {
        const aux = sessionStorage.getItem(localStorageKey);
        if (aux) {
            return JSON.parse(this.getRawConfiguration()).config;
        }else {
            return null;
        }
    }

    public isConfigurationLoaded(): boolean {
        const aux = this.getRawConfiguration();
        if (aux) {
            if (aux.toString().includes('config')){
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private saveConfigurationInCache(config: string) {
        sessionStorage.setItem(localStorageKey, config);
        console.log('Configuration loaded: ' + config);
    }

    public removeConfigurationFromCache() {
        localStorage.removeItem(localStorageKey);
        this.removeUserPhotoFromCache();
        console.log('Configuration removed from cache.');
    }

    public getUserPhotoObjectAsBase64StringFromCache() {
        const aux = sessionStorage.getItem(localStorageKeyUserPhoto);
        if (aux) {
            return aux;
        }else {
            return null;
        }
    }

    // public addAliasAzureEndpoint(adalConfig: any): void {
    //     // debugger;
    //     const aliasAzureADEndpointKey = 'https://aliasextsvc.viacom.com';
    //     const aliasAzureADEndpointValue = 'https://viacom.onmicrosoft.com/vmsapiprd';
    //     const aliasStgAzureADEndpointKey = 'https://aliasextsvcstg.viacom.com';
    //     const aliasStgAzureADEndpointValue = 'https://viacom.onmicrosoft.com/vmsapistg';
    //     console.log('Adal config before adding:', adalConfig, adalConfig.config, adalConfig.config.adal, adalConfig.config.adal.endpoints);
    //     if (typeof adalConfig !== 'undefined' && adalConfig) {
    //         if (typeof adalConfig.config !== 'undefined' && adalConfig.config) {
    //             if (typeof adalConfig.config.adal !== 'undefined' && adalConfig.config.adal) {
    //                 if (typeof adalConfig.config.adal.endpoints !== 'undefined' && adalConfig.config.adal.endpoints) {
    //                     adalConfig['config']['adal']['endpoints'][aliasAzureADEndpointKey] = aliasAzureADEndpointValue;
    //                     adalConfig['config']['adal']['endpoints'][aliasStgAzureADEndpointKey] = aliasStgAzureADEndpointValue;
    //                 }
    //             }
    //         }
    //     }
    //     console.log('Adal config after adding:', adalConfig);
    // }

    public saveUserPhotoAsBase64StringInCache(value: string) {
        sessionStorage.setItem(localStorageKeyUserPhoto, value);
    }

    public removeUserPhotoFromCache() {
        sessionStorage.removeItem(localStorageKeyUserPhoto);
        console.log('User photo removed from cache.');
    }
}