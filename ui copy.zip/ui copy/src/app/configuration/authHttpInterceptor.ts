import { Injectable, Injector, Inject } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { Router } from '@angular/router';
import { AdalService } from 'ng2-adal/dist/core';
import { Observable } from 'rxjs/Observable';
import { AuthHttp } from 'ng2-adal/dist/core';
import { DOCUMENT } from '@angular/platform-browser';
import { EnvironmentService } from '../services/environment.service';

const environmentConfigUrl = `/config.json`;
const aliasStgResourceEndpoint = `https://aliasextsvcstg.viacom.com`;
const aliasResourceEndpoint = `https://aliasextsvc.viacom.com/`;

@Injectable()
export class AuthHttpInterceptor implements HttpInterceptor {

  constructor( @Inject(DOCUMENT) private document: Element, private adalService: AdalService, private injector: Injector, private environmentService: EnvironmentService) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (request.url !== environmentConfigUrl) {
      return this.getToken(request.url)
        .switchMap((token) => {
          if (this.adalService.userInfo) {
            this.adalService.userInfo.isAuthenticated = true;
          }
          this.removeAdalFrame();
          return next.handle(request.clone({ setHeaders: { Authorization: `Bearer ${token}` } }));
        }).catch((error: HttpErrorResponse) => {
          if (error.status == null) {
            console.log('Not recoverable error, logging out.', error);
            this.removeAdalFrame();
          }
          return Observable.throw(error);
        });
    } else {
      return next.handle(request.clone());
    }
  }

  /**
   * for reference, check this out:
   * https://stackoverflow.com/questions/39767019/app-initializer-raises-cannot-instantiate-cyclic-dependency-applicationref-w
   */
  public get router(): Router {
    return this.injector.get(Router);
  }

  private getToken(url): Observable<string> {
    const aliasAssetDetailsUrl = this.environmentService.isRuntimeEnvironmentGreaterThan(4) ? this.environmentService.getAliasEndpoints().aliasAssetDetailsUrl : this.environmentService.getAliasEndpoints().aliasStgAssetDetailsUrl;
    const aliasAssetRestrictionsUrl = this.environmentService.isRuntimeEnvironmentGreaterThan(4) ? this.environmentService.getAliasEndpoints().aliasAssetRestrictionUrl : this.environmentService.getAliasEndpoints().aliasStgAssetRestrictionUrl;
    if (url === aliasAssetDetailsUrl || url.split('?')[0] === aliasAssetRestrictionsUrl) {
      return this.getUserTokenForAlias();
    } else {
      return this.adalService.acquireToken(this.adalService.GetResourceForEndpoint(url)).delay(200);
    }
  }

  private getUserTokenForAlias(): Observable<string> {
    const aliasResource = this.environmentService.isRuntimeEnvironmentGreaterThan(4) ? this.environmentService.getAliasEndpoints().aliasAzureADResourceUrl : this.environmentService.getAliasEndpoints().aliasStgAzureADResourceUrl;
    return this.adalService.acquireToken(aliasResource).delay(200);
  }

  private removeAdalFrame() {
    const iFrames = this.document.getElementsByTagName('iframe');
    for (let i = 0; i < iFrames.length; i++) {
      if (iFrames[i].id.startsWith('adal')) {
        iFrames[i].remove();
      }
    }
  }
}
