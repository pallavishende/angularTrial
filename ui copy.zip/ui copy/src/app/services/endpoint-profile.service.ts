import { Injectable } from '@angular/core';
import { ConfigService } from './config.service';
import { Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject, BehaviorSubject } from 'rxjs';

import * as _ from 'lodash';

import { HttpClient } from '@angular/common/http';


@Injectable()
export class EndpointProfileService {
  private endpointProfilesSubject = new BehaviorSubject(null);
  endpointProfiles = this.endpointProfilesSubject.asObservable();   // stream
  profilesCount: number = 0;
  _httpCall;

  constructor(private authHttp: HttpClient, private configService: ConfigService) { }

  getEndpoints() {
    var customHeaders = new Headers();
    customHeaders.append('Content-Type', 'application/json');
    customHeaders.append('Accept', 'application/json');

    if ( !this._httpCall ) {
      this._httpCall = this.authHttp.get(this.configService.epdUrl)
         .map((response: any) => response)
         .publishReplay(1)
         .refCount();
    }
    return this._httpCall;
  }

  getEndpointProfiles() {
    if ( this.profilesCount === 0 ) {
      this.getEndpoints().subscribe(
        data => {
          const profiles = data;
          const tmp = _.orderBy(profiles, (endpoint) => {
            return endpoint['name'];
          }, 'asc');
          _.each(tmp, (item) => {
            item['nameForImg'] = item['name'].replace(/ /g, '_').replace(/&/g, 'and');
          });
          this.profilesCount = tmp.length;
          this.endpointProfilesSubject.next(tmp);
        }
      );
    } else {
    }
    return this.endpointProfiles;
  }
}
