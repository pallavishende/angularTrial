import { Injectable } from '@angular/core';
import { EnvironmentService } from '../services/environment.service';

@Injectable()
export class ConfigService {
  public searchUrl: string;
  public searchDetailsUrl: string;
  public clipDetailsUrl: string;
  public omfUrl: string;
  public ordersUrl: string;
  public orderDetailsUrl: string;
  public orderFiltersUrl: string;
  public orderOwnerAssignmentUrl: string;
  public epdUrl: string;
  public activitiesUrl: string;
  public activityUrl: string;
  public assignActivitiesUrl: string;
  public unassignActivitiesUrl: string;
  public startWorkUrl: string;
  public reopenTaskUrl: string;
  public activityDetailUrl: string;
  public updUrl: string;
  public assigneeUrl: string;
  public teamUrl: string;
  public securityUrl: string;
  public activitiesFiltersUrl: string;
  public publishCopyOrdersUrl: string;
  public assetRestorationUrl: string;
  public userNotificationsUrl: string;
  public awsCognitoTokenUrl: string;
  public fileHandlerUrl: string;
  public orderInstructionFormUrl: string;
  public aliasAssetDetailsUrl: string;
  public aliasStgAssetDetailsUrl: string;
  public aliasAssetRestrictionUrl: string;
  public aliasStgAssetRestrictionUrl: string;
  public aliasAzureADResourceUrl: string;
  public aliasStgAzureADResourceUrl: string;
  public ADProfilePhotoUrl: string;

  constructor(private environmentService: EnvironmentService) {
    const environment = environmentService.getEnvironment();

    if (environment != null) {
      this.searchUrl = environment.searchUrl;
      this.searchDetailsUrl = environment.searchDetailsUrl;
      this.clipDetailsUrl = environment.clipDetailsUrl;
      this.omfUrl = environment.omfUrl;
      this.ordersUrl = environment.ordersUrl;
      this.orderDetailsUrl = environment.orderDetailsUrl;
      this.orderFiltersUrl = environment.orderFiltersUrl;
      this.orderOwnerAssignmentUrl = environment.orderOwnerAssignmentUrl;
      this.epdUrl = environment.epdUrl;
      this.activitiesUrl = environment.activitiesUrl;
      this.activityUrl = environment.activityUrl;
      this.assignActivitiesUrl = environment.assignActivitiesUrl;
      this.startWorkUrl = environment.startWorkUrl;
      this.reopenTaskUrl = environment.reopenTaskUrl;
      this.unassignActivitiesUrl = environment.unassignActivitiesUrl;
      this.activityDetailUrl = environment.activityDetailUrl;
      this.activitiesFiltersUrl = environment.activitiesFiltersUrl;
      this.publishCopyOrdersUrl = environment.publishCopyOrdersUrl;
      this.updUrl = environment.updUrl;
      this.assigneeUrl = environment.assigneeUrl;
      this.teamUrl = environment.teamUrl;
      this.userNotificationsUrl = environment.userNotificationsUrl;
      this.securityUrl = environment.securityUrl;
      this.assetRestorationUrl = environment.assetRestorationUrl;
      this.fileHandlerUrl = environment.fileHandlerUrl;
      this.orderInstructionFormUrl = environment.orderInstructionFormUrl;
      this.awsCognitoTokenUrl = environment.awsCognitoTokenUrl;
      this.aliasAssetDetailsUrl = environment.aliasAssetDetailsUrl;
      this.aliasStgAssetDetailsUrl = environment.aliasStgAssetDetailsUrl;
      this.aliasAssetRestrictionUrl = environment.aliasAssetRestrictionUrl;
      this.aliasStgAssetRestrictionUrl = environment.aliasStgAssetRestrictionUrl;
      this.aliasAzureADResourceUrl = environment.aliasAzureADResourceUrl;
      this.aliasStgAzureADResourceUrl = environment.aliasStgAzureADResourceUrl;
      this.ADProfilePhotoUrl = environment.ADProfilePhotoUrl;
    } else {
      console.log('Environment not defined.');
    }
  }
}
