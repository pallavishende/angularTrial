import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { Subject } from 'rxjs/Subject';
import * as AWS from 'aws-sdk/global';
import * as S3 from 'aws-sdk/clients/s3';
import 'amazon-cognito-js';
import 'rxjs/add/observable/of';
import { ConfigService } from './config.service';
import { EnvironmentService } from './environment.service';

@Injectable()
export class AwsS3ConfigService {

  private awsS3Credentails: AWSS3Credentials;
  public fileUploadProgressSubject = new Subject<any>();
  @Output() uploadCompletionSubject = new EventEmitter<string>();


  constructor(private configService: ConfigService, private environmentService: EnvironmentService, private authHttp: HttpClient) {}

  getAWSCognitoCredentials(): Observable<boolean> {
    const authCredentailsSubject = new Subject<any>();
    this.awsS3Credentails = new AWSS3Credentials();
    this.authHttp.get(this.configService.awsCognitoTokenUrl).retryWhen(error => {
      return error.flatMap((error) => {
        return Observable.of(error.status).delay(200);
      }).take(5).concat(Observable.throw({error: 'Cognito credentials call failed.'}));
    })
     .subscribe((data) => {
      console.log('Success: received cognito credentials:', data);
      // Initialize the Amazon Cognito credentials provider
      AWS.config.region = 'us-east-1'; // Region
      AWS.config.credentials = new AWS.CognitoIdentityCredentials({
        IdentityPoolId: 'us-east-1:5433de16-8ba9-4040-b290-391977bbad3b',
        IdentityId: data['identityId'],
        Logins: {
          'cognito-identity.amazonaws.com': data['token']
        }
      });

      AWS.config.getCredentials(() => {
        this.awsS3Credentails.accessKeyId = AWS.config.credentials.accessKeyId;
        this.awsS3Credentails.secretAccessKey = AWS.config.credentials.secretAccessKey;
        this.awsS3Credentails.sessionToken = AWS.config.credentials.sessionToken;
        console.log('accessKeyId: ' + this.awsS3Credentails.accessKeyId);
        console.log('secretAccessKey: ' + this.awsS3Credentails.secretAccessKey);
        console.log('sessionToken: ' + this.awsS3Credentails.sessionToken);
        AWS.config.update({ accessKeyId: this.awsS3Credentails.accessKeyId,
          secretAccessKey: this.awsS3Credentails.secretAccessKey, region: 'us-east-1' });
        authCredentailsSubject.next(true);
      });
    }, (error) => {
      console.log('Error: Cognito credentials api call failed.');
      console.log(error);
    });
    return authCredentailsSubject.asObservable();
  }

 getAWSS3Credentials(): AWSS3Credentials {
   return this.awsS3Credentails;
 }

 getPreSignedUrl(fileItem): Observable<string> {
      const filePreSignedUrl = new Subject<string>()
      this.getAWSCognitoCredentials().subscribe((data) => {
        const awsS3Credentails = this.getAWSS3Credentials();
        const bucket = new S3({
          accessKeyId: awsS3Credentails.accessKeyId,
          secretAccessKey: awsS3Credentails.secretAccessKey,
          sessionToken: awsS3Credentails.sessionToken,
          region: 'us-east-1'
        });
        const params = {
          Bucket: this.getS3BucketName(),
          Key: fileItem.name,
        };
        bucket.getSignedUrl('getObject', params, (error, data) => {
          if (error) {
            console.log('AWS ERROR: failed to get pre-signed url.', error);
            fileItem.isDeleted = false;
          } else {
            console.log('AWS: Successfully received pre-signed url.', data);
            filePreSignedUrl.next(data);
          }
        });
      });
      return filePreSignedUrl.asObservable();
  }

  /**
   * the bucket name will be fetched from the api, but for now
   * getting it in the UI
   */
  getS3BucketName(): string {
    if (this.environmentService.getCurrentRuntimeEnvironment() === 5) {
      return 'via-cp-prod-bridge-attachments';
    } else {
      if (this.environmentService.getCurrentRuntimeEnvironment() > 3) {
        return 'via-cp-stg2-bridge-attachments';
      } else {
        return 'via-cp-dev-bridge-attachments';
      }
    }
  }

}

class AWSS3Credentials {
  accessKeyId: string;
  secretAccessKey: string;
  sessionToken: string;
}
