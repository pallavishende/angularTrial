/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { SystemAlertsService } from './system-alerts.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('SystemAlertsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      providers: [SystemAlertsService]
    });
  });

  it('should ...', inject([SystemAlertsService], (service: SystemAlertsService) => {
    expect(service).toBeTruthy();
  }));
});
