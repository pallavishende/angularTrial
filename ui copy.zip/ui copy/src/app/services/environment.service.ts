import { Injectable } from '@angular/core';
import { ConfigurationManagerService } from '../configuration/configuration-manager.service';

@Injectable()
export class EnvironmentService {

  private environmentName: string;

  constructor(
    private configurationManagerService: ConfigurationManagerService) {
    this.setEnvironmentName();
  }

  getEnvironment(): any {
    const config = this.configurationManagerService.getConfiguration();

    if (config != null) {
      const gatewayUrl = this.configurationManagerService.getConfiguration().gatewayUrl;

      if (gatewayUrl !== undefined) {
        let endpointsObj = {
          searchUrl:                    `${gatewayUrl}/api/v1/search`,
          searchDetailsUrl:             `${gatewayUrl}/api/v1/search/content/`,
          clipDetailsUrl:               `${gatewayUrl}/api/v1/clips`,
          omfUrl:                       `${gatewayUrl}/api/v1/orders/`,
          ordersUrl:                    `${gatewayUrl}/api/v1.1/orders`,
          orderFiltersUrl:              `${gatewayUrl}/api/v1/order-filters`,
          orderDetailsUrl:              `${gatewayUrl}/bridge/api/v1/orders/`,
          orderOwnerAssignmentUrl:      `${gatewayUrl}/api/v1/orders/assignments`,
          epdUrl:                       `${gatewayUrl}/api/v1/endpoints/`,
          activitiesUrl:                `${gatewayUrl}/api/v1/grouped-activities`,
          activityUrl:                  `${gatewayUrl}/bridge/api/v1/activities/`,
          activityDetailUrl:            `${gatewayUrl}/bridge/api/v1/activity-bundles/`,
          assignActivitiesUrl:          `${gatewayUrl}/api/v1/grouped-activities/assignments/`,
          startWorkUrl:                 `${gatewayUrl}/api/v1/activity-bundles/startWork`,
          reopenTaskUrl:                `${gatewayUrl}/bridge/api/v1/orders-reopen/`,
          publishCopyOrdersUrl:         `${gatewayUrl}/bridge/api/v1/orders/search/copy-orders-by-vmid/`,
          updUrl:                       `${gatewayUrl}/api/v1/users/`,
          assigneeUrl:                  `${gatewayUrl}/bridge/api/v1/assignee/`,
          teamUrl:                      `${gatewayUrl}/api/v1/teams/`,
          securityUrl:                  `${gatewayUrl}/bridge/api/v1/security/`,
          unassignActivitiesUrl:        `${gatewayUrl}/api/v1/grouped-activities/unassignments/`,
          activitiesFiltersUrl:         `${gatewayUrl}/bridge/api/v1/activity-filters`,
          assetRestorationUrl:          `${gatewayUrl}/api/v1/line-items/`,
          fileHandlerUrl:               `${gatewayUrl}/api/v1/files`,
          awsCognitoTokenUrl:           `${gatewayUrl}/bridge/api/v1/security/cognito-token`,
          /**
           * external endpoints
           */
          ADProfilePhotoUrl:            `https://graph.microsoft.com/v1.0/me/photo/$value`,
          /**
           * mock endpoints
           */
          orderInstructionFormUrl:      `mock/api/v1/order-instructions-form-fields`
        };
        endpointsObj = Object.assign(this.getAliasEndpoints(), endpointsObj);
        return endpointsObj;
      } else {
        console.log('Gateway url not defined.');
      }
    } else {
      console.log('Configuration not found.');
    }
  }

  getAliasEndpoints() {
    const aliasUrl = `https://aliasextsvc.viacom.com`;
    const aliasStgUrl = `https://aliasextsvcstg.viacom.com/api`;
    return {
      aliasAssetDetailsUrl:         `${aliasUrl}/api/clipURL?expiry=60`,
      aliasAssetRestrictionUrl:     `${aliasUrl}/api/material/getRestrictionId`,
      aliasStgAssetDetailsUrl:      `${aliasStgUrl}/clipURL?expiry=60`,
      aliasStgAssetRestrictionUrl:  `${aliasStgUrl}/material/getRestrictionId`,
      aliasAzureADResourceUrl:      `https://viacom.onmicrosoft.com/vmsapiprd`,
      aliasStgAzureADResourceUrl:   `https://viacom.onmicrosoft.com/vmsapistg`
    };
  }

  setEnvironmentName() {
    const url = window.location.href;
    if (url.search('dev.bridge') > -1) {
      this.environmentName = 'dev';
    } else if (url.search('qa.bridge') > -1) {
      this.environmentName = 'qa';
    } else if (url.search('uat1.bridge') > -1) {
      this.environmentName = 'uat1';
    } else if (url.search('stg.bridge') > -1) {
      this.environmentName = 'stg';
    } else if (url.search('stg2.bridge') > -1) {
      this.environmentName = 'stg';
    } else if (url.search('localhost') > -1) {
      this.environmentName = 'localhost';
    } else {
      this.environmentName = 'prod';
    }
  }

  getEnvironmentName() {
    return this.environmentName;
  }

  getCurrentRuntimeEnvironment(): RuntimeEnvironments {
    switch (this.getEnvironmentName()) {
      case 'localhost': return RuntimeEnvironments.Local;
      case 'dev': return RuntimeEnvironments.DEV;
      case 'qa': return RuntimeEnvironments.QA;
      case 'uat1': return RuntimeEnvironments.UAT;
      case 'stg': return RuntimeEnvironments.STG;
      case 'prod': return RuntimeEnvironments.PROD;
      default: return RuntimeEnvironments.Unknown;
    }
  }

  isRuntimeEnvironment(environment: RuntimeEnvironments): boolean {
    return (this.getCurrentRuntimeEnvironment() === environment);
  }

  isRuntimeEnvironmentGreaterThan(environment: RuntimeEnvironments): boolean {
    return this.getCurrentRuntimeEnvironment() > environment;
  }

  isRuntimeEnvironmentLowerThan(environment: RuntimeEnvironments): boolean {
    return this.getCurrentRuntimeEnvironment() < environment;
  }

}

export enum RuntimeEnvironments {
  Local = 0,
  DEV = 1,
  QA = 2,
  UAT = 3,
  STG = 4,
  PROD = 5,
  Unknown = 99
}
