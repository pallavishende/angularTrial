import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

@Injectable()
export class SystemAlertsService {
  // Observable string sources
  // private alerts = new Subject<Array<Object>>();
  // alerts: Subject<string> = new BehaviorSubject<string>(null);
  private alerts = new Subject<Object>();
  // Observable string streams
  alertsStream = this.alerts.asObservable();

  constructor(
    private router: Router,
  ) {
  }

  addSuccessAlerts(alertMessage: string) {
    const alertObject = {
      type: 'success',
      messege: alertMessage
    };

    this.alerts.next(alertObject);
  }

  addErrorAlerts(alertMessage: string) {
    const alertObject = {
      type: 'error',
      messege: alertMessage
    };

    this.alerts.next(alertObject);
    console.log('systemAlertsService > addAlerts > alerts: ', this.alerts);
  }

  addWarningAlerts(alertMessage: string) {
    const alertObject = {
      type: 'warning',
      messege: alertMessage
    };

    this.alerts.next(alertObject);
    console.log('systemAlertsService > addAlerts > alerts: ', this.alerts);
  }

  redirectTo404Page() {
    this.router.navigateByUrl('invalid-request', { skipLocationChange: true });
  }

}
