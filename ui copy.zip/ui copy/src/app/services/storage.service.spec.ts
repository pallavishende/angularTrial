import { TestBed, inject } from '@angular/core/testing';
import { StorageService } from './storage.service';
import { RouterTestingModule } from '@angular/router/testing';
import { Router, Event, NavigationEnd } from '@angular/router';

describe('StorageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ 
        StorageService, 
        {provide: Router, useValue: RouterTestingModule },
       ]
    });
  });

  it('should be created', inject([StorageService], (service: StorageService) => {
    expect(service).toBeTruthy();
  }));
});
