import { Injectable } from '@angular/core';
import { ConfigurationManagerService } from '../configuration/configuration-manager.service';

@Injectable()
export class SecretService {
  
 constructor(private configurationManagerService: ConfigurationManagerService){}

  
  public get adalConfig(): any {

    let config = this.configurationManagerService.getConfiguration();

    if(config != null){
      return {
        tenant: config.adal.tenant,
        clientId: config.adal.clientId,
        redirectUri: window.location.origin + "/",
        postLogoutRedirectUri: window.location.origin + "/",
        endpoints:  config.adal.endpoints,
        cacheLocation: "localStorage",
      };
    }else{
      console.log("WARNING: configuration not available")
        return {
          tenant: "NA",
          clientId: "NA",
          redirectUri: window.location.origin + "/",
          postLogoutRedirectUri: window.location.origin + "/",
          endpoints:  "",
          cacheLocation: "localStorage",
        };
      }
    }
  }


       
   