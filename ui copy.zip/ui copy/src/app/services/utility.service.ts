import { Injectable } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { UserService } from './user.service';
import { LineItem } from '../models/line-item';
import * as _ from 'lodash';

@Injectable()
export class UtilityService {

  activityCategory = {
    ACTIVITY: 1,
    APPROVAL: 2
  };
  activityTypes = {
    CREATE_VIDEO: {
      type: 1, // manual task
      description: 'Create Video',
      label: 'Video',
      route: 'create-video',
      map: 1,
      category: this.activityCategory.ACTIVITY
    },
    STILLS:	{
      type: 2,
      description: 'Capture Still Frames',
      label: 'Still Frames',
      map: 2,
      category: this.activityCategory.ACTIVITY
    },
    COPYWRITE: {
      type: 3,
      description: 'Write Copy',
      label: 'Copy',
      route: 'write-copy',
      map: 3,
      category: this.activityCategory.ACTIVITY
    },
    CAPTIONS:	{
      type: 4,
      description: 'Edit Captions',
      label: 'Captions',
      map: 4,
      category: this.activityCategory.ACTIVITY
    },
    GRAPHICS:	{
      type: 5,
      description: 'Create Graphics',
      label: 'Graphics',
      route: 'create-graphics',
      map: 5,
      category: this.activityCategory.ACTIVITY
    },
    TRANSCODE: {
      type: 6,
      description: 'Transcode Video',
      map: 6,
      category: this.activityCategory.ACTIVITY
    },
    APPROVE_VIDEO: 	{
      type: 7,
      description: 'Approve Video',
      label: 'Video',
      route: 'approve-video',
      map: 1,
      category: this.activityCategory.APPROVAL
    }, 	// SubActivity
    APPROVE_CAPTIONS:	{
      type: 8,
      description: 'Approve Captions',
      label: 'Captions',
      map: 4,
      category: this.activityCategory.APPROVAL
    },  // SubActivity
    APPROVE_STILLS:	{
      type: 9,
      description: 'Approve Still Frames',
      label: 'Still Frames',
      map: 2,
      category: this.activityCategory.APPROVAL
    },	 // SubActivity
    APPROVE_COPYWRITE: {
      type: 10,
      description: 'Edit Copy',
      label: 'Copy',
      route: 'edit-copy',
      map: 3,
      category: this.activityCategory.APPROVAL
    },   // SubActivity
    APPROVE_GRAPHICS:	{
      type: 11,
      description: 'Approve Graphics',
      label: 'Graphics',
      route: 'approve-graphics',
      map: 5,
      category: this.activityCategory.APPROVAL
    },	 // SubActivity
    EDIT_COPY:	{
      type: 12,
      description: 'Edit Copy',
      map: 12,
      category: this.activityCategory.ACTIVITY
    },
    PUBLISH_VIDEO:	{
      type: 13,
      description: 'Publish Video',
      route: 'publish-video',
      map: 13,
      category: this.activityCategory.ACTIVITY
    },
    SITE_APP_UPDATES:	{
      type: 14,
      description: 'Site & App Updates',
      label: 'Site & App Updates',
      route: 'site-and-app-updates',
      map: 14,
      category: this.activityCategory.ACTIVITY
    },
    QA:	{
      type: 15,
      description: 'QA - Site & App Updates',
      label: 'QA - Site & App Updates',
      route: 'qa-site-and-app-updates',
      map: 14,
      category: this.activityCategory.APPROVAL
    },
    QA_VIDEO:	{
      type: 16,
      description: 'QA - Video',
      route: 'qa-video',
      map: 16,
      category: this.activityCategory.ACTIVITY
    }
  };

  activityGenerationMode = {
    Automatic: 'AUTOMATIC',
    Manual: 'MANUAL'
  };
  usersSubscription: Subscription;

  constructor(private userService: UserService) { }

  getActivityNameByTypeId(id) {
    const targetActivity = _.find(this.activityTypes, activity => activity.type === Number(id));
    if (targetActivity) {
      return targetActivity.description;
    }
  }

  getActivityRouteByTypeId(id) {
    let targetActivity = _.find(this.activityTypes, activity => activity.type === Number(id));
    if (targetActivity) {
      return targetActivity['route'];
    }
  }

  getActivityTypesList() {
    let tmp = [];
    let activityTypesRef = this.activityTypes;
    _.forEach(Object.keys(activityTypesRef), function(activityType) {
      tmp.push(activityTypesRef[activityType]);
    });
    return tmp;
  }

  // to be moved to activity helper service
  // returns activities grouped by version level
  getActivities(lineItems) {
    let result: Array<Object> = [];
    lineItems.forEach(lineItem => {
      const activitiesList = [];
      lineItem.activities.forEach(activity => {
        if (activity.subActivities.length > 0) {
          activity.subActivities.forEach(subActivity => activitiesList.push(subActivity));
        }
        activitiesList.push(activity);
      });
      result.push({id: lineItem.id, activities: activitiesList});
    });
    return result;
  }

  getProgressObj(activitiesObj) {
    const result = [];
    // result array doesn't contain cc and still frame
    this.getActivityTypesList().forEach(item => {
      if (item.type !== 2
      && item.type !== 4
      && item.type !== 8
      && item.type !== 9) {
        result.push({type: item.type, description: item.description, completed: 0, total: 0});
      }
    });
    let createVideo;
    let createFlag;
    let approveVideo;
    let approveFlag;
    activitiesObj.forEach(versionObj => {
      createVideo = false;
      createFlag = true;
      approveVideo = false;
      approveFlag = true;
      versionObj.activities.forEach(activity => {
        // handle create cc, stillframes and create videos together
        if (activity.typeId === 1 || activity.typeId === 2 || activity.typeId === 4) {
          createFlag = createFlag && (activity.currentState.status === 'COMPLETED' || activity.currentState.status === 'APPROVED');
          if (activity.typeId === 1) {
            createVideo = true;
          }
        } // handle approve cc, stillframes and approve videos together
        else if (activity.typeId === 7 || activity.typeId === 8 || activity.typeId === 9) {
          approveFlag = approveFlag && (activity.currentState.status === 'COMPLETED');
          if (activity.typeId === 7) {
            approveVideo = true;
          }
        } else if (result.find(item => item.type === activity.typeId)) {
          if (activity.currentState.status === 'COMPLETED' || activity.currentState.status === 'APPROVED') {
            result.find(item => item.type === activity.typeId).completed++;
          }
          result.find(item => item.type === activity.typeId).total++;
        }
      });
      if (createVideo) {
        if (createFlag) {
          result.find(item => item.type === 1).completed++;
        }
        result.find(item => item.type === 1).total++;
      }
      if (approveVideo) {
        if (approveFlag) {
          result.find(item => item.type === 7).completed++;
        }
        result.find(item => item.type === 7).total++;
      }
    });
    return result;
  }

  propertyFilter(filterObject, filterProperty, filterValue) {
    return _.hasIn(filterObject, filterProperty) && _.get(filterObject, filterProperty) === filterValue;
  }

  getDisplayNameFromEmail(email) {
    let displayName = '';
    let users;
    this.usersSubscription = this.userService.getAllUsers().subscribe(
      data => {
        if ( data ) {
          users = data['content'];
          if ( email !== '' ) {
            const tmp = _.find(users, { 'login': email });
            displayName = tmp ? `${tmp['firstName']} ${tmp['lastName']}` : 'NA';
            return displayName;
          } else {
            displayName = 'Unassigned';
            return displayName;
          }
        }
      },
      error => {
        console.log('Error: failed to get bridge users.');
      }
    );
    return displayName;
  }

  getLineItemActivity(typeId: number, lineItem: LineItem) {
    if (!lineItem || !typeId) {
      return null;
    }
    switch (typeId) {
      case 7:
        return this.getLineItemActivity(1, lineItem).subActivities[0];

      case 10:
        return this.getLineItemActivity(3, lineItem).subActivities[0];

      case 11:
        return this.getLineItemActivity(5, lineItem).subActivities[0];

      case 15:
        return this.getLineItemActivity(14, lineItem).subActivities[0];

      default:
        let targetActivity = _.filter(lineItem.activities, function (activity) {
          return activity['typeId'] === Number(typeId);
        });
        if (targetActivity && targetActivity.length > 0) {
          return targetActivity[0];
        }
    }
  }

  generateGuid() {
    let d = new Date().getTime();
    let uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = (d + Math.random() *16 ) % 16 | 0;
      d = Math.floor(d / 16);
      return (c === 'x' ? r : (r&0x3|0x8)).toString(16);
    });
    return uuid;
  }

  getHeaderForContentType(metadata, contentType?: string): string {
    if (!contentType) {
      return '';
    }
    contentType = contentType.toUpperCase();
    if (contentType === 'BRAND' && metadata.originBrandName) {
      return metadata.originBrandName;
    } else if (contentType === 'SERIES' && metadata.seriesTitle) {
      return metadata.seriesTitle;
    } else if (contentType === 'SEASON') {
      if (metadata.seasonTitle) {
        return metadata.seasonTitle;
      } else if (metadata.seriesTitle && metadata.seasonNumber) {
        return metadata.seriesTitle + ', Season ' + metadata.seasonNumber;
      } else if (metadata.title) {
        return metadata.title;
      }
    } else if (contentType === 'EPISODE') {
      if (metadata.episodeNumber && metadata.title) {
        if (!metadata.seriesTitle) {
          return '#' + metadata.episodeNumber + ': ' + metadata.title; // only missing series title
        } else {
          return metadata.seriesTitle + ' #' + metadata.episodeNumber + ': ' + metadata.title; // standard
        }
      } else if (metadata.seriesTitle && metadata.episodeNumber) {
        return metadata.seriesTitle + ' #' + metadata.episodeNumber; // missing episode name
      } else if (metadata.seriesTitle && metadata.title) {
        return metadata.seriesTitle + ': ' + metadata.title; // missing episode number
      }
    } else if ((contentType === 'EVENT' || contentType === 'SPECIAL') && metadata.movieAndSpecial) {
      return metadata.movieAndSpecial;
    }
    return '';
  }

}
