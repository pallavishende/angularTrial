import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { SharedModule } from './shared/shared.module';
import { RouteGuard } from './route-guard/route-guard';
import { ActivitiesBaseComponent } from './activities/activities-base/activities-base.component';
import { UserPreferencesModule } from './user-preferences/user-preferences.module';
import { InvalidRequestsModule } from './invalid-requests/invalid-requests.module';
import { PageNotFoundComponent } from './invalid-requests/page-not-found/page-not-found.component';
import { OnboardingModule } from './onboarding/onboarding.module';

const AppRoutes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'catalog', canActivate: [ RouteGuard ],
    children: [
      { path: '', loadChildren: './catalog/catalog.module#CatalogModule' }
    ]
  },
   { path: 'settings', canActivate: [ RouteGuard ],
    children: [
      { path: '', loadChildren: './user-preferences/user-preferences.module#UserPreferencesModule' }
    ]
  },
  { path: 'shared', canActivate: [ RouteGuard ],
    children: [
      { path: '', loadChildren: './shared/shared.module#SharedModule' }
    ]
  },
  { path: 'orders', canActivate: [ RouteGuard ],
    children: [
      { path: '', loadChildren: './orders/orders.module#OrdersModule' }
    ]
  },
  { path: 'tasks', canActivate: [ RouteGuard ],
    children: [
      { path: '', loadChildren: './activities/activities.module#ActivitiesModule' }
    ]
  },
  { path: 'get-started', canActivate: [ RouteGuard ],
    children: [
      { path: '', loadChildren: './onboarding/onboarding.module#OnboardingModule' }
    ]
  },
  { path: '',   redirectTo: 'login', pathMatch: 'full' },
 { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(AppRoutes) ],  //   imports: [ RouterModule.forRoot(AppRoutes, {useHash: true})  ]
  exports: [ RouterModule ],
  providers: [ RouteGuard ]
})

export class AppRoutesModule {}

