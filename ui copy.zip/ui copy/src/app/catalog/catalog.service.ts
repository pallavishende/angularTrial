import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import { Subject, BehaviorSubject } from 'rxjs';
import 'rxjs/add/operator/map';
import { ConfigService } from '../services/config.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Activity } from '../models/activity';
import { SubActivity } from '../models/sub-activity';
import { LoadingMaskService } from '../shared/loading-mask/loading-mask.service';
import { SystemAlertsService } from '../services/system-alerts.service';
import { UserService } from '../services/user.service';
import { OrdersService } from '../orders/orders/orders.service';
import { UtilityService } from '../services/utility.service';
import { NavigationService } from '../services/navigation.service';
import { EnvironmentService } from '../services/environment.service';

const aliasAssetDetailsApiKey = `F3A4F748-604A-4CDB-83AF-58B20FAC327B`;

@Injectable()
export class CatalogService {
  private itemDetailSubject = new BehaviorSubject(null);
  itemDetailStream = this.itemDetailSubject.asObservable();
  itemDetailsCache = {};
  headers = new Headers();
  body = {
    searchTerm: null,
    size: null,
    offset: 0,
    searchType: '',
    seriesTitleFilters: [],
    seasonNumberFilters: [],
    brandNameFilters: []
  };
  selectedVersion = {
    dsid: '',
    name: ''
  };
  catalogOrderClipsArr = [];

  constructor(
    private title: Title,
    private authHttp: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private userService: UserService,
    private ordersService: OrdersService,
    private utilityService: UtilityService,
    private loadingMask: LoadingMaskService,
    private alerts: SystemAlertsService,
    private navigationService: NavigationService,
    private environmentService: EnvironmentService
  ) {}

  getItems(searchObj: any, pageCount: number, contentType) {
    this.headers.append('Content-Type', 'application/json');
    this.headers.append('Accept', 'application/json');
    this.body = {
      searchTerm: searchObj.searchTerm.value,
      size: 25,
      offset: 50 + (25 * (pageCount - 2)),
      searchType: contentType,
      seriesTitleFilters: searchObj.seriesTitleFilters,
      seasonNumberFilters: searchObj.seasonNumberFilters,
      brandNameFilters: searchObj.brandNameFilters
    };
    if (pageCount === 1) {
      this.body.offset = 0;
      this.body.size = 50;
    }
    if (this.body.searchType === 'brands') {
      return this.getBrandsContent();
    } else {
      return this.authHttp.post(this.configService.searchUrl, this.body);
    }
  }

  getContent(contentType: string) {
    const requestPayload = this.body;
    // requestPayload.searchType = contentType;
    console.log('requesthing this payload:', requestPayload);
    return this.authHttp.post(this.configService.searchUrl, requestPayload);
  }

  getBrandsContent() {
    return this.authHttp.get(`${this.configService.searchUrl}/brands?name=${encodeURIComponent(this.body.searchTerm)}`);
  }

  getSeriesContent() {
    this.headers.append('Content-Type', 'application/json');
    this.headers.append('Accept', 'application/json');
  }

  getItemDetails(vmid: string, contentType?: string) {
    if (contentType === 'BRAND') {
      return this.authHttp.get(this.configService.searchUrl + '/brands-by-ids/' + vmid)
      .map((response: any) => response);
    }
    return this.authHttp.get(this.configService.searchDetailsUrl + vmid)
      .map((response: any) => response);
  }

  getItemDetailsCached(vmid: string) {
    if ( this.itemDetailsCache[vmid] === undefined ) {
      // fetch data and set up streem
      console.log('getItemDetailsCached > empty');
      this.getItemDetails(vmid).subscribe(
        data => {
          console.log('getItemDetailsCached > empty > data: ', data);
          this.itemDetailsCache[vmid] = data;
          this.itemDetailSubject.next(data);
        }
      );
    } else {
      console.log('getItemDetailsCached > NOT empty > data: ', this.itemDetailStream);
    }
    return this.itemDetailStream;
  }

  getVersionDetails(vmid: string, dsid: string) {
    return this.authHttp.get(this.configService.searchDetailsUrl + vmid + '/' + dsid)
      .map((response: any) => response);
  }

  getClipDetails(clipIdentifier: any) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'ApiKey': aliasAssetDetailsApiKey
      })
    };
    const payload = [{
       'ItemId': clipIdentifier.clipId,
      'ItemType': 'Clip',
      'MaterialId': clipIdentifier.materialId
    }];
    const aliasAssetDetailsEndpoint = this.environmentService.isRuntimeEnvironmentGreaterThan(4) ? this.configService.aliasAssetDetailsUrl : this.configService.aliasStgAssetDetailsUrl;
    return this.authHttp.post(aliasAssetDetailsEndpoint, payload, httpOptions);
  }

  getAssetRestrictionType(clipId: string): Observable<any> {
     const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'ApiKey': aliasAssetDetailsApiKey
      })
    };
    const aliasAssetRestrictionEndpoint = this.environmentService.isRuntimeEnvironmentGreaterThan(4) ? this.configService.aliasAssetRestrictionUrl : this.configService.aliasStgAssetRestrictionUrl;
    return this.authHttp.get(`${aliasAssetRestrictionEndpoint}?contentId=${clipId}`, httpOptions);
  }

  getClips(vmId: string, dsId: string, clipId: Array<number>) {
    return this.authHttp.get(this.configService.clipDetailsUrl + '/' + vmId + '/' + dsId + '/' + clipId.toString(),
    {observe: 'response', responseType: 'text'}).map((response) => JSON.parse(response.body));
  }

   setCatalogPageTitle(title: string) {
    this.title.setTitle(title);
   }

   getCatalogContentIndex(contentType: string): CatalogContent {
     switch (contentType) {
      case 'EPISODE': return CatalogContent.EPISODE;
      case 'SERIES': return CatalogContent.SERIES;
      case 'EVENT': return  CatalogContent.EVENT;
      case 'BRAND': return  CatalogContent.BRAND;
    }
   }

  getSeriesDetails(seriesVmid: string) {
    return this.authHttp.get(`${this.configService.searchUrl}/content/${seriesVmid}`);
  }

  getSeasonDetails(seriesVmid: string, seasonVmid: string) {
    return this.authHttp.get(`${this.configService.searchUrl}/content/${seasonVmid}`);
  }

/**
 *  Create new order methods start here
 */
  createNewOrder(payload, orderType, linkOrderId?: Array<any>) {
    this.loadingMask.enableLoadingMask();
    this.ordersService.createOrder(payload)
    .subscribe(
      data => {
        this.catalogOrderClipsArr.length = 0;
        if (linkOrderId) { // if order is created as a mirror order, no navigation happens and is linked to original order
          this.ordersService.linkOrders(data.id, linkOrderId).subscribe(
            data => {
              this.loadingMask.disableLoadingMask();
              this.alerts.addSuccessAlerts('Your order <strong>' + payload.name + '</strong> was created successfully!');
              this.ordersService.notifyLinkOrderUpdate(linkOrderId);
            }
          );
        } else {
          if (orderType === 'video') {
            this.navigationService.disableRouteGuard();
            this.router.navigate(['orders/' + data.id + '/draft/endpoint']);
          } else {
            this.navigationService.disableRouteGuard();
            this.router.navigate(['orders/' + data.id + '/draft/instructions']);
          }
        }
      },
      error => {
        console.log('error');
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      }
    );
  }

  createVideoOrder(orderName, vmId, contentType, isFullEpisode: boolean, lineItems, linkOrderId?: Array<any>) {
    this.loadingMask.enableLoadingMask();
    const userLoginInfo = this.userService.getUserLoginInfo();
    contentType = contentType.toUpperCase();
    if (contentType === 'EVENT' || contentType === 'MOVIE') {
      contentType = 'SPECIAL';
    }
    const payload = {
      name: orderName,
      creator: userLoginInfo['firstName'] + ' ' + userLoginInfo['familyName'],
      createdBy: userLoginInfo['email'],
      assigneeEmail: userLoginInfo['email'],
      metadata: {
        'vmId': vmId,
        'contentType': contentType,
        'orderType': 'VIDEO',
        'isFullEpisode': isFullEpisode,
        // TO BE REMOVED temporary flag for combined approval and publish
        'isNewOrder': true
      },
      lineItems: lineItems,
      orderFor: 2222,
      to: 'bridge'
    };
    if (linkOrderId) {
      this.createNewOrder(payload, 'video', linkOrderId);
    } else {
      this.createNewOrder(payload, 'video');
    }
  }

  createNonVideoOrder(orderName, vmId, contentType, orderType, linkOrderId?: Array<any>) {
    this.loadingMask.enableLoadingMask();
    const activityObj = new Activity();
    const subActivityObj = new SubActivity();
    const userLoginInfo = this.userService.getUserLoginInfo();
    contentType = contentType.toUpperCase();
    if (contentType === 'EVENT' || contentType === 'MOVIE') {
      contentType = 'SPECIAL';
    }
    const payload = {
      name: orderName,
      creator: userLoginInfo['firstName'] + ' ' + userLoginInfo['familyName'],
      createdBy: userLoginInfo['email'],
      assigneeEmail: userLoginInfo['email'],
      metadata: {
        'vmId': vmId,
        'contentType': contentType,
        'orderType': orderType.toUpperCase(),
        'isFullEpisode': false,
        // TO BE REMOVED temporary flag for combined approval and publish
        'isNewOrder': true
      },
      lineItems: [],
      orderFor: 2222,
      to: 'bridge'
    };

    activityObj.quantity = 1;
    subActivityObj.generationMode = this.utilityService.activityGenerationMode.Automatic;
    switch (orderType) {
      case 'copy':
      activityObj.typeId = this.utilityService.activityTypes.COPYWRITE.type; // 3;
      activityObj.input = {};
      subActivityObj.typeId = this.utilityService.activityTypes.APPROVE_COPYWRITE.type;
      subActivityObj.description = this.utilityService.activityTypes.APPROVE_COPYWRITE.description;
      break;

      case 'graphics':
      activityObj.typeId = this.utilityService.activityTypes.GRAPHICS.type; // 5;
      activityObj.input = {};
      subActivityObj.typeId = this.utilityService.activityTypes.APPROVE_GRAPHICS.type; // 11
      subActivityObj.description = this.utilityService.activityTypes.APPROVE_GRAPHICS.description;
      break;

     case 'siteAndAppUpdates':
      activityObj.typeId = this.utilityService.activityTypes.SITE_APP_UPDATES.type; // 14;
      activityObj.input = {};
      subActivityObj.typeId = this.utilityService.activityTypes.QA.type; // 15
      subActivityObj.description = this.utilityService.activityTypes.QA.description;
      payload.metadata.orderType = 'SITE_APP_UPDATES';
      break;
    }

    activityObj.subActivities = [];
    activityObj.subActivities.push(subActivityObj);

    payload.lineItems['activities'] = [];
    payload.lineItems.push({'activities': [activityObj]});
    if (linkOrderId) {
      this.createNewOrder(payload, 'copy', linkOrderId);
    } else {
      this.createNewOrder(payload, 'copy');
    }
  }

/**
 * Create new order methods end here
 */
}

export enum CatalogContent {
  EPISODE = 0,
  SERIES = 1,
  EVENT = 2,
  BRAND = 3
}
