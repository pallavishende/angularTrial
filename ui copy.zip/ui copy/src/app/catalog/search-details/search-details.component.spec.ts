/* tslint:disable:no-unused-variable */

/*
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { HttpClientModule } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CatalogService } from '../catalog.service';
import { ConfigService } from '../../services/config.service';
import { ModalModule } from "ng2-modal";
import { SystemAlertsService } from '../../services/system-alerts.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { ToasterContainerComponent, ToasterConfig, BodyOutputType } from 'angular2-toaster';

import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SearchDetailsComponent } from './search-details.component';
import { ToasterModule, ToasterService } from 'angular2-toaster';

describe('SearchDetailsComponent', () => {
  let component: SearchDetailsComponent;
  let fixture: ComponentFixture<SearchDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, CommonModule, HttpClientModule, RouterTestingModule, ModalModule, ToasterModule ],
      declarations: [ SearchDetailsComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      providers: [ {provide: CatalogService, useValue: CatalogService},
        {provide: ConfigService, useValue: ConfigService},
        {provide: SystemAlertsService, useValue: SystemAlertsService },
        {provide: ToasterService, useValue: ToasterService}  ,
        LoadingMaskService    ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
*/