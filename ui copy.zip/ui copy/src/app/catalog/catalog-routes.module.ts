import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CatalogBaseComponent } from './catalog-base/catalog-base.component';
import { SearchComponent } from './search/search.component';
import { SearchDetailsComponent } from './search-details/search-details.component';
import { SiteHeaderComponent } from '../shared/site-header/site-header.component';

const CatalogRoutes: Routes = [
  { path: '', component: CatalogBaseComponent, data: {title: 'Catalog'},
    children: [
      { path: '', component: SearchComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  },
  { path: 'content-details/:id/:dsid', component: CatalogBaseComponent, data: {title: 'Content Details', name: ''},
    children: [
      { path: '', component: SearchDetailsComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  },
  { path: 'content-details/:id', component: CatalogBaseComponent, data: {title: 'Content Details', name: ''},
    children: [
      { path: '', component: SearchDetailsComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  }
];

@NgModule({
  imports: [ RouterModule.forChild(CatalogRoutes) ],
  exports: [ RouterModule ]
})

export class CatalogRoutesModule {}
