/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { Http, Response, Headers, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import 'rxjs/add/observable/of';

import { SearchComponent } from './search.component';
import { CatalogService } from '../catalog.service';
import { ConfigService } from '../../services/config.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { FormsModule, FormControl, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from '@angular/router';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { ContentPanelService } from './content-panel/content-panel.service';

import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { StorageService } from '../../services/storage.service';


xdescribe('SearchComponent', () => {
  let fixture, greeter, element, debugElem, app;
  let mockBackend, service;
  let mockSearchObj = {
    searchTerm: 'south'
  };
  let mockCatalogService = {
      getItems: (searchObj) => {
        return {
            episodes: [
              {id:1, name:'item 1'},
              {id:2, name:'item 2'}
            ]
          };
      }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, ReactiveFormsModule, CommonModule, HttpClientModule, RouterTestingModule, RouterModule ],
      declarations: [ SearchComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      providers: [
        { provide: CatalogService, useValue: mockCatalogService },
        StorageService,
        ConfigService,
        SystemAlertsService,
        MockBackend,
        BaseRequestOptions,
        LoadingMaskService,
        ContentPanelService,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        }
      ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(SearchComponent);
    element = fixture.nativeElement;              // to access DOM element
    debugElem = fixture.debugElement;             // test helper
    app = fixture.debugElement.componentInstance; // to access properties and methods
  }));

  beforeEach(inject([CatalogService, MockBackend], (s, m) => {
    service = s;
    mockBackend = m;
  }));

  it('#should create search component', () => {
    expect(app).toBeTruthy();
  });

  it('#should remove special characters', () => {
    expect(app.removeSpecialCharacters('&s_pe*@#cial')).toEqual(' s_pe   cial');
  });

  it('#should have ngOnInit defined', () => {
    spyOn(mockCatalogService, 'getItems').and.returnValue(Observable.of({id: 111}));
    expect(app.ngOnInit).toBeDefined();
  });

  xit('#should have dataSubscription defined', async(() => {
    let results = {
      episodes: [
        {id:1, name:'item 1'},
        {id:2, name:'item 2'}
      ]
    };
    spyOn(mockCatalogService, 'getItems').and.callFake(function(searchObj) {
      return Observable.of(results);
    });
    app.searchObj = mockSearchObj;
    app.getResults();
    expect(app.dataSubscription).toBeDefined();
  }));

  it('should have data defined', async(() => {
    let data = service.getItems(mockSearchObj);
    expect(data).toBeDefined();
  }));

  it('should have 2 episodes in data', async(() => {
    let data = service.getItems(mockSearchObj);
    expect(data.episodes.length).toEqual(2);
  }));

  // it('#should have sortData defined', () => {
  //   expect(app.sortData).toBeDefined();
  // });

  // it('#sortData should have 3 parameters', () => {
  //   expect(app.sortData.length).toEqual(3);
  // });

  // it('#should have goToDetail defined', () => {
  //   expect(app.goToDetail).toBeDefined();
  // });

});
