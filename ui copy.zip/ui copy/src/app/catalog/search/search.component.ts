import { Component, OnInit, ElementRef, ViewChild, AfterViewInit, OnDestroy, ApplicationRef, TemplateRef, HostListener } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from 'rxjs/Subscription';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { forkJoin } from 'rxjs/observable/forkJoin';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/throttleTime';
import 'rxjs/add/observable/fromEvent';

import { CatalogService } from '../catalog.service';
import { ContentPanelService } from './content-panel/content-panel.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { StorageService } from '../../services/storage.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['../catalog-base/catalog-base.component.scss', './search.component.scss']
})

export class SearchComponent implements OnInit, OnDestroy, AfterViewInit {

  filterObj: any;
  searchValue: string;
  totalResultsFound = 0;
  searchResults: any;
  advancedFilterObj;
  sortObj = {
    'sortParamsObj': {},
    currentSortSelection: ''
  };
  dataObservable: Observable<{}>;
  subscriptions = new Subscription();
  contentSubscription: Subscription;
  // maximum number of filters available when the results load for brands, series, seasons and versions respectively
  numberOfFilters = Array<number>();
  validSearchInput: boolean;
  isLoadingData: boolean;
  activeCatalogTab: string = 'EPISODE';
  searchObj = {
    searchTerm: new FormControl(),
    pageCount: 1,
    searchType: 'episode',
    brandNameFilters: [],
    seriesTitleFilters: [],
    seasonNumberFilters: []
  };

  /**
   * this needs to be removed from here
   */
  seriesDetails = {
    description: '',
    title: '',
    seasons: [],
    brand: '',
    vmid: ''
  };
  orderName = '';
  isFullEpisode = false;
  orderInfoObj = {};

  @ViewChild('searchInput') searchInput;
  @ViewChild('sidenav') sidenav;
  @ViewChild('contentRegistryDialog') contentRegistryDialog: TemplateRef<any>;
  @ViewChild('orderTitle') input: ElementRef;
  @HostListener('window:scroll', [])
  onWindowScroll() {
    const scrollPercentage = (((window.scrollY + window.innerHeight) / document.scrollingElement.scrollHeight)) * 100;
    if (scrollPercentage >= 98
      && this.searchResults
      && this.searchResults.length
      && this.getContentSize() < this.totalResultsFound
      && !this.isLoadingData) {
      this.isLoadingData = true;
      this.loadMoreResponseData();
    }
  }

  clearFilterChecks(filterName?: string) {
    this.resetFilters(filterName);
    this.updateFilters();
  }

  constructor(
    private applicationRef: ApplicationRef,
    private matDialog: MatDialog,
    private catalogService: CatalogService,
    private contentPanelService: ContentPanelService,
    private loadingMask: LoadingMaskService,
    private storageService: StorageService,
    private alerts: SystemAlertsService
  ) {
   }

  getContentSize() {
    if (typeof this.searchResults !== 'undefined') {
      if (this.activeCatalogTab === 'BRAND') {
        return this.searchResults[3].brandsResult.length;
      } else {
        return this.searchResults[this.getCurrentContentIndex()].contentResult.length;
      }
    }
  }

  ngOnInit() {
    this.loadingMask.enableLoadingMask();
    this.catalogService.setCatalogPageTitle('Catalog - Viacom Bridge');
    this.getPersistSearchResponse();
    this.subscriptions.add(this.searchObj.searchTerm.valueChanges.debounceTime(500).distinctUntilChanged().subscribe((event) => {
      if (this.searchObj.searchTerm.dirty) {
        this.loadingMask.enableLoadingMask();
        this.searchObj.searchTerm.setValue(event, { emitEvent: false });
        this.searchValue = this.searchObj.searchTerm.value;
        this.activeCatalogTab = 'EPISODE';
        this.getResults();
      }
    }));
    this.loadingMask.enableLoadingMask();
    this.getResults();
  }

  ngAfterViewInit() {
    this.searchInput.nativeElement.focus();
  }

  resetFilters(filterName?: string) {
    if (!filterName) {
      this.searchObj.brandNameFilters = [];
      this.searchObj.seasonNumberFilters = [];
      this.searchObj.seriesTitleFilters = [];
    } else {
      this.searchObj[filterName] = [];
    }
    this.resetFiltersCount();
  }


  updateFilters(e?, filter?) {
    // this.sortObj.sortParamsObj = {};
    if (e && filter) {
      if (e.target.checked) {
        this.searchObj[filter].push(e.target.name);
      } else {
        const index = this.searchObj[filter].indexOf(e.target.name);
        this.searchObj[filter].splice(index, 1);
      }
    }
    this.resetCatalogPageCount();
    this.loadingMask.enableLoadingMask();
    this.subscriptions.add(this.catalogService.getItems(this.searchObj, this.searchObj.pageCount, this.activeCatalogTab.toLowerCase())  // 1 is the page number
    .subscribe(
      data => {
        this.loadingMask.disableLoadingMask();
        this.totalResultsFound = (data['totalHits'] === undefined) ? 0 : parseInt(data['totalHits']);
        this.searchResults[this.getCurrentContentIndex()] = data;
        this.searchResults = this.searchResults.slice();
        this.advancedFilterObj = {
          availableSeries: data['availableSeries'],
          availableBrands: data['availableBrands'],
          availableSeasons: _.sortBy(data['availableSeasons'], (season) => {
            return season['seasonNumber'];
          })
        };
        this.changeFiltersCount();
        this.setPersistSearchResponse();
      },
      error => {
        this.loadingMask.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        console.log('error');
      }
    ));
  }

  removeSpecialCharacters(s) {
    if (s !== undefined) {
      return s.toString().replace(/[^\w\s]/gi, ' ');
    }
  }

  clearTerm() {
    this.searchObj.searchTerm.setValue('');
    this.searchValue = '';
    this.activeCatalogTab = 'EPISODE';
    delete this.searchResults;
    delete this.advancedFilterObj;
    // this.sortObj.sortParamsObj = {};
    this.resetFilters();
    this.setPersistSearchResponse();
  }

  clearSearchAndFilters() {
    this.clearTerm();
  }

  getSeriesDetails(seriesVmid: string) {
    this.contentPanelService.sideNavSubject.next();
    this.subscriptions.add(this.catalogService.getSeriesDetails(seriesVmid).subscribe((data) => {
      data = data['contentDetails'];
      this.seriesDetails.description = data['description'];
      this.seriesDetails.title = data['title'];
      this.seriesDetails.seasons = data['seasons'];
      this.seriesDetails.brand = data['originBrandName'];
      this.seriesDetails.vmid = data['vmid'];
      this.contentPanelService.seriesDetailSubject.next(this.seriesDetails);
    }));
  }

  getSeasonDetails(event) {
    this.subscriptions.add(this.catalogService.getSeasonDetails(event.seriesVmid, event.seasonVmid).subscribe(
    (data) => {
      this.contentPanelService.seasonDetailSubject.next(data);
    }));
  }

  getResults() {
    if (this.searchObj.searchTerm.dirty) {
      this.resetFilters();
    }
    // this.sortObj.sortParamsObj = {};
    if (this.searchObj.searchTerm.value !== null) {
      if ((this.searchObj.searchTerm.value).trim() === '') {
        this.validSearchInput = false;
        this.clearTerm();
        this.loadingMask.disableLoadingMask();
        return;
      } else {
        this.validSearchInput = true;
      }
    } else {
      this.loadingMask.disableLoadingMask();
      return;
    }
    if (this.searchObj.searchTerm.value && this.validSearchInput) {
      this.resetCatalogPageCount();
      this.loadResponseData();
    }
  }

  loadResponseData() {
    // this.sortObj.sortParamsObj = {};
    this.contentSubscription = this.getCatalogContentObservable().subscribe(
      data => {
        this.loadingMask.disableLoadingMask();
        let activeTabContent;
        const modifiedData = this.modifySubscribedCatalogData(data);
        if (this.searchObj.pageCount === 1) {
          activeTabContent = modifiedData[this.getCurrentContentIndex()];
          this.searchResults = modifiedData;
          this.setActiveFilters();
          this.applicationRef.tick();
        } else {
          activeTabContent = modifiedData;
          this.searchResults[this.getCurrentContentIndex()].contentResult.push(...modifiedData['contentResult']);
          this.searchResults = _.clone(this.searchResults);
          this.applicationRef.tick();
        }
        this.totalResultsFound = activeTabContent['totalHits'] === undefined ? 0 : parseInt(activeTabContent['totalHits']);
        this.setPersistSearchResponse();
        this.isLoadingData = false;
      },
      error => {
        this.loadingMask.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        console.log('error:', error);
      }
    );
  }

  modifySubscribedCatalogData(data) {
    if (data[3] && data[3].brandsResult) {
      const filteredBrands = data[3].brandsResult.filter(brand => (brand.name.toLowerCase() !== 'n/a' && brand.name.toLowerCase() !== 'na'));
      if (data[3].brandsResult.length > filteredBrands.length) {
        data[3].totalHits -= (data[3].brandsResult.length - filteredBrands.length);
        data[3].brandsResult = filteredBrands;
      }
    }
    return data;
  }

  setActiveFilters() {
    const currentTabContent = this.searchResults[this.catalogService.getCatalogContentIndex(this.activeCatalogTab)];
    this.advancedFilterObj = {
      availableSeries: currentTabContent['availableSeries'],
      availableBrands: currentTabContent['availableBrands'],
      availableSeasons: _.sortBy(currentTabContent['availableSeasons'], (season) => {
        return season['seasonNumber'];
      })
    };
  }

  getCatalogContentObservable() {
    if (this.searchObj.pageCount === 1) {
      return forkJoin([
        this.catalogService.getItems(this.searchObj, this.searchObj.pageCount, 'episode'),
        this.catalogService.getItems(this.searchObj, this.searchObj.pageCount, 'series'),
        this.catalogService.getItems(this.searchObj, this.searchObj.pageCount, 'event'),
        this.catalogService.getItems(this.searchObj, this.searchObj.pageCount, 'brands')
      ]);
    } else {
      return this.catalogService.getItems(this.searchObj, this.searchObj.pageCount, this.activeCatalogTab.toLowerCase());
    }
  }


  loadMoreResponseData() {
    this.searchObj.pageCount++;
    this.loadResponseData();
  }

  switchContentType(contentType: string) {
    // if (this.activeCatalogTab !== contentType.toUpperCase()) {
    //   this.activeCatalogTab = contentType.toUpperCase();
    //   this.searchObj.searchType = contentType;
    //   this.setActiveFilters();
    //   this.totalResultsFound = this.searchResults[this.catalogService.getCatalogContentIndex(this.activeCatalogTab)].totalHits;
    //   if (this.activeCatalogTab !== 'BRAND') {
    //     this.searchObj.pageCount = this.getCurrentTabPageCount();
    //   }
    // }
    if (this.activeCatalogTab !== contentType.toUpperCase()) {
      if (this.contentSubscription) {
        this.contentSubscription.unsubscribe();
      }
      this.activeCatalogTab = contentType.toUpperCase();
      this.searchObj.searchType = contentType;
      // this.setActiveFilters();
      // this.totalResultsFound = this.searchResults[this.catalogService.getCatalogContentIndex(this.activeCatalogTab)].totalHits;
      this.searchObj.pageCount = 1;
      this.resetFilters();
      this.loadResponseData();
      // if (this.activeCatalogTab !== 'BRAND') {
      // this.searchObj.pageCount = this.getCurrentTabPageCount();
      // }
    }
  }

  getCurrentTabPageCount(): number {
    const contentLength = this.searchResults[this.getCurrentContentIndex()].contentResult.length;
    if (contentLength <= 50) {
      return 1;
    } else {
      return ((contentLength - 50) / 25) + 1;
    }
  }

  getCurrentContentIndex(): number {
    return this.catalogService.getCatalogContentIndex(this.activeCatalogTab);
  }

  getPersistSearchResponse() {
    const catalogPersistedObj = this.storageService.getCatalogObjFromLocal();
    if (catalogPersistedObj !== null) {
      this.searchObj.searchTerm.setValue(catalogPersistedObj.searchObj.searchTerm, { emitEvent: false });
      this.searchObj.brandNameFilters = catalogPersistedObj.searchObj.brandNameFilters;
      this.searchObj.seriesTitleFilters = catalogPersistedObj.searchObj.seriesTitleFilters;
      this.searchObj.seasonNumberFilters = catalogPersistedObj.searchObj.seasonNumberFilters;
      this.searchObj.pageCount = catalogPersistedObj.searchObj.pageCount;
      this.searchValue = this.searchObj.searchTerm.value;
      this.numberOfFilters = catalogPersistedObj.numberOfFilters;
      this.activeCatalogTab = catalogPersistedObj.activeTab || 'EPISODE';
      // this.sortObj = catalogPersistedObj.sortObj;
    }
    this.loadingMask.disableLoadingMask();
  }


  setPersistSearchResponse() {
    let catalogPersistenceObj;
    catalogPersistenceObj = {
      'searchObj': {
        searchTerm: '',
        pageCount: this.searchObj.pageCount,
        brandNameFilters: this.searchObj.brandNameFilters,
        seriesTitleFilters: this.searchObj.seriesTitleFilters,
        seasonNumberFilters: this.searchObj.seasonNumberFilters
      },
      'numberOfFilters': this.numberOfFilters,
      'activeTab': this.activeCatalogTab
      // 'sortObj': {
      //   'sortParamsObj': this.sortObj.sortParamsObj,
      //   'currentSortSelection': this.sortObj.currentSortSelection
      // }
    };
    catalogPersistenceObj.searchObj.searchTerm = this.searchObj.searchTerm.value;
    this.storageService.setCatalogObjToLocal(catalogPersistenceObj);
  }


  resetFiltersCount() {
    this.numberOfFilters[0] = 5;
    this.numberOfFilters[1] = 5;
    this.numberOfFilters[2] = 5;
    this.numberOfFilters[3] = 5;
  }

  resetCatalogPageCount() {
    this.searchObj.pageCount = 1;
  }

  changeFiltersCount() {
    if (this.numberOfFilters[0] !== 5) {
      this.numberOfFilters[0] = this.advancedFilterObj.availableBrands.length;
    }
    if (this.numberOfFilters[1] !== 5) {
      this.numberOfFilters[1] = this.advancedFilterObj.availableSeries.length;
    }
    if (this.numberOfFilters[2] !== 5) {
      this.numberOfFilters[2] = this.advancedFilterObj.availableSeasons.length;
    }
  }

  composeCreateOrderModal(payload) {
    this.orderInfoObj = payload;
  }

  createNewOrderPayload() {
    if (this.orderInfoObj['orderType'] === 'video') {
      this.catalogService.createVideoOrder(this.orderName, this.orderInfoObj['orderVmid'], this.orderInfoObj['orderContentType'], this.isFullEpisode, []);
    } else {
      this.catalogService.createNonVideoOrder(this.orderName, this.orderInfoObj['orderVmid'], this.orderInfoObj['orderContentType'], this.orderInfoObj['orderType']);
    }
  }

  openContentRegistryDialog(): void {
    this.matDialog.open(this.contentRegistryDialog, {
      width: '560px',
      height: '350px'
    });
  }

  actionOnOpen() {
    this.orderName = '';
    const elem = this.input.nativeElement;
    setTimeout(() => {
      elem.focus();
    }, 250);
  }

  jumpToTop() {
    window.scroll({
      top: 0,
      behavior: 'smooth'
    });
  }

  ngOnDestroy() {
    if (this.contentSubscription) {
      this.contentSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
    this.loadingMask.disableLoadingMask();
  }
}
