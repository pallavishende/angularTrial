import { Component, OnInit, OnDestroy, ViewChild, Input, Output, EventEmitter, Renderer2, ElementRef } from '@angular/core';
import { MatSidenav } from '@angular/material';
import * as _ from 'lodash';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-content-panel',
  templateUrl: './content-panel.component.html',
  styleUrls: ['../search.component.scss', '../../catalog-base/catalog-base.component.scss', './content-panel.component.scss']
})
export class ContentPanelComponent implements OnInit, OnDestroy {

  @ViewChild('sidenav') public sideNav: MatSidenav;
  @ViewChild('orderTitle') input: ElementRef;
  @Output() sideNavRef = new EventEmitter<any>();
  @Output() seasonDetails = new EventEmitter<any>();
  @Output() createNewOrder = new EventEmitter<any>();
  @Input('serviceRef') serviceRef: any;

  subscriptions = new Subscription();
  seriesDetails: any;
  seasonContentDetails: any;
  seasonDetailsArr: Array<{
    showSeasonDetails: boolean,
    seasonDetails: any
  }> = [];
  seasonEpisodeArr = [];
  brandName = '';
  seriesName = '';
  seasonNumber;

  constructor(
    private renderer: Renderer2
  ) { }

  ngOnInit() {
    /**
     * subscribing to navbar toggle event, series and season data
     */
    this.subscriptions.add(this.serviceRef.sideNavSubject.subscribe(() => {
      const sidenavContainer = document.getElementById('sidenav-container');
      this.renderer.addClass(sidenavContainer, 'right-aligned');
      this.sideNav.open();
    }));
    this.subscriptions.add(this.serviceRef.seriesDetailSubject.subscribe((data) => {
      this.seriesDetails = data;
      this.brandName = this.seriesDetails['brand'];
      if (this.brandName.toLowerCase() === 'n/a' || this.brandName.toLowerCase() === 'na') {
        this.brandName = 'No Brand / Acquired';
      }
      this.seriesName = this.seriesDetails['title'];
      _.forEach(this.seriesDetails.seasons, (season, index) => {
        this.seasonDetailsArr[index] = {
          showSeasonDetails: false,
          seasonDetails: {}
        };
      });
    }));
    this.subscriptions.add(this.serviceRef.seasonDetailSubject.subscribe(
    (data) => {
      this.seasonContentDetails = data;
      const seasonIndex = _.indexOf(this.seriesDetails.seasons, _.find(this.seriesDetails.seasons, (season) => {
        if (season['vmid'] === data.contentDetails.vmid) {
          return season;
        }
      }));
      this.seasonDetailsArr[seasonIndex] = {
        showSeasonDetails: true,
        seasonDetails: data.contentDetails
      };
    }));
  }

  onSidenavClose() {
    const sidenavContainer = document.getElementById('sidenav-container');
    this.renderer.removeClass(sidenavContainer, 'right-aligned');
    this.seriesDetails = undefined;
    this.seasonContentDetails = undefined;
  }

  toggleSeasonView(index: number, seasonVmid: string) {
    if (this.seasonDetailsArr[index].showSeasonDetails) {
      this.seasonDetailsArr[index].showSeasonDetails = false;
    } else {
      this.getSeasonDetails(seasonVmid);
      this.seasonDetailsArr[index].showSeasonDetails = true;
    }
  }

  getSeasonDetails(seasonVmid: string) {
    this.seasonContentDetails = [];
    this.seasonDetails.emit({ seriesVmid: this.seriesDetails.vmid, seasonVmid: seasonVmid });
  }

  emitOrderPayload(contentType, orderType, lineItem) {
    const payload = {};
    payload['orderVmid'] = lineItem.vmid;
    payload['orderType'] = orderType;
    payload['orderContentType'] = contentType;

    payload['brandTitle'] = this.brandName;
    payload['seriesTitle'] = this.seriesName;
    if (contentType === 'SEASON') {
      payload['seasonNumber'] = this.seasonNumber;
    } else if (contentType === 'EPISODE') {
      payload['seasonNumber'] = this.seasonNumber;
      payload['episodeNumber'] = lineItem.episodeNumber;
      payload['episodeTitle'] = lineItem.title;
    }
    this.createNewOrder.emit(payload);
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
