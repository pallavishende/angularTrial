import { Injectable, EventEmitter } from '@angular/core';
import { MatSidenav } from '@angular/material';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class ContentPanelService {

  public sideNavSubject = new Subject<any>();
  public seriesDetailSubject = new Subject<any>();
  public seasonDetailSubject = new Subject<any>();

  constructor() { }
}
