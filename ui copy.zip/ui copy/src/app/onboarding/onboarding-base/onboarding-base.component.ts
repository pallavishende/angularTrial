import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onboarding-base',
  templateUrl: './onboarding-base.component.html',
  styleUrls: ['./onboarding-base.component.scss']
})
export class OnboardingBaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
