import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { UserService } from '../../services/user.service';

@Component({
  selector: 'complete-setup-modal',
  templateUrl: './complete-setup-modal.component.html',
  styleUrls: ['./complete-setup-modal.component.scss']
})
export class CompleteSetupModalComponent implements OnInit {

  @ViewChild('newUserModal') newUserModal;

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit() {
    if (this.userService.isNewUser) {
      this.newUserModal.open();
    }
  }

  navigateToUserGuide() {
    this.userService.isNewUser = false;
    this.router.navigateByUrl('/user-guide');
  }

  onModalClose(): void {
    this.userService.isNewUser = false;
  }

}
