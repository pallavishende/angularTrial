import { Injectable } from '@angular/core';
import { Headers, Response, RequestOptions, RequestOptionsArgs } from '@angular/http';
import { Title } from '@angular/platform-browser';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { ConfigService } from '../services/config.service';
import { HttpClient } from '@angular/common/http';

const userNotificationPreferenceIds = [2051, 2052, 3451, 3351, 2101, 2053, 2102, 2054, 3453];

@Injectable()
export class UserPreferencesService {

  constructor(private authHttp: HttpClient, private title: Title, private configService: ConfigService) { }

  getUserNotificationPreference(userId: number) {
      return this.authHttp.get(this.configService.updUrl + userId + '/notifications/preferences')
      .map((response: any) => response);
  }

  updateUserNotificationPreference(userId: number, notificationIds: number[]) {
    const header = new Headers();
    header.append('Content-type', 'application/json');
    return this.authHttp.put(this.configService.updUrl + userId + '/notifications/' + notificationIds.toString(), {});
  }

  updateAllUserNotificationPreferences(userId: number) {
    let header = new Headers();
    header.append('Content-type', 'application/json');
    return this.authHttp.put(this.configService.updUrl + userId + '/notifications/' + userNotificationPreferenceIds.toString(), {});
  }

  resetUserNotificationPreference(userId: number) {
    let header = new Headers();
    header.append("Content-type", "application/json");
    return this.authHttp.put(this.configService.updUrl + userId + '/notifications/reset', {});
  }

  setOrdersPageTitle(title: string) {
    this.title.setTitle(title);
  }

}
