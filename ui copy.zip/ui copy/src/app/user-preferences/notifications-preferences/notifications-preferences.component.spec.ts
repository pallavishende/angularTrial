import { async, ComponentFixture, TestBed, fakeAsync, tick  } from '@angular/core/testing';
import { AdalService } from 'ng2-adal/dist/core';
import { HttpClient } from '@angular/common/http';
import { Http, ConnectionBackend, RequestOptions, BaseRequestOptions } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { MockBackend } from '@angular/http/testing';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import { NotificationsPreferencesComponent } from './notifications-preferences.component';
import { UserPreferencesService } from '../user-preferences.service';
import { UserService } from '../../services/user.service';
import { ConfigService } from '../../services/config.service';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';
import { LoginService } from '../../login/login.service';
import { SecretService } from '../../services/secret.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service'


xdescribe('NotificationsPreferencesComponent', () => {
  let component: NotificationsPreferencesComponent;
  let fixture: ComponentFixture<NotificationsPreferencesComponent>;
  let element, debugElem;

  let mockUserPreferenceService = {
    getUserNotificationPreference() {
      return {
        data: [
          {
            id: 2051,
            isSelected: true,
            name: 'Mock Preference1',
            notificationType: 'ACTIVITY_ASSIGNED'
          },
          {
            id: 2052,
            isSelected: false,
            name: 'Mock Preference2',
            notificationType: 'ORDER_CANCELLED'
          }
        ]
      };
    }
  };

  let mockLoginService = {
    getUserInfo() {
      return {
        id: '1111',
        displayName: 'User Name'
      };
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientModule, RouterTestingModule ],
      declarations: [ NotificationsPreferencesComponent ],
      providers: [ UserService,
                   ConfigService,
                   EnvironmentService,
                   LoginService,
                   SecretService,
                   SystemAlertsService,
                   LoadingMaskService,
                   ConfigurationManagerService,
                   ConnectionBackend,
                   MockBackend,
                   HttpClient,
                   { provide: UserPreferencesService, useValue: mockUserPreferenceService },
                   { provide: LoginService, useValue: mockLoginService },
                   BaseRequestOptions,
                   AdalService ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotificationsPreferencesComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;     // to access DOM elements
    debugElem = fixture.debugElement;    // test helper
    fixture.detectChanges();
  });

  it('should create notification preferences component', () => {
    let app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should be able to access the input elements from DOM', () => {
    expect(component.notificationPreferenceRef).toBeDefined();
  });

  it('should have ngOnInit defined and getUsers must be called on init', () => {
    spyOn(component, 'getUsers');
    component.ngOnInit();
    expect(component.getUsers).toHaveBeenCalled();
  });

  it('should have User Preferences subscription defined', async(() => {
    let prefsService = TestBed.get(UserPreferencesService);

    let results = {
      data: [
          {
            id: 2051,
            isSelected: true,
            name: 'Mock Preference1',
            notificationType: 'ACTIVITY_ASSIGNED'
          },
          {
            id: 2052,
            isSelected: false,
            name: 'Mock Preference2',
            notificationType: 'ORDER_CANCELLED'
          }
        ]
    }
    spyOn(mockUserPreferenceService, 'getUserNotificationPreference').and.callFake((preferencesObj) => {
      return Observable.of(results);
    });
    component.userPreferences = mockUserPreferenceService.getUserNotificationPreference()['value'];
    component.getUserNotificationPreference();
    expect(component.userPreferences).toEqual(results);
  }));

  it('should get the user information by getUserInfo method', () => {
    let loginService = TestBed.get(LoginService);
    let loginInfo = {
                      id: '1111',
                      displayName: 'User Name'
                    };
    spyOn(mockLoginService, 'getUserInfo').and.callFake((loginInfo) => {
      return loginInfo;
    });
    component.userName = loginService.getUserInfo()['displayName'];
    expect(component.userName).toEqual('User Name');
  });

  it('should get the user notification preferences by getUserNotificationPreference method', () => {
    let loginService = TestBed.get(LoginService);
    let UserPrefs = [
                      { id: 2051,
                        isSelected: true,
                        name: 'An activity has been asssigned to me',
                        notificationType: 'ACTIVITY_ASSIGNED' }
                    ];
    spyOn(mockUserPreferenceService, 'getUserNotificationPreference').and.returnValue(Observable.of
    (UserPrefs));
    component.userPreferences = UserPrefs;
    component.getUserNotificationPreference();
    expect(component.userPreferences).toEqual(UserPrefs);
  });

  it('should invoke updateUserPreferences() method when "Update" button is clicked', async(() => {
    let updateButton = fixture.debugElement.nativeElement.querySelector('button');
    spyOn(component, 'updateUserPreferences');
   updateButton.click();
    fixture.whenStable().then(() => {
      expect(component.updateUserPreferences()).toHaveBeenCalled();
    });
  }));

  it('should invoke settingsModified() method and add index to modifiedPreferencesId array if its not already there, remove it otherwise', () => {
    let UserPrefs = [
                      { id: 2051,
                        isSelected: true,
                        name: 'An activity has been asssigned to me',
                        notificationType: 'ACTIVITY_ASSIGNED' }
                    ];

    component.userPreferences = UserPrefs;
    expect(component.modifiedPreferencesId.length).toEqual(0);
    component.settingsModified(0);
    expect(component.modifiedPreferencesId.length).toEqual(1);
    component.settingsModified(0);
    expect(component.modifiedPreferencesId.length).toEqual(0);
  });

});
