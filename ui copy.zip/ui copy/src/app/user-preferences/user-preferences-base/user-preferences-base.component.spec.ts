import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { UserPreferencesBaseComponent } from './user-preferences-base.component';
import { AuthHttp }from 'ng2-adal/dist/core'; 

describe('UserPreferencesBaseComponent', () => {
  let component: UserPreferencesBaseComponent;
  let fixture: ComponentFixture<UserPreferencesBaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      declarations: [ UserPreferencesBaseComponent ],
      providers: [ AuthHttp ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPreferencesBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
