import { Component, OnInit } from '@angular/core';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-user-preferences-base',
  templateUrl: './user-preferences-base.component.html',
  styleUrls: ['./user-preferences-base.component.scss']
})
export class UserPreferencesBaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
