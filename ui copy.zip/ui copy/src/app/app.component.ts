import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd, Event, RouteConfigLoadStart, RouteConfigLoadEnd } from '@angular/router';
import { SystemAlertsService } from './services/system-alerts.service';
import { ToasterService, ToasterConfig, BodyOutputType } from 'angular2-toaster';
import { ConfigService } from './services/config.service';
import { UserService } from './services/user.service';
import { LoginService } from './login/login.service';
import { StorageService } from './services/storage.service';
import { LoadingMaskService } from './shared/loading-mask/loading-mask.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
  alertObject;

  // for configuration options, see: https://github.com/Stabzs/Angular2-Toaster
  public toasterconfig: ToasterConfig =
  new ToasterConfig({
    showCloseButton: true,
    tapToDismiss: false,
    timeout: 5000,
    bodyOutputType: BodyOutputType.TrustedHtml,
    positionClass: 'toast-top-center',
    limit: 1,
    mouseoverTimerStop: true
  });

  constructor(
    private alerts: SystemAlertsService,
    private router: Router,
    private loadingMask: LoadingMaskService,
    private toasterService: ToasterService,
    private loginService: LoginService,
    private storageService: StorageService,
  ) {
    this.toasterService = toasterService;
    this.loginService.initialize();
    this.storageService.enableLastUrlPersistence();
  }

  ngOnInit() {
    this.loginService.handleWindowCallback();
    this.alerts.alertsStream.subscribe(
      data => {
        this.alertObject = data;
        this.toasterService.pop(this.alertObject.type, null, this.alertObject.messege);
      }
    );
    this.router.events.subscribe((event: Event) => {
      if (event instanceof RouteConfigLoadStart) {
        this.loadingMask.enableLoadingMask();
      } else if (event instanceof RouteConfigLoadEnd) {
        this.loadingMask.disableLoadingMask();
      }
      if (!(event instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
    this.storageService.navigateToLastUrlIfAvailable();
    this.disableDragAndDrop();
  }

/**
 * disabling browser default dragging and dropping of files to open in
 * the browser window. Drag and drop functiinality is taken care by
 * file-uploader component in shared directory.
 */
  disableDragAndDrop() {
    window.addEventListener('dragover', (event) => {
      event && event.preventDefault();
    }, false);
    window.addEventListener('drop', event => {
      event && event.preventDefault();
    }, false);
  }

}
