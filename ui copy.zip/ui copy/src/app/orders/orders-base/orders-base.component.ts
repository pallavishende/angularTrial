import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders-base',
  templateUrl: './orders-base.component.html',
  styleUrls: ['./orders-base.component.scss']
})
export class OrdersBaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
