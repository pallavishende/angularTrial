import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import { OrderStore } from '../../models/order-store';
import { OrdersService } from '../orders/orders.service';
import { OrderDetailsScheduleService } from '../order-details-schedule/order-details-schedule.service';
import { LineItem } from '../../models/line-item';
import { Activity } from '../../models/activity';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { EnvironmentService } from '../../services/environment.service';
import * as _ from 'lodash';

const orderInstructionsFormFields = require('../../models/mock-payloads/order-instructions-form-fields.json');
const orderPublishingFormFields = require('../../models/mock-payloads/order-publishing-form-fields.json');
const orderVideoCopyFormFields = require('../../models/mock-payloads/order-video-copy-form-fields.json');
const orderGraphicsFormFields = require('../../models/mock-payloads/order-graphic-request-instructions.json');

@Injectable()
export class OrderProgressTrackerService {
  order;
  routeData;
  isSubmitReady = false;
  isPreviousCompleted = true;
  isNavigationDisabled = false;
  isEnvGreaterThanUAT = false;
  defaultOptions = [
    {
      step: 'endpoint', stepReady: false,
      section: 'platform-progress', stepCompleted: false,
      orderType: ['video']
    },
    {
      step: 'instructions', stepReady: false,
      section: 'format-progress', stepCompleted: false,
      orderType: ['video', 'copy', 'graphics', 'site_app_updates']
    },
    // {
    //   step: 'package', stepReady: false,
    //   section: 'package-progress', stepCompleted: false,
    //   orderType: ['video']
    // },
    /*{
      step: 'approval', stepReady: false,
      section: 'approval-progress', stepCompleted: false,
      orderType: ['video', 'copy', 'graphics']
    },*/
    {
      step: 'schedule', stepReady: false,
      section: 'schedule-progress', stepCompleted: false,
      orderType: ['video', 'copy', 'graphics', 'site_app_updates']
    },
    {
      step: 'review', stepReady: false,
      section: 'review-progress', stepCompleted: false,
      orderType: ['video', 'copy', 'graphics', 'site_app_updates']
    },
    {
      step: 'submit', stepReady: false,
      section: 'NA', stepCompleted: false,
      orderType: ['video', 'copy', 'graphics', 'site_app_updates']
    }
  ];

  constructor(
    private orderStore: OrderStore,
    private router: Router,
    private ordersService: OrdersService,
    private orderDetailsScheduleService: OrderDetailsScheduleService,
    private loadingMask: LoadingMaskService,
    private systemAlertsService: SystemAlertsService,
    private environmentService: EnvironmentService
  ) {
    this.isEnvGreaterThanUAT = this.environmentService.isRuntimeEnvironmentGreaterThan(3);
  }

  get() {
    return this.orderStore.orderStream;
  }

  getOrderStore() {
    return this.orderStore;
  }

  getDefaultOptions() {
    return this.defaultOptions;
  }

  isFound(list, toMatch) {
    return _.find(list, function (item) {
      return item === toMatch;
    });
  }

  getFormatActivity(item: LineItem) {
    return _.find(item.activities, { 'typeId': 1 });
  }

  validateLineItems(lineItems) {
    const customProgression = {
      platform: [],
      format: [],
      approval: [],
      schedule: [],
      review: 0
    };
    const localIsFound = this.isFound;  // keep ref
    let isNavigationStatusModified = false;
    if (lineItems.length <= 0) {
      return customProgression;
    }
    _.forEach(lineItems, (lineItem: LineItem) => {
      // platform validation
      if (_.hasIn(lineItem, 'customConfig.endpoint') && _.get(lineItem, 'customConfig.endpoint') !== '') {
        if (lineItem['metadata'][0]['clipId'] !== null && lineItem['metadata'][0]['clipId'] !== '') {
          if (!localIsFound(customProgression.platform, lineItem['metadata'][0]['clipId'])) {
            customProgression.platform.push(lineItem['metadata'][0]['clipId']);
          }
        } else {
          if (!localIsFound(customProgression.platform, lineItem['metadata'][0]['clipTitle'])) {
            customProgression.platform.push(lineItem['metadata'][0]['clipTitle']);
          }
        }
      }

      // format validation
      let videoActivityObj: Activity;
      let hasAllRequiredFields = true;
      videoActivityObj = _.find(lineItem.activities, (activity) => {
        return activity['typeId'] === 1;
      });

      if (lineItem['publishInstructionsMetadata']) {
        for (const key in orderPublishingFormFields) {
          if (orderPublishingFormFields.hasOwnProperty(key)) {
            if (key === 'adTargeting' && lineItem['publishInstructionsMetadata'][key] && lineItem['publishInstructionsMetadata'][key][0].trim() === '') {
              hasAllRequiredFields = false;
            } else {
              if (orderPublishingFormFields[key].isRequiredField &&
              (!lineItem['publishInstructionsMetadata'][key] || lineItem['publishInstructionsMetadata'][key].length === 0 || (lineItem['publishInstructionsMetadata'][key][0] && lineItem['publishInstructionsMetadata'][key][0].trim() === ''))) {
                hasAllRequiredFields = false;
                break;
              }
            }
          }
        }
      }

      if (lineItem['videoCopyInstructionsMetadata']) {
        for (const key in orderVideoCopyFormFields) {
          if (orderVideoCopyFormFields.hasOwnProperty(key)) {
            if (orderVideoCopyFormFields[key].isRequiredField) {
              if (!lineItem['videoCopyInstructionsMetadata'][key]) {
                hasAllRequiredFields = false;
                break;
              } else if (lineItem['videoCopyInstructionsMetadata'][key][0].trim() === '') {
                hasAllRequiredFields = false;
                break;
              }
            }
            if (orderVideoCopyFormFields[key].charLimit && lineItem['videoCopyInstructionsMetadata'][key]) {
              if (lineItem['videoCopyInstructionsMetadata'][key][0].length > orderVideoCopyFormFields[key].charLimit) {
                hasAllRequiredFields = false;
                break;
              }
            }
          }
        }
      }

      if (lineItem['videoInstructionsMetadata']) {
        // if current version type need caption field
        if (lineItem['videoInstructionsMetadata']['versionType'] && lineItem['videoInstructionsMetadata']['versionType'][0]
        && orderInstructionsFormFields['captions'].permittedVersionType.indexOf(lineItem['videoInstructionsMetadata']['versionType'][0]) > -1) {
          if (!lineItem['videoInstructionsMetadata']['captions'] || !lineItem['videoInstructionsMetadata']['captions'][0]) {
            hasAllRequiredFields = false;
          }
          if (lineItem['videoInstructionsMetadata']['captions'] && lineItem['videoInstructionsMetadata']['captions'].indexOf('Deliver/include transcript file') > -1) {
            if (!lineItem['videoInstructionsMetadata']['budgetCode']) {
              hasAllRequiredFields = false;
            } else if (!lineItem['videoInstructionsMetadata']['budgetCode'][0]) {
              hasAllRequiredFields = false;
            } else if (lineItem['videoInstructionsMetadata']['budgetCode'][0].trim() === '') {
              hasAllRequiredFields = false;
            }
          }
        }
        // if no file drop off location
        if (!lineItem['videoInstructionsMetadata']['fileDropOffLocation'] || !lineItem['videoInstructionsMetadata']['fileDropOffLocation'][0]) {
          hasAllRequiredFields = false;
        }
        // if selected slates and graphics, slates and graphics source info is thus neccessary
        if (lineItem['videoInstructionsMetadata']['slatesAndGraphics'] && lineItem['videoInstructionsMetadata']['slatesAndGraphics'].length > 0) {
          if (!lineItem['videoInstructionsMetadata']['slatesAndGraphicsSourceInfo']) {
            hasAllRequiredFields = false;
          }
        }
      } else {
        hasAllRequiredFields = false;
      }

      if (_.get(videoActivityObj, 'input.isUploading')) {
        this.isNavigationDisabled = true;
        isNavigationStatusModified = true;
      }
      if (_.hasIn(lineItem, 'customConfig.version')
        && (_.get(lineItem, 'customConfig.version')).toString().replace(/&nbsp;|\s/g, '') !== ''
        && hasAllRequiredFields
      ) {
        if (lineItem['metadata'][0]['clipId'] !== '') {
          customProgression.format.push(lineItem['metadata'][0]['clipId']);
        } else {
          customProgression.format.push(lineItem['metadata'][0]['clipTitle']);
        }
      } else {
        customProgression.format = [];
      }

      // schedule validation
      if (_.hasIn(lineItem, 'publishDateTime') && _.get(lineItem, 'publishDateTime') !== ''
        && this.orderDetailsScheduleService.isValidDate(_.get(lineItem, 'dueDateTime'), _.get(lineItem, 'publishDateTime'))
        && !this.orderDetailsScheduleService.isPast(_.get(lineItem, 'dueDateTime'))
        && !this.orderDetailsScheduleService.isPast(_.get(lineItem, 'publishDateTime'))
      ) {
        if (lineItem['metadata'][0]['clipId'] !== '') {
          customProgression.schedule.push(lineItem['metadata'][0]['clipId']);
        } else {
          customProgression.schedule.push(lineItem['metadata'][0]['clipTitle']);
        }
      } else {
        customProgression.schedule = [];
      }
    });

    if (!isNavigationStatusModified) {
      this.isNavigationDisabled = false;
    }
    return customProgression;
  }

  generateOrderProgress(lineItems, lineItemsClipId, orderType?: string) {
    if (orderType !== 'video' && typeof orderType !== 'undefined') {
      return this.getNonVideoOrderProgress(lineItems, orderType);
    } else {
      const customProgression = this.validateLineItems(lineItems);
      const defOpt = this.defaultOptions; // maintain ref
      let isPreviousCompleted = true;

      // platform
      defOpt[0].stepReady = true;
      defOpt[0].stepCompleted = lineItemsClipId && lineItemsClipId.length > 0 && (customProgression.platform.length === lineItemsClipId.length);
      isPreviousCompleted = defOpt[0].stepCompleted;

      // format
      defOpt[1].stepReady = defOpt[0].stepCompleted;
      defOpt[1].stepCompleted = customProgression.format.length === lineItems.length && isPreviousCompleted;
      isPreviousCompleted = defOpt[1].stepCompleted;

      // schedule
      defOpt[2].stepReady = defOpt[1].stepCompleted;
      defOpt[2].stepCompleted = customProgression.schedule.length === lineItems.length && isPreviousCompleted;
      isPreviousCompleted = defOpt[2].stepCompleted;

      // review
      defOpt[3].stepReady = isPreviousCompleted;
      defOpt[3].stepCompleted = isPreviousCompleted;
      this.isSubmitReady = isPreviousCompleted;
      return this.defaultOptions;
    }
  }

  getNonVideoOrderProgress(lineItems, orderType) {
    const defOpt = this.defaultOptions; // maintain ref
    let isPreviousCompleted = true;
    
    // instructions
    // instructions page is optional for Copy Orders and required for Graphics Orders
    if (lineItems[0].activities[0].input.isUploading) {
      this.isNavigationDisabled = true;
    } else {
      this.isNavigationDisabled = false;
    }
    if (orderType === 'graphics') {
      defOpt[1].stepReady = true;
      defOpt[1].stepCompleted = lineItems[0].activities[0].description !== null
        && lineItems[0].activities[0].description.trim() !== '' && this.checkGraphicsForm(lineItems) && isPreviousCompleted;
      isPreviousCompleted = defOpt[1].stepCompleted;
    } else {
      defOpt[1].stepReady = true;
      defOpt[1].stepCompleted = true;
      isPreviousCompleted = defOpt[1].stepCompleted;
    }

    // schedule
    defOpt[2].stepReady = isPreviousCompleted;
    defOpt[2].stepCompleted = lineItems[0].dueDateTime && !this.orderDetailsScheduleService.isPast(lineItems[0].dueDateTime) && isPreviousCompleted;
    if (orderType === 'site_app_updates') {
      if(lineItems[0].launchDateTime === 'notValid' || lineItems[0].launchDateError) {
        lineItems[0].launchDateTime = '';
        defOpt[2].stepCompleted = false;
      } else if(lineItems[0].launchDateTime && defOpt[2].stepCompleted) {
        defOpt[2].stepReady = isPreviousCompleted;
        defOpt[2].stepCompleted = !this.orderDetailsScheduleService.isPast(lineItems[0].launchDateTime) && isPreviousCompleted
          && this.orderDetailsScheduleService.isValidDate(lineItems[0].dueDateTime, lineItems[0].launchDateTime);
      }
    } else if(orderType === 'graphics' && !this.isEnvGreaterThanUAT) {
        let request = lineItems[0].activities[0].instructions.filter(item => item.label === 'requestType')[0];
        if(request && request.values[0] === 'VMN') {
          defOpt[2].stepCompleted = !this.orderDetailsScheduleService.isPast(lineItems[0].dueDateTime) && 
          !this.orderDetailsScheduleService.isPast(lineItems[0].launchDateTime) && isPreviousCompleted
          && this.orderDetailsScheduleService.isValidDate(lineItems[0].dueDateTime, lineItems[0].launchDateTime)
          && this.checkForDueDateReason(lineItems);
        }
    }
    isPreviousCompleted = defOpt[2].stepCompleted;

    // review
    defOpt[3].stepReady = isPreviousCompleted;
    defOpt[3].stepCompleted = isPreviousCompleted;
    this.isSubmitReady = isPreviousCompleted;
    return this.defaultOptions;
  }

  checkGraphicsForm(lineItems) {
    let hasAllRequiredFields = true;
    let brand = lineItems[0].activities[0].instructions.filter(item => item.label === 'brand')[0];
    let request = lineItems[0].activities[0].instructions.filter(item => item.label === 'requestType')[0];
    if(request) {
      if(request.values[0] === 'VMN') {
        if(brand) {
          let platformList = lineItems[0].activities[0].instructions.filter((inst) => inst['label'] === 'platformList');
          if(platformList[0] && platformList[0].values.length > 0) {
            platformList[0].values.forEach(res => {
                if(res === 'CUSTOM') {
                  let resultCustom = lineItems[0].activities[0].instructions.findIndex((inst) => inst['type'] === res && inst['label'] === 'Description');
                  hasAllRequiredFields = hasAllRequiredFields && resultCustom >= 0 ? true : false;
                } else {
                  let result = lineItems[0].activities[0].instructions.filter((inst) => inst['type'] === res);
                  let brandObj = orderGraphicsFormFields.RequestType[res];
                  let count = 0;
                  let isCustomChecked = false;
                  
                  brandObj[0].options.forEach(obj => {
                    let optionsObj = result.filter(resl => resl.label === obj.key);
                    if(optionsObj.length > 0) {
                      isCustomChecked = optionsObj[0].label === 'Custom' ? true : false;
                      count++;
                    }
                  });
                  
                  if(count > 0 && hasAllRequiredFields) {
                    hasAllRequiredFields = true;
                  } else {
                    hasAllRequiredFields = false;
                  }
                  if(isCustomChecked) {
                    let resultCustom = lineItems[0].activities[0].instructions.findIndex((inst) => inst['type'] === res && inst['label'] === 'dimensions');
                    hasAllRequiredFields = resultCustom >= 0 && hasAllRequiredFields ? true : false;
                  } 
                }
              });
            } else {
              hasAllRequiredFields = false;
            }
          }
        
        if (lineItems[0]['graphicsInstructionsMetadata']) {
          if (!lineItems[0]['graphicsInstructionsMetadata']['noOfDelivarables'] || !lineItems[0]['graphicsInstructionsMetadata']['noOfDelivarables'][0]) {
            hasAllRequiredFields = false;
          }
        } else {
          hasAllRequiredFields = false;
        }
      } else {
        hasAllRequiredFields = true;
      }
    } 
    return hasAllRequiredFields;
  }

  checkForDueDateReason(lineItems) {
    let index = lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'dueDateReason');
    if(index >= 0) {
      if(lineItems[0].activities[0].instructions[index].values[0].length > 0) {
        return true;
      }
    } 
    return false; 
  }

  getLastCompletedOrderStep(lineItems, lineItemsClipId) {
    let route;
    const status = this.generateOrderProgress(lineItems, lineItemsClipId);
    for (let i = 0; i < status.length - 1; i++) {
      if (!this.defaultOptions[i].stepCompleted) {
        route = this.defaultOptions[i];
        break;
      }
    }
    return route || this.defaultOptions[3];
  }

  getLastCompletedNonVideoOrderStep(orderPayload) {
    let route;
    const status = this.generateOrderProgress(orderPayload.lineItems, orderPayload.lineItems, orderPayload.metadata.orderType.toLowerCase());
    for (let i = 0; i < status.length - 1; i++) {
      if (status[i].orderType.indexOf('graphics') > -1 || status[i].orderType.indexOf('copy') > -1) {
        if (!this.defaultOptions[i].stepCompleted) {
          if (i === 3 && orderPayload.metadata.orderType.toLowerCase() === 'copy') { // approvals page
            route = this.defaultOptions[1];  // if approvals step is not completed, route to the instructions page because its optional
          } else {
            route = this.defaultOptions[i];
          }
          break;
        }
      }
    }
    return route || this.defaultOptions[3];
  }

  isSubmitEnabled() {
    return this.isSubmitReady;
  }

  resetDefaultOptions() {
    _.forEach(this.defaultOptions, function (option) {
      option.stepReady = false;
      option.stepCompleted = false;
    });
  }

  updateOrder(orderData) {
    let tmp = _.cloneDeep(orderData);
    delete tmp.lineItemsClipId;
    delete tmp.groupedLineItemsByClipId;
    _.map(tmp.lineItems, (item) => {
      delete item['videoInstructionsMetadata'];
      delete item['publishInstructionsMetadata'];
      delete item['endpoint_info'];
      delete item['lineItemId'];
      delete item['format_description'];
      delete item['opened'];
      delete item['dateError'];
      delete item['n'];
      /**
       * setting inputs array from lineitem => activities of typeId 1 to an empty object
       */
      if (item['activities'] && item['activities'].length) {
        if (orderData.metadata.orderType === 'VIDEO') {
          const videoActivityIndex =
            _.indexOf(item['activities'], _.find(item['activities'], (activity) => {
              if (activity['typeId'] === 1) {
                return activity;
              }
            }));
          if (videoActivityIndex >= 0) {
            item['activities'][videoActivityIndex].input = {};
          }
        } else {
          if (item['activities'][0]) {
            item['activities'][0].input = {};
          }
        }
      }
    });
    return this.ordersService.modifyOrder(tmp.id, tmp);
  }

  saveOrder(order, alertMsg?: string, onComplete?) {
    this.loadingMask.enableLoadingMask();
    this.updateOrder(order)
      .subscribe(
      data => {
        this.getOrderStore().loadInitialModel(data);
        if (alertMsg && alertMsg.length > 0) {
          this.systemAlertsService.addSuccessAlerts(alertMsg);
        }
        if (order['lineItems'].length === 0) {
          this.router.navigate(['/orders/' + order.id + '/draft/endpoint']);
        }
        this.ordersService.getOrder(order.id).subscribe(
          updatedData => {
            this.loadingMask.disableLoadingMask();
            this.orderStore.loadInitialModel(updatedData, updatedData.metadata.orderType);
            if (onComplete) {
              onComplete();
            }
          },
          error => {
            console.log('Order could not be updated. error: ', error);
            this.loadingMask.disableLoadingMask();
            this.systemAlertsService.addErrorAlerts(
              'Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
            if (onComplete) {
              onComplete();
            }
          }
        );
      },
      error => {
        console.log('Order could not be submitted. error: ', error);
        this.loadingMask.disableLoadingMask();
        this.systemAlertsService.addErrorAlerts(
          'Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        if (onComplete) {
          onComplete();
        }
      }
      );
  }

  updateOrderName(order, name) {
    this.ordersService.updateOrderName(order.id, name).subscribe(
      data => {
        this.systemAlertsService.addSuccessAlerts('Order name has been updated successfully.');
        order.name = data.name;
      },
      error => {
        this.systemAlertsService.addErrorAlerts('Error: Order name could not be updated. Please try again');
      }
    );
  }

  submitOrder(orderId) {
    return this.ordersService.placeOrder(orderId);
  }

  saveRouteData(routeData) {
    this.routeData = routeData;
  }

  getRouteData() {
    return this.routeData;
  }

}
