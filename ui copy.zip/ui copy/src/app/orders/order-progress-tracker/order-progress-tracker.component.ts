import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, RouterStateSnapshot } from '@angular/router';
import 'rxjs/add/operator/map';
import { OrderProgressTrackerService } from './order-progress-tracker.service';
import { OrdersService } from '../orders/orders.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { OrderCustomizationBaseService } from '../order-customization-base/order-customization-base.service';
import { StorageService } from '../../services/storage.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { LineItem } from '../../models/line-item';
import { Activity } from '../../models/activity';
import { Order } from '../../models/order';
import { Subscription, Observable, Subject } from 'rxjs';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import * as _ from 'lodash';

@Component({
    selector: 'app-order-progress-tracker',
    templateUrl: './order-progress-tracker.component.html',
    styleUrls: ['./order-progress-tracker.component.scss']
})

export class OrderProgressTrackerComponent implements OnInit, OnDestroy {
    trackerOptions = [];
    orderRoute;
    orderId;
    isFirst: boolean;
    isLast: boolean;
    isNextStepEnabled: boolean;
    currentRouteIndex: number;
    orderData;
    validationCompleted: Boolean = false;
    subscriptions = new Subscription();

    constructor(
        private orderProgressTrackerService: OrderProgressTrackerService,
        private ordersService: OrdersService,
        private router: Router,
        private alerts: SystemAlertsService,
        private orderCustomizationBaseService: OrderCustomizationBaseService,
        private loadingMask: LoadingMaskService,
        private storageService: StorageService
    ) {
        this.alerts = alerts;
    }

    ngOnInit() {
        const snapshot: RouterStateSnapshot = this.router.routerState.snapshot;
        this.orderId = snapshot.url.substring(8, snapshot.url.indexOf('/draft'));
        this.trackerOptions = this.orderProgressTrackerService.getDefaultOptions();
        this.subscriptions.add(this.orderProgressTrackerService.get().subscribe(
            data => {
                if (data['id'] && data['id'].toString() === this.orderId) {
                    this.orderData = data;
                    const routeData = this.orderProgressTrackerService.getRouteData();
                    if (this.getUniqueLineItems().length > 0 && routeData) {
                        this.orderRoute = routeData.section;
                        const progressItems = this.orderProgressTrackerService.generateOrderProgress(data.lineItems, this.getUniqueLineItems(), this.orderData.metadata.orderType.toLowerCase());
                        this.currentRouteIndex = _.findIndex(progressItems, ['step', this.orderRoute]);
                        this.isFirst = this.isFirstStepOfOrderCustomization();
                        this.isLast = this.isLastStepOfOrderCustomization();
                        if (this.trackerOptions[this.currentRouteIndex].stepCompleted === true) {
                            this.isNextStepEnabled = true;
                        } else {
                            this.isNextStepEnabled = false;
                        }
                    } else {
                        this.orderProgressTrackerService.resetDefaultOptions();
                        this.orderRoute = ''; // this resets the highlight
                    }
                }
            },
            error => {
                this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
            }
        ));
    }

    isFirstStepOfOrderCustomization(): boolean {
        if (this.orderData.metadata.orderType.toLowerCase() === 'video') {
            return this.orderRoute === 'endpoint';
        } else {
            return this.orderRoute === 'instructions';
        }
    }

    isLastStepOfOrderCustomization(): boolean {
        return this.orderRoute === 'review';
    }

    getUniqueLineItems() {
        let uniqueLineItemsByClipId = this.orderData.lineItemsClipId || this.orderData.lineItems;
        return uniqueLineItemsByClipId;
    }

    isSubmitEnabled() {
        return this.orderProgressTrackerService.isSubmitEnabled();
    }

    isStepEnabled(step) {
        const stepIndex = _.findIndex(this.trackerOptions, ['step', step]);
        if (step === this.orderRoute) {
            return false;
        } else {
            return this.trackerOptions[stepIndex].stepReady;
        }
    }

    isNavigationDisabled() {
        return this.orderProgressTrackerService.isNavigationDisabled;
    }

    goToStep(step) {
        this.loadingMask.enableLoadingMask();
        this.subscriptions.add(this.orderProgressTrackerService.updateOrder(this.orderData).subscribe(
            data => {
                if (step === 'instructions' && this.orderData.metadata.orderType.toLowerCase() === 'video') {
                    this.loadingMask.disableLoadingMask();
                } else {
                    this.orderCustomizationBaseService.initializeModel(this.orderData.id);
                }
                this.router.navigate(['/orders/' + this.orderId + '/draft/' + step]);
            },
            error => {
                console.log('Unable to save data');
                this.loadingMask.disableLoadingMask();
                this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
            }
        ));
    }

    handleOrderAndSubmit() {
        // TO BE REMOVED temporary flag for combined approval and publish
        this.orderData.metadata.isNewOrder = true;
        if (this.orderData.metadata.orderType === 'VIDEO') {
            _.forEach(this.orderData.lineItems, lineItem => {
                let composeVideoTask = _.find(lineItem.activities, activity => activity['typeId'] === 1);
                // TO BE REMOVED if has approve video task from old order drafts, remove it before submit
                if (composeVideoTask['subActivities'].length > 0) {
                    composeVideoTask['subActivities'] = [];
                }
            });
        }
        this.orderProgressTrackerService.updateOrder(this.orderData).subscribe(
            data => {
                this.ordersService.setLastSubmittedOrderId(this.orderId);
                this.subscriptions.add(this.orderProgressTrackerService.submitOrder(this.orderId).subscribe(
                    data => {
                        // TODO: update the last circle of progress tracker
                        this.alerts.addSuccessAlerts(`Your order has been submitted successfully.`);
                        this.storageService.resetOrdersObjInLocal();
                        this.validateSubmittedOrderStatus(data);
                    },
                    error => {
                        console.log('Order could not be submitted. error: ', error);
                        this.loadingMask.disableLoadingMask();
                        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
                    }
                ));
            },
            error => {
                this.loadingMask.disableLoadingMask();
                this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
            }
        );
    }

    submitOrder() {
        this.loadingMask.enableLoadingMask();
        this.handleOrderAndSubmit();
    }

    validateSubmittedOrderStatus(orderData): void {
        if (orderData['currentMilestone'].status === 'SUBMITTED') {
            // this.validateOrderData(orderData);
            this.navigateToOrderDetailsPage();
        } else {
            this.shortPollOrderData(orderData['id']).subscribe((data) => {
                // this.validateOrderData(orderData);
                this.navigateToOrderDetailsPage();
            });
        }
    }


/**
 * the following method will be depricated in the next push
 */
    validateOrderData(orderData): void {
        let orderTasks;
        let isOrderDataValid: boolean;
        let orderDetailsIntervalSubscription;

        orderDetailsIntervalSubscription = IntervalObservable.create(3000).subscribe((interval) => {
            this.ordersService.getOrderDetails(this.orderId).subscribe((orderData) => {
                orderTasks = this.getOrderTasks(orderData);
                _.forEach(orderTasks, (task: Activity, index: number) => {
                    if (typeof task['activityBundleId'] === 'undefined' || task['activityBundleId'] === null) {
                        isOrderDataValid = false;
                        return false;
                    } else if (index === orderTasks.length - 1) {
                        isOrderDataValid = true;
                    }
                });
                if (isOrderDataValid) {
                    orderDetailsIntervalSubscription.unsubscribe();
                    this.navigateToOrderDetailsPage();
                } else {
                    this.submitOrder();
                }
            });
        });
        this.subscriptions.add(orderDetailsIntervalSubscription);
    }

    /**
     * short polling for fetching order data so as to get
     * the latest data and trigger an action based on the
     * order current status.
     * @param orderId (number): id to fetch order data
     */
    shortPollOrderData(orderId: number): Observable<Order> {
        const orderDataShortPollingSubject = new Subject<Order>();
        let getOrderIntervalSubscription = new Subscription;
        getOrderIntervalSubscription = IntervalObservable.create(2000).subscribe(
            (interval) => {
                this.ordersService.getOrder(orderId).subscribe((orderData: Order) => {
                    if (orderData.currentMilestone.status !== 'DRAFT') {
                        getOrderIntervalSubscription.unsubscribe();
                        orderDataShortPollingSubject.next(orderData);
                    }
                },
                    (error) => {
                        console.log(`Error: couldn\'t fetch order data. Retrying..`);
                    });
            }
        );
        this.subscriptions.add(getOrderIntervalSubscription);
        return orderDataShortPollingSubject.asObservable();
    }

    getOrderTasks(orderData): Array<any> {
        const orderTasks = [];
        _.forEach(orderData.lineItems, (lineItem: LineItem) => {
            _.forEach(lineItem.activities, (activity) => {
                orderTasks.push(activity);
                if (activity.subActivities && activity.subActivities.length > 0) {
                    orderTasks.push(activity.subActivities[0]);
                }
            });
        });
        return orderTasks;
    }


    navigateToOrderDetailsPage(): void {
        this.ordersService.isNewSubmittedOrder = true;
        this.router.navigate([`/orders/${this.orderId}/order-detail`]);
    }


    goToPreviousStep() {
        for (let i = this.currentRouteIndex - 1; i >= 0; i--) {
            if (this.trackerOptions[i].orderType.indexOf(this.orderData.metadata.orderType.toLowerCase()) > -1) {
                this.goToStep(this.trackerOptions[i].step);
                break;
            }
        }
    }

    goToNextStep() {
        for (let i = this.currentRouteIndex + 1; i < this.trackerOptions.length - 1; i++) {
            if (this.trackerOptions[i].orderType.indexOf(this.orderData.metadata.orderType.toLowerCase()) > -1) {
                this.goToStep(this.trackerOptions[i].step);
                break;
            }
        }
    }

    validateDueBy() {
      let isValidDueBy = true;
      const now = new Date();
      this.orderData.lineItems.forEach((item) => {
        if (item.dueDateTime) {
          const dueByDateTime = new Date(item.dueDateTime);
          isValidDueBy = isValidDueBy && (dueByDateTime > now);
        }
      });
      return isValidDueBy;
    }

    alertInvalidDueBy() {
      this.alerts.addErrorAlerts('You have due dates in your Order that occur in the past. Please update the Schedule step, then try submitting again!');
    }

    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }

}
