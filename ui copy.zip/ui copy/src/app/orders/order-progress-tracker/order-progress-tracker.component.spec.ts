/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ModalModule } from "ng2-modal";

import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/observable/of';

import { OrderProgressTrackerComponent } from './order-progress-tracker.component';
import { OrderStore } from '../../models/order-store';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { UtilityService } from '../../services/utility.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { StorageService } from '../../services/storage.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrderCustomizationBaseService } from '../order-customization-base/order-customization-base.service';
import { OrderDetailsScheduleService } from '../order-details-schedule/order-details-schedule.service';
import { OrdersService } from '../orders/orders.service';
import { UserService } from '../../services/user.service';

describe('OrderProgressTrackerComponent', () => {
  let fixture, greeter, element, debugElem, app;
  let mockBackend, service;
  let mockService = {
      get: () => {}
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderProgressTrackerComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [HttpClientModule, FormsModule, ModalModule, RouterTestingModule],
      providers: [
        {provide: OrderProgressTrackerService, useValue: mockService},
        {provide: OrderDetailsScheduleService, useValue: mockService},
        OrderCustomizationBaseService,
        OrdersService,
        {provide: UserService, useValue: mockService},
        OrderStore,
        {
          provide: ActivatedRoute, useValue: {
            param: Observable.of({ id: '1234' })
          }
        },
        {
          provide: Router, useValue: {
            param: Observable.of({ id: '1234' })
          }
        },
        SystemAlertsService,
        StorageService,
        UtilityService,
        ConfigService,
        EndpointProfileService,
        LoadingMaskService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: HttpClient,
          useFactory: (http: Http) => http,
          deps: [Http],
        },
        EnvironmentService,
        ConfigurationManagerService
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrderProgressTrackerComponent);
    element = fixture.nativeElement;              // to access DOM element
    debugElem = fixture.debugElement;             // test helper
    app = fixture.debugElement.componentInstance; // to access properties and methods
  }));

  beforeEach(inject([OrderProgressTrackerService, MockBackend], (s, m) => {
    service = s;
    mockBackend = m;
  }));

  xit('should create progress tracker component', () => {
    expect(app).toBeTruthy();
  });
});
