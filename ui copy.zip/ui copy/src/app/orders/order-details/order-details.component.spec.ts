/* tslint:disable:no-unused-variable */
import { TestBed, async, ComponentFixture, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Http, Response, ResponseOptions, BaseRequestOptions, Headers } from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { AdalService } from 'ng2-adal/dist/core';
import { HttpClient } from '@angular/common/http';

import { SecretService } from '../../services/secret.service';
import { OrderStore } from '../../models/order-store';
import { UtilityService } from '../../services/utility.service';
import { UserService } from '../../services/user.service';
import { LoginService } from '../../login/login.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { HtmlFormatDirective } from '../../directives/html-format.directive';
import { StatusDirective } from '../../directives/status.directive';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';
import { OrderDetailsComponent } from './order-details.component';
import { OrderDetailsReviewService } from '../order-details-review/order-details-review.service';
import { CatalogService } from '../../catalog/catalog.service';
import { NavigationService } from '../../services/navigation.service';
import { Order } from '../../models/order';
import 'rxjs/add/observable/of';


xdescribe('OrderDetailsComponent', () => {
  let fixture, greeter, element, debugElem, app;
  let mockBackend, service;
  //let order: Order;
  let users = {
    content: [
      {id: 2351, login: "Meghan.Besse@viacommix.com", firstName: "Meghan", lastName: "Besse", displayName: 'Meghan Besse'},
      {id: 1551, login: "Samir.Patel@viacomcontractor.com", firstName: "Samir", lastName: "Patel", displayName: 'Samir Patel'},
      {id: 1601, login: "Saransh.Ahlawat@viacomcontractor.com", firstName: "Saransh", lastName: "Ahlawat", displayName: 'Saransh Ahlawat'},
      {id: 1552, login: "Luis.Velez@viacommix.com", firstName: "Luis", lastName: "Velez", displayName: 'Luis Velez'}
    ]
  };

  let lineItem = {
    current_state: {
      'status': "TO_DO"
    },
    activities: [
      {
        'typeId': 1,
        'assignedUserEmail': '',
        'subActivities': [
          {
            'typeId': 7,
            'assignedUserEmail': 'Samir.Patel@viacomcontractor.com',
            'current_state': {
              'status': "WAITING"
            },
          }
        ],
        'current_state': {
          'status': "TO_DO"
        },
      },
      {
        'typeId': 3,
        'assignedUserEmail': 'Samir.Patel@viacomcontractor.com',
        'subActivities': [
          {
            'typeId': 7,
            'assignedUserEmail': 'Samir.Patel@viacomcontractor.com',
            'current_state': {
              'status': "WAITING"
            },
          }
        ],
        'current_state': {
          'status': "TO_DO"
        },
      },
      {
        'typeId': 13,
        'assignedUserEmail': '',
        'subActivities': [],
        'current_state': {
          'status': "TO_DO"
        },
      }
    ]
  };

  let orderData = {
    id: 1111,
    to: 1233,
    order_for: 12312,
    creator: 'J Unit',
    name: 'TEST ORDER FOR J UNIT',
    metadata: {
    },
    dsid: 'VBDSID',
    current_milestone: {
      status: 'TO_DO',
      last_modified_date: '00000000',
      last_modified_by: 'J UNIT'
    },
    milestones: [{
      status: 'TO_DO',
      last_modified_date: '00000000',
      last_modified_by: 'J UNIT'
    }],
    lineItems: [lineItem],
    lineItemVmid: [lineItem]
  };

  let mockReviewService = {
      get: () => {}
  };
  let MockUserService = {
    getAllUsers: function() {
      return Observable.of(users);
    }
  };

  let MockCatalogService = {
    getItemDetails: function(vmid) {
      return Observable.of({
        vmid: 'vdnf-23s0-fsdr-123f',
        title: 'South Park'
      })
    }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, RouterTestingModule, HttpClientModule ],
      declarations: [ OrderDetailsComponent, HtmlFormatDirective, StatusDirective ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        {provide: OrderDetailsReviewService, useValue: mockReviewService},
        OrderStore,
        {
          provide: ActivatedRoute, useValue: {
            params: Observable.of({ id: 'test' })
          }
        },
        {
          provide: HttpClient,
          useFactory: (http: Http) => http,
          deps: [Http]
        },
        UtilityService,
        NavigationService,
        AdalService,
        SystemAlertsService,
        EndpointProfileService,
        ConfigService,
        {provide: UserService, useValue: MockUserService},
        SecretService,
        {provide: CatalogService, useValue: MockCatalogService},
        LoginService,
        LoadingMaskService,
        EnvironmentService,
        ConfigurationManagerService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        }
      ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(OrderDetailsComponent);
    element = fixture.nativeElement;              // to access DOM element
    debugElem = fixture.debugElement;             // test helper
    //app = fixture.debugElement.componentInstance; // to access properties and methods
    app = fixture.componentInstance; // to access properties and methods
    //fixture.detectChanges();
  }));

  beforeEach(inject([OrderDetailsReviewService, MockBackend], (s, m) => {
    service = s;
    mockBackend = m;
  }));

  it('should create order details component', async(() => {
    expect(app).toBeDefined();
  }));

  it('should have ngOnInit defined', () => {
    spyOn(mockReviewService, 'get').and.returnValue(Observable.of(orderData));
    expect(app.ngOnInit).toBeDefined();
  });

  // it('should have dataSubscription defined', async(() => {
  //   spyOn(mockReviewService, 'get').and.returnValue(Observable.of(orderData));
  //   app.initialize();
  //   expect(app.dataSubscription).toBeDefined();
  // }));
  //
  // it('should have catalogSubscription defined', async(() => {
  //   spyOn(mockReviewService, 'get').and.returnValue(Observable.of(orderData));
  //   app.getCatalogInfo('vdnf-23s0-fsdr-123f');
  //   expect(app.catalogSubscription).toBeDefined();
  // }));
  //
  // it('should have order defined', async(() => {
  //   spyOn(mockReviewService, 'get').and.returnValue(Observable.of(orderData));
  //   app.initialize();
  //   expect(app.order).toBeDefined();
  // }));

  it('#getActivity should have 2 parameters', () => {
    expect(app.getActivity.length).toEqual(2);
  });

  it('#showSection should have 1 parameter', () => {
    expect(app.showSection.length).toEqual(1);
  });

  it('#getContentActivities should have 1 parameter', () => {
    expect(app.getContentActivities.length).toEqual(1);
  });

  it('#getContentActivities should should return list of activities', () => {
    let result = app.getContentActivities(lineItem);
    expect(result.length).toEqual(1);
  });

  it('#getCopyActivity should have 1 parameter', () => {
    expect(app.getCopyActivity.length).toEqual(1);
  });

  it('#getCopyActivity should return list of activities', () => {
    let result = app.getCopyActivity(lineItem);
    expect(result.length).toEqual(1);
  });

  it('#getComposeCopyStatus should have 1 parameter', () => {
    expect(app.getComposeCopyStatus.length).toEqual(1);
  });

  it('#getComposeCopyStatus should return TO_DO', () => {
    let result = app.getComposeCopyStatus(lineItem);
    expect(result).toEqual('TO_DO');
  });

  it('#getComposeCopyUser should have 1 parameter', () => {
    expect(app.getComposeCopyUser.length).toEqual(1);
  });

  it('#getComposeCopyUser should be Samir.Patel@viacomcontractor.com', () => {
    let result = app.getComposeCopyUser(lineItem);
    expect(result).toEqual('Samir.Patel@viacomcontractor.com');
  });

  it('#getApproveCopyStatus should have 1 parameter', () => {
    expect(app.getApproveCopyStatus.length).toEqual(1);
  });

  it('#getApproveCopyStatus should return WAITING', () => {
    let result = app.getApproveCopyStatus(lineItem);
    expect(result).toEqual({ status: 'WAITING', showMsg: true });
  });

  it('#getApproveCopyUser should have 1 parameter', () => {
    expect(app.getApproveCopyUser.length).toEqual(1);
  });

  it('#getComposeContentStatus should have 1 parameter', () => {
    expect(app.getComposeContentStatus.length).toEqual(1);
  });

  it('#getComposeContentUser should have 1 parameter', () => {
    expect(app.getComposeContentUser.length).toEqual(1);
  });

  it('#getApproveContentStatus should have 1 parameter', () => {
    expect(app.getApproveContentStatus.length).toEqual(1);
  });

  it('#getApproveContentUser should have 1 parameter', () => {
    expect(app.getApproveContentUser.length).toEqual(1);
  });

  it('#getApproveContentUser: approve video should return Samir Patel', () => {
    let result = app.getApproveContentUser(lineItem);
    expect(result).toEqual('Samir.Patel@viacomcontractor.com');
  });

  it('#getDisplayNameFromEmail: Luis.Velez@viacommix.com should return Luis Velez', () => {
    let name = app.getDisplayNameFromEmail('Luis.Velez@viacommix.com');
    expect(name).toEqual('Luis Velez');
  });

  it('#getDisplayNameFromEmail: John.Velez@viacommix.com should return Unassigned', () => {
    let name = app.getDisplayNameFromEmail('John.Velez@viacommix.com');
    expect(name).toEqual('Unassigned');
  });

  it('#getPublishActivity should have 1 parameter', () => {
    expect(app.getPublishActivity.length).toEqual(1);
  });

  it('#getPublishActivity should return 1 object', () => {
    let result = app.getPublishActivity(lineItem);
    expect(result.length).toEqual(1);
  });

});
