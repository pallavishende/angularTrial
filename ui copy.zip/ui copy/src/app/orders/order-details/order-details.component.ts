import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { OrdersService } from '../orders/orders.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { forkJoin } from 'rxjs/observable/forkJoin';
import * as moment from 'moment/moment';
import { clone, get, forEach, find, set, filter, cloneDeep, forOwn, includes, remove } from 'lodash';
import { OrderDetailsFormatService } from '../order-details-format/order-details-format.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { OrderStore } from '../../models/order-store';
import { Order } from '../../models/order';
import { LineItem } from '../../models/line-item';
import { Activity, Instructions } from '../../models/activity';
import { CustomConfig } from '../../models/custom-config';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrderDetailsScheduleService } from '../order-details-schedule/order-details-schedule.service';
import { UtilityService } from '../../services/utility.service';
import { CatalogService } from '../../catalog/catalog.service';
import { StorageService } from '../../services/storage.service';
import { ActivitiesService } from '../../activities/activities.service';
import { UserService } from '../../services/user.service';
import { NavigationService } from '../../services/navigation.service';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import { OrderDetailsPackageService } from '../order-details-package/order-details-package.service';
import { OrderInstructionFormFields } from '../../models/generic-form-field';
import { EnvironmentService } from '../../services/environment.service';

/**
 * this mock json will be replaced by an api call in the future
 */
const orderInstructionsFormFields = require('../../models/mock-payloads/order-instructions-form-fields.json');
const publishInstructionsFormFields = require('../../models/mock-payloads/order-publishing-form-fields.json');

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.scss']
})

export class OrderDetailsComponent implements OnInit, OnDestroy {

  @ViewChild('tasksAssigmentDialog') tasksAssigmentDialog: TemplateRef<any>;

  subscriptions = new Subscription();
  shortPollingSubscription: Subscription;
  updateOrderEvent = new Subject<any>();
  userInfo;
  order: Order;
  modifyOrderObj;
  endpointProfiles;
  contentDetails;
  dsid;
  users;
  pageSubheader = '';
  today;
  progressArr = [];
  progressTotal = { total: 0, completed: 0 };
  orderId;
  selectedLineItem;
  selectedLineItemClipId;
  selectedPublishLineItemClipId;
  selectedPublishInstructions;
  selectedCopyInstructions = false;
  showPublishInstructionsForm = false;
  showCopyInstructionsForm;
  isPublishFieldValid: boolean;
  isCopyFieldValid: boolean;
  isVideoInstructionsFormValid = true;
  enableSubmitPublishInstructions = true;
  modalType = '';
  initializeEditor: boolean;
  initializePublishEditor: boolean;
  packageTotal = 0;
  dueDate;
  publishDate;
  instructionsFormFields: OrderInstructionFormFields;
  publishInstructionsFormFields: OrderInstructionFormFields;
  allTeams: Array<any>;
  taskAssignmentObj = {};
  tasksDisplayObj = [];
  isLoadingAssignee = false;
  pausePolling = false;
  tasksConfig = [];
  isVmnMmopsTeamAvailable = false;
  isEnvGreaterThanUAT = false;
  orderTypeConfig = { // display mapping
    VIDEO: {displayName: 'VIDEO PUBLISHING', tasks: [1, 13, 16]}, // task type 7 (approve video) removed from UI by design
    COPY: {displayName: 'COPY', tasks: [3, 10]},
    GRAPHICS: {displayName: 'GRAPHICS', tasks: [5, 11]},
    SITE_APP_UPDATES: {displayName: 'SITE & APP UPDATES', tasks: [14, 15]}
  };

  constructor(
    private matDialog: MatDialog,
    private endpointProfileService: EndpointProfileService,
    private loadingMask: LoadingMaskService,
    private alerts: SystemAlertsService,
    private activatedRoutes: ActivatedRoute,
    private orderStore: OrderStore,
    private ordersService: OrdersService,
    private orderProgressTrackerService: OrderProgressTrackerService,
    private router: Router,
    private catalogService: CatalogService,
    private utilityService: UtilityService,
    private activitiesService: ActivitiesService,
    private userService: UserService,
    private navigationService: NavigationService,
    private orderDetailsFormatService: OrderDetailsFormatService,
    private orderDetailsScheduleService: OrderDetailsScheduleService,
    private orderDetailsPackageService: OrderDetailsPackageService,
    private storageService: StorageService,
    private environmentService: EnvironmentService) {
      this.isEnvGreaterThanUAT = this.environmentService.isRuntimeEnvironmentGreaterThan(3);
  }

  ngOnInit() {
    this.ordersService.setOrdersPageTitle('Order Detail - Viacom Bridge');
    this.orderId = this.activatedRoutes.params['_value'].id;
    this.today = moment().format('YYYY-MM-DD').toString();
    this.userInfo = this.userService.getUserLoginInfo();
    this.userInfo['name'] = 'Me (' + this.userInfo['firstName'] + ' ' + this.userInfo['familyName'] + ')';
    this.getOrderDetails();
    this.pollingFunction();
    this.instructionsFormFields = orderInstructionsFormFields;
    this.publishInstructionsFormFields = publishInstructionsFormFields;
  }

  getOrderDetails() {
    this.loadingMask.enableLoadingMask();
    this.subscriptions.add(this.ordersService.getOrderDetails(this.orderId).subscribe(
      data => {
        this.order = data;
        // TO BE REMOVED after all old orders are gone
        if (!this.order.metadata['isNewOrder']) {
          this.orderTypeConfig.VIDEO = {displayName: 'VIDEO PUBLISHING', tasks: [1, 7, 13, 16]};
        }
        this.constructTasksConfig();
        this.initialize(data);
        this.orderStore.loadInitialModel(data, data.metadata.orderType);
        this.order.lineItemsClipId = this.appendClipLevelInfo(data.lineItems, this.order.lineItemsClipId);
        this.getOrderProgress(data.lineItems);
        this.loadingMask.disableLoadingMask();
        if (this.ordersService.isNewSubmittedOrder) {
          this.openTeamAssignmentDialog();
        }
        this.pausePolling = false;
      },
      error => {
        if (error.status === 404) {
          this.alerts.redirectTo404Page();
        } else {
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        }
      }));
  }

  // NOTICE: this method will change lineItems retrieved from lineItemsClipId
  // ONLY use lineItems from lineItemsClipId for UI template display purpose, all calculations should use lineItems from this.order.lineItems
  appendClipLevelInfo(lineItems, lineItemsClipId) {
    let clonedLineItemsClipId = cloneDeep(lineItemsClipId);
    forEach(lineItems, lineItem => {
      // find lineItems with QA-video task and append QA task to lineItemClipId
      let qaVideoTask = find(lineItem.activities, activity => activity['typeId'] === 16);
      if (qaVideoTask) {
        let targetClipLineItem = find(clonedLineItemsClipId, (lineItemClipId) => {
          const clipLineItemMetadata = lineItemClipId['metadata'][0];
          const lineItemMetadata = lineItem['metadata'][0];
          if (clipLineItemMetadata && lineItemMetadata) {
            if (clipLineItemMetadata.clipId) {
              return clipLineItemMetadata.clipId === lineItemMetadata.clipId;
            } else {
              return clipLineItemMetadata.clipTitle === lineItemMetadata.clipTitle;
            }
          }
        });
        if (targetClipLineItem && !find(targetClipLineItem['activities'], (activity) => {return activity['typeId'] === 16; })) {
          targetClipLineItem['activities'].push(qaVideoTask);
        }
      }
    });
    return clonedLineItemsClipId;
  }

  constructTasksConfig() {
    this.tasksConfig = [];
    let currentOrderTypeConfig = this.orderTypeConfig[this.order.metadata['orderType']];
    forEach(currentOrderTypeConfig.tasks, taskId => this.tasksConfig.push({
      typeId: Number(taskId),
      name: this.utilityService.getActivityNameByTypeId(Number(taskId)),
      route: this.utilityService.getActivityRouteByTypeId(Number(taskId))
    }));
  }

  initialize(data) {
    this.initializeOrderModification();
    this.order = data;
    console.log('details > initialize > data: ', data);
    if (this.order.name) {
      this.ordersService.setOrdersPageTitle(this.order.name + ' - Order Detail - Viacom Bridge');
    }
    this.subscriptions.add(this.endpointProfileService.getEndpointProfiles().subscribe(
      data => {
        this.endpointProfiles = data;
      }
    ));
    let vmid = get(this.order, 'metadata.vmId') === undefined ?
      '' : get(this.order, 'metadata.vmId').toString();
    if (!this.contentDetails && vmid) {
      this.getContentDetails(vmid, this.order.metadata['contentType']);
    }
  }

  pollingFunction() {
    this.subscriptions.add(IntervalObservable.create(20000).subscribe(
      interval => {
        if (typeof this.shortPollingSubscription !== 'undefined') {
          this.shortPollingSubscription.unsubscribe();
        }
        this.shortPollingSubscription = this.ordersService.getOrderDetails(this.orderId).subscribe(
        data => {
          if (!this.pausePolling) {
            this.updateOrderDetail(data);
          }
        });
      }
    ));
  }

  updateOrderDetail(orderObj) {
    let updatedObj = orderObj;
    this.order['currentMilestone'] = updatedObj['currentMilestone'];
    forEach(this.order.lineItemsClipId, (lineItemClipId) => {
      let updatedLineItem = find(updatedObj.lineItems, (updatedLineItem) => {
        return updatedLineItem['id'] === lineItemClipId['id'];
      });
      if (updatedLineItem) {
        lineItemClipId['activities'] = updatedLineItem['activities'];
      }
    });

    forEach(this.order.lineItems, (lineItem) => {
      let updatedLineItem = find(updatedObj.lineItems, (updatedLineItem) => {
        return updatedLineItem['id'] === lineItem['id'];
      });
      if (updatedLineItem) {
        lineItem['activities'] = updatedLineItem['activities'];
      }
    });

    this.order.lineItemsClipId = this.appendClipLevelInfo(orderObj.lineItems, this.order.lineItemsClipId);
    this.getOrderProgress(orderObj.lineItems);
  }

  setPreviousPageUrl() {
    let orderDetailsUrl;
    orderDetailsUrl = this.router.url;
    this.navigationService.setActivityDetailsPreviousUrl(orderDetailsUrl);
  }

  getContentDetailsRoute() {
    if (this.order.metadata && this.order.metadata['vmId']) {
      if (this.order.lineItems[0].metadata && this.order.lineItems[0].metadata[0] && this.order.lineItems[0].metadata[0].dsId) {
        return '/catalog/content-details/' + this.order.metadata['vmId'] + '/' + this.order.lineItems[0].metadata[0].dsId;
      } else {
        return '/catalog/content-details/' + this.order.metadata['vmId'];
      }
    }
  }

  getActivityStatus(activity) {
    if (activity.startWorkStatusValue && activity.activityBundleStatus === 'TO_DO') {
      return 'IN_PROGRESS';
    } else {
      return activity.activityBundleStatus;
    }
  }

  getActivityStatusNonVideo(activity) {
    if (activity.startWorkStatusValue && activity.currentState.status === 'TO_DO') {
      return 'IN_PROGRESS';
    } else if (activity.activityBundleStatus === 'REOPENED') {
      return 'REOPENED';
    } else {
      return activity.currentState.status;
    }
  }

  getActivityByTypeId(lineItem, typeId) {
    if (!lineItem || !typeId) {
      return null;
    }
    switch (typeId) {
      case 7:
        return this.getActivityByTypeId(lineItem, 1).subActivities[0];

      case 10:
        return this.getActivityByTypeId(lineItem, 3).subActivities[0];

      case 11:
        return this.getActivityByTypeId(lineItem, 5).subActivities[0];

      case 15:
        return this.getActivityByTypeId(lineItem, 14).subActivities[0];

      default:
        let targetActivity = filter(lineItem.activities, function (activity) {
          return activity['typeId'] === Number(typeId);
        });
        if (targetActivity && targetActivity.length > 0) {
          return targetActivity[0];
        }
    }
  }

  getContentDetails(vmid, contentType) {
    this.subscriptions.add(this.catalogService.getItemDetails(vmid, contentType)
      .subscribe(
      data => {
        this.contentDetails = data.contentDetails;
        if (contentType === 'BRAND' && data.minimumBrands.length > 0) {
          this.pageSubheader = data.minimumBrands[0].name;
          this.contentDetails = data.minimumBrands[0];
        } else if ((contentType === 'SERIES' || contentType === 'SPECIAL') && data.contentDetails) {
          this.pageSubheader = data.contentDetails.title;
        } else {
          this.pageSubheader = this.utilityService.getHeaderForContentType(data.contentDetails, contentType);
        }
        this.loadingMask.disableLoadingMask();
      }));
  }

  addVersionToClip(versionInstructionsMetadata: Array<any>) {
    this.loadingMask.enableLoadingMask();
    this.pausePolling = true;
    // creating new activity for end point and version
    let newLineItem = new LineItem();
    let versionTitle;
    let versionDescription;
    let versionType;
    forEach(versionInstructionsMetadata, (instructionMetadata: Instructions) => {
      if (instructionMetadata.label === 'versionTitle') {
        versionTitle = instructionMetadata.values[0];
      } else if (instructionMetadata.label === 'additionalNotes') {
        versionDescription = instructionMetadata.values[0];
      } else if (instructionMetadata.label === 'versionType') {
        versionType = instructionMetadata.values[0];
      }
    });
    newLineItem.metadata = this.selectedLineItem['metadata'];
    newLineItem.customConfig = new CustomConfig();
    newLineItem.customConfig.endpoint = this.modifyOrderObj.endpoint;
    newLineItem.customConfig.version = versionTitle;
    this.orderStore.addNewLineItem(newLineItem);
    const activity = this.orderDetailsFormatService.newActivity(1, versionDescription);
    this.orderStore.addActivity(activity, newLineItem);

    if (newLineItem.customConfig.endpoint === 'Viacom Sites & Apps' && versionType === 'Video with captioning') {
      const qaActivity = this.orderDetailsFormatService.newActivity(16, this.utilityService.activityTypes.QA_VIDEO.description);
      this.orderStore.addActivity(qaActivity, newLineItem);
    }

    this.utilityService.getLineItemActivity(1, newLineItem).instructions = versionInstructionsMetadata;
    this.saveScheduleToModel(newLineItem);

    if (this.selectedLineItem.endpoint_info['Viacom Sites & Apps'] && this.selectedLineItem.endpoint_info['Viacom Sites & Apps'].length > 0 &&
    this.modifyOrderObj.endpoint === 'Viacom Sites & Apps') {
      const publishInstructionsLineItem = this.selectedLineItem.endpoint_info['Viacom Sites & Apps'].find(lineItem => lineItem.id);
      if (publishInstructionsLineItem) {
        let publishInstructions = this.utilityService.getLineItemActivity(13, publishInstructionsLineItem).instructions;
        forEach(publishInstructions, instruction => delete instruction['id']);
        this.utilityService.getLineItemActivity(13, newLineItem).instructions = publishInstructions;
      }
    }

    newLineItem = this.assignApprovals(newLineItem, this.selectedLineItem);
    this.orderStore.syncActivities(newLineItem);

    const payload = clone(this.order);
    this.subscriptions.add(this.orderProgressTrackerService.updateOrder(payload).subscribe(
      data => {
        this.alerts.addSuccessAlerts('You added ' + '<strong>' + this.selectedLineItem.customConfig.version + '</strong>' + ' to '
          + '<strong>' + this.order.name + '</strong>');
        this.getOrderDetails();
        console.log('Success: You added a version! ' + this.selectedLineItem.id + '.');
      },
      error => {
        console.log('Error: version could not be added!');
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        this.getOrderDetails();
      }
    ));
  }

  editOrder() {
    let payload;
    let dueDate;
    let publishDate;
    this.loadingMask.enableLoadingMask();
    this.pausePolling = true;
    this.updateOrderEvent.next();
    if (this.order.metadata['orderType'].toLowerCase() === 'video') {
      dueDate = new Date(this.modifyOrderObj.schedule.dueBy.date + ' ' + this.modifyOrderObj.schedule.dueBy.time);
      publishDate = new Date(this.modifyOrderObj.schedule.publishOn.date + ' ' + this.modifyOrderObj.schedule.publishOn.time);
      let targetLineItem = find(this.order.lineItems, {id: this.selectedLineItem.id});
      targetLineItem['customConfig'].dueByDate = this.modifyOrderObj.schedule.dueBy.date;
      targetLineItem['customConfig'].dueByTime = this.modifyOrderObj.schedule.dueBy.time;
      targetLineItem['customConfig'].publishOnDate = this.modifyOrderObj.schedule.publishOn.date;
      targetLineItem['customConfig'].publishOnTime = this.modifyOrderObj.schedule.publishOn.time;
      targetLineItem['dueDateTime'] = dueDate;
      targetLineItem['publishDateTime'] = publishDate;
      if (this.modifyOrderObj.endpoint === 'Viacom Sites & Apps' &&
        targetLineItem['videoInstructionsMetadata'] && targetLineItem['videoInstructionsMetadata'].versionType &&
        targetLineItem['videoInstructionsMetadata'].versionType[0] === 'Video with captioning') {
        if (!find(targetLineItem['activities'], {'typeId': 16})) {
          const qaActivity = this.orderDetailsFormatService.newActivity(16, this.utilityService.activityTypes.QA_VIDEO.description);
          targetLineItem['activities'].push(qaActivity);
          this.assignApprovals(targetLineItem, this.selectedLineItemClipId);
        }
      } else {
        if (find(targetLineItem['activities'], {'typeId': 16})) {
          remove(targetLineItem['activities'], {'typeId': 16});
        }
      }

      payload = clone(this.order);
      this.subscriptions.add(this.orderProgressTrackerService.updateOrder(payload).subscribe(
        (data) => {
          this.loadingMask.disableLoadingMask();
          this.alerts.addSuccessAlerts('<strong>' + this.order.name + '</strong>' + ' has been updated.');
          this.getOrderDetails();
        },
        (error) => {
          console.log('Order Details Error: Order could not be editted!');
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }));
    } else {
      this.editNonVideoOrder();
    }
  }

  editNonVideoOrder() {
    let payload;
    let dueDate;
    this.order.lineItems[0].activities[0].description = this.modifyOrderObj.instructions.description;
    if (this.order.metadata['orderType'].toLowerCase() === 'copy') {
      const modifiedInstructions = [];
      if (this.modifyOrderObj.instructions.brandName.trim()) {
        modifiedInstructions.push({label: 'brandName', values: [this.modifyOrderObj.instructions.brandName.trim()]});
      }
      this.order.lineItems[0].activities[0].instructions = modifiedInstructions;
    }

    dueDate = new Date(this.modifyOrderObj.schedule.dueBy.date + ' ' + this.modifyOrderObj.schedule.dueBy.time);
    this.order.lineItems[0].dueDateTime = moment.utc(dueDate).toISOString();
    payload = clone(this.order);
    this.subscriptions.add(this.orderProgressTrackerService.updateOrder(payload).subscribe(
      (data) => {
        this.loadingMask.disableLoadingMask();
        this.alerts.addSuccessAlerts('<strong>' + this.order.name + '</strong>' + ' has been updated.');
        this.getOrderDetails();
      },
      (error) => {
        console.log('Order Details Error: Order could not be editted!');
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  editPublishInstructions() {
    this.pausePolling = true;
    // find which lineItems need updating publish instructions
    let targetLineItemIds = [];
    forEach(this.selectedPublishLineItemClipId['endpoint_info']['Viacom Sites & Apps'], lineItem => {
      targetLineItemIds.push(lineItem.id);
    });

    // construct publish instructions payload
    let publishInstructions = [];
    if (this.showCopyInstructionsForm) {
      forEach(this.selectedCopyInstructions, (value, key) => {
        publishInstructions.push({label: key, values: value});
      });
    }
    if (this.showPublishInstructionsForm) {
      forEach(this.selectedPublishInstructions, (value, key) => {
        publishInstructions.push({label: key, values: value});
      });
    }
    publishInstructions = publishInstructions.filter(instruction => {
      return instruction.values[0];
    });

    // update this.order
    forEach(this.order.lineItems, (lineItem) => {
      if (includes(targetLineItemIds, lineItem.id)) {
        this.utilityService.getLineItemActivity(13, lineItem).instructions = publishInstructions;
      }
    });

    let orderPayload;
    this.updateOrderEvent.next();
    this.loadingMask.enableLoadingMask();
    orderPayload = clone(this.order);
    this.subscriptions.add(this.orderProgressTrackerService.updateOrder(orderPayload).subscribe(
      (data) => {
        this.loadingMask.disableLoadingMask();
        this.alerts.addSuccessAlerts('<strong>' + this.order.name + '</strong>' + ' has been updated.');
        this.getOrderDetails();
      },
      (error) => {
        console.log('Order Details Error: Publish Instructions could not be editted!');
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      }));
  }

  onFocus(event) {
    event.target.select();
  }

  isDueByTooSoon() {
    if (!this.modifyOrderObj.schedule.dueBy.time) {
      this.modifyOrderObj.schedule.dueBy.time = '12:00 PM';
    }
    const now = new Date().getTime();
    const dueDateTime = new Date(this.modifyOrderObj.schedule.dueBy.date + ' ' + this.modifyOrderObj.schedule.dueBy.time).getTime();
    return dueDateTime - now < 7200000 && dueDateTime > now;
  }

  validateDueBy(modalType) {
    if (this.dueDate > new Date()) {
      if (modalType === 'addVersion') {
        this.updateOrderEvent.next();
      } else if (modalType === 'editVersion') {
        this.editOrder();
      }
      return true;
    } else {
      return false;
    }
  }

  alertInvalidDueBy() {
    this.alerts.addErrorAlerts('The due date you\'ve entered is in the past. Please update the times to save your changes.');
  }

  isEditOrderValidated() {
    let isValid: boolean;
    if (!this.modifyOrderObj.schedule.dueBy.time) {
      this.modifyOrderObj.schedule.dueBy.time = '12:00 PM';
    }
    if (!this.modifyOrderObj.schedule.publishOn.time) {
      this.modifyOrderObj.schedule.publishOn.time = '12:00 PM';
    }
    this.dueDate = new Date(this.modifyOrderObj.schedule.dueBy.date + ' ' + this.modifyOrderObj.schedule.dueBy.time);
    this.publishDate = new Date(this.modifyOrderObj.schedule.publishOn.date + ' ' + this.modifyOrderObj.schedule.publishOn.time);
    if (moment(this.dueDate).isValid()) {
      switch (this.order.metadata['orderType']) {
        case 'COPY':
          isValid = true;
          break;

        case 'SITE_APP_UPDATES':
          isValid = true;
          break;

        case 'GRAPHICS':
          if (this.modifyOrderObj.instructions.description.replace(/&nbsp;|\s/g, '')) {
            isValid = true;
          }
          break;

        case 'VIDEO':
          if (this.isVideoInstructionsFormValid &&
            moment(this.publishDate).isValid() &&
            this.modifyOrderObj.instructions.title &&
            this.modifyOrderObj.endpoint &&
            this.publishDate > this.dueDate
          ) {
            isValid = true;
          }
          break;
      }
      if (!this.timeValidator(this.modifyOrderObj.schedule.dueBy.time)) {
        isValid = false;
      } else if (!this.timeValidator(this.modifyOrderObj.schedule.publishOn.time)) {
        isValid = false;
      }
      return isValid || false;
    }
  }

  assignApprovals(lineItem, mirrorLineItem) {
    forEach(lineItem.activities, (activity) => {
      if (this.getActivityByTypeId(mirrorLineItem, activity.typeId)) {
        activity.assignedUserEmail = this.getActivityByTypeId(mirrorLineItem, activity.typeId)['assignedUserEmail'];
        activity.assignedUserName = this.getActivityByTypeId(mirrorLineItem, activity.typeId)['assignedUserName'];
        activity.teamId = this.getActivityByTypeId(mirrorLineItem, activity.typeId)['teamId'];
        activity.teamName = this.getActivityByTypeId(mirrorLineItem, activity.typeId)['teamName'];
      }
    });
    return lineItem;
  }

  saveScheduleToModel(item) {
    item.customConfig['dueByDate'] = this.modifyOrderObj.schedule.dueBy.date;
    item.customConfig['dueByTime'] = this.modifyOrderObj.schedule.dueBy.time;
    item.customConfig['publishOnDate'] = this.modifyOrderObj.schedule.publishOn.date;
    item.customConfig['publishOnTime'] = this.modifyOrderObj.schedule.publishOn.time;
    let dueDate = new Date(item.customConfig['dueByDate'] + ' ' + item.customConfig['dueByTime']);
    let publishBy = new Date(item.customConfig['publishOnDate'] + ' ' + item.customConfig['publishOnTime']);

    item['dueDateTime'] = moment.utc(dueDate).toISOString();
    item['publishDateTime'] = moment.utc(publishBy).toISOString();

    try {
      if (dueDate.toString() !== 'Invalid date' && moment(dueDate).isValid() &&
        publishBy.toString() !== 'Invalid date' && moment(publishBy).isValid()) {
        if (this.orderDetailsScheduleService.isValidDate(get(item, 'dueDateTime'), get(item, 'publishDateTime'))) {
          set(item, 'dateError', false);
          this.createPublishActivity(item, this.utilityService, this.orderDetailsPackageService);
        } else {
          set(item, 'dateError', true);
        }

        this.orderStore.notify();
      }
    } catch (e) {
      console.log('Date not in proper format.');
    }
  }

  createPublishActivity(item, utilityServiceRef, packageServiceRef) {
    // dates are valid, create publish activity
    // 1. create if publish content activity does not exist
    let publishActivityObj = find(item.activities, function (activity) {
      return activity['typeId'] === utilityServiceRef.activityTypes.PUBLISH_VIDEO.type;
    });
    if (publishActivityObj === undefined) {
      let activityObj = new Activity();
      activityObj.quantity = 1;
      activityObj.typeId = utilityServiceRef.activityTypes.PUBLISH_VIDEO.type;
      activityObj.description = utilityServiceRef.activityTypes.PUBLISH_VIDEO.description;
      activityObj.generationMode = utilityServiceRef.activityGenerationMode.Automatic;
      packageServiceRef.createActivityObj(activityObj, item);
    }
  }

  timeValidator(timeStr: string): boolean {
    if (!timeStr) {
      return false;
    }
    const parserColon = timeStr.indexOf(':');
    const parserSpace = timeStr.indexOf(' ');
    const hourStr = timeStr.substr(0, parserColon);
    const minuteStr = timeStr.substr(parserColon + 1, parserSpace - parserColon - 1);
    const periodStr = timeStr.substr(parserSpace + 1);
    const h = Number(hourStr);
    const m = Number(minuteStr);
    if (h > 0 && h <= 12) {
      if (m >= 0 && m < 60 && minuteStr.length === 2) {
        if (periodStr === 'AM' || periodStr === 'PM') {
          return true;
        }
      }
    }
    return false;
  }

  showSection(item) {
    item['opened'] = !(item['opened'] || false);
    return item['opened'];
  }

  findAssignedTeamByActivityType(activityType) {
    const assignmentObj = this.storageService.getActivitiesAssignmentFromLocal();
    if (!assignmentObj) {
      return this.userInfo;
    }
    const targetTeam = find(this.allTeams, team => team.id === assignmentObj[activityType]);
    if (!targetTeam) {
      return this.userInfo;
    } else {
      return targetTeam;
    }
  }

  setTeamsAssignmentDefaultValues(): void {
    this.taskAssignmentObj = {};
    this.isVmnMmopsTeamAvailable = false;
    const targetTeam = find(this.allTeams, team => team.name === 'vmn mmops');
    forEach(this.tasksConfig, task => {
      if(task.typeId === 1 && targetTeam) {
        this.isVmnMmopsTeamAvailable = true;
        this.taskAssignmentObj[task.typeId] = targetTeam;
      } else {
        this.taskAssignmentObj[task.typeId] = this.findAssignedTeamByActivityType(task.typeId)
      }

    });
  }

  constructTasksDisplayObj() {
    this.tasksDisplayObj = [];
    if (this.taskAssignmentObj) {
      forEach(this.taskAssignmentObj, (value, key) => {
        this.tasksDisplayObj.push(
          {
            typeId: Number(key),
            taskName: this.utilityService.getActivityNameByTypeId(Number(key))
          }
        );
      });
    }
  }

  saveAssigmentChanges(): void {
    this.pausePolling = true;
    const orderObjClone = cloneDeep(this.order);
    const tasksAssignmentObservableArray = [];
    this.loadingMask.enableLoadingMask();
    forOwn(this.taskAssignmentObj, (value, key) => {
      const activityIds = [];
      forEach(orderObjClone.lineItems, (lineItem: LineItem) => {
        forEach(lineItem.activities, (activity: Activity) => {
          if (activity.typeId === parseInt(key)) {
            activityIds.push({id: activity['activityBundleId']});
          } else if (activity.subActivities.length > 0 && activity.subActivities[0].typeId === parseInt(key)) {
            activityIds.push({id: activity.subActivities[0]['activityBundleId']});
          }
        });
      });
      if (value['email']) {
        tasksAssignmentObservableArray.push(this.activitiesService.bulkAssignActivity(value['email'], activityIds, this.userInfo.email));
        this.storageService.setActivitiesAssignmentToLocal({'type': key, 'value': value['email']});
      } else {
        tasksAssignmentObservableArray.push(this.activitiesService.bulkAssignActivity(value['id'], activityIds, this.userInfo.email, true));
        this.storageService.setActivitiesAssignmentToLocal({'type': key, 'value': value['id']});
      }
    });
    forkJoin(tasksAssignmentObservableArray).subscribe(
      (data) => {
        console.log('Success:', data);
        this.alerts.addSuccessAlerts('Successfully assigned the Tasks.');
        this.ordersService.isNewSubmittedOrder = false;
        this.getOrderDetails();
        this.matDialog.closeAll();
      },
      (error) => {
        console.log('Error:', error);
        this.alerts.addErrorAlerts('Failed to assign Tasks. Please try again.');
        this.loadingMask.disableLoadingMask();
      }
    );
  }

  orderSubmittedDate() {
    const submittedMilestone = find(this.order.milestones, (milestone) => {
      return milestone.status = 'PLACED';
    });
    return submittedMilestone;
  }

  getLastVisitedOrdersTab() {
    return this.navigationService.getActiveOrdersListTab();
  }

  setSelectedLineItem(item, lineItemClipId?) {
    // item come from UI modified lineItemClipId, need to get real value from this.order.lineItems
    this.selectedLineItem = find(this.order.lineItems, lineItem => lineItem.id === item.id);
    if (lineItemClipId) {
      this.selectedLineItemClipId = lineItemClipId;
    }
  }

  setSelectedPublishLineItemClipId(item) {
    this.showCopyInstructionsForm = false;
    this.showPublishInstructionsForm = false;
    this.selectedPublishLineItemClipId = item;
    const publishLineItem = this.selectedPublishLineItemClipId['endpoint_info']['Viacom Sites & Apps'][0];
    if (publishLineItem && publishLineItem.videoCopyInstructionsMetadata) {
      this.showCopyInstructionsForm = true;
    }
    if (publishLineItem && publishLineItem.publishInstructionsMetadata) {
      this.showPublishInstructionsForm = true;
    }
  }

  findVersions(lineItem) {
    let versionIds = [];
    // tslint:disable-next-line:forin
    for (const endpoint in lineItem.endpoint_info) {
      forEach(lineItem.endpoint_info[endpoint], version => versionIds.push(version.id));
    }
    return versionIds;
  }

  updateOrderData(event) {
    if (this.modalType === 'addVersion') {
      this.addVersionToClip(event);
    } else {
      this.order = event;
    }
  }

  updatePublishOrderInstructions(event, type) {
    if (type === 'copy') {
      this.selectedCopyInstructions = event;
    } else if (type === 'publish') {
      this.selectedPublishInstructions = event;
    }
  }

  handlePublishInstructionsValidation(type, event?) {
    if (type === 'publish') {
      this.isPublishFieldValid = event;
    } else if (type === 'copy') {
      this.isCopyFieldValid = event;
    }
    this.enableSubmitPublishInstructions = true;
    if (this.showPublishInstructionsForm) {
      this.enableSubmitPublishInstructions = this.enableSubmitPublishInstructions && this.isPublishFieldValid;
    }
    if (this.showCopyInstructionsForm) {
      this.enableSubmitPublishInstructions = this.enableSubmitPublishInstructions && this.isCopyFieldValid;
    }
  }

  hasQaTask(): boolean {
    return Boolean(find(this.order.lineItemsClipId, lineItem => {
      return Boolean(this.getActivityByTypeId(lineItem, 16));
    }));
  }

  getOrderProgress(lineItems) {
    this.progressArr = this.utilityService.getProgressObj(this.utilityService.getActivities(lineItems));
    this.progressArr = this.progressArr.filter(type => includes(this.orderTypeConfig[this.order.metadata['orderType']].tasks, type.type));
    let total = 0;
    let completed = 0;
    forEach(this.progressArr, item => {
      completed += item.completed;
      total += item.total;
    });
    this.progressTotal.total = total;
    this.progressTotal.completed = completed;
  }

  deleteVersion() {
    let payload = this.order;
    payload.lineItems = payload.lineItems.filter(lineitem => lineitem.id !== this.selectedLineItem.id);
    this.loadingMask.enableLoadingMask();
    this.pausePolling = true;
    this.subscriptions.add(this.orderProgressTrackerService.updateOrder(payload).subscribe(
      data => {
        this.loadingMask.disableLoadingMask();
        this.alerts.addSuccessAlerts('You deleted ' + '<strong>' + this.selectedLineItem.customConfig.version + '</strong>' + ' from '
          + '<strong>' + this.order.name + '</strong>');
        this.getOrderDetails();
        console.log('Success! You deleted version ' + this.selectedLineItem.id + '.');
      },
      error => {
        console.log('error deleting version');
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      }
    ));
  }

  deleteClip() {
    let payload = this.order;
    if (this.selectedLineItem.metadata[0].clipId) {
      payload.lineItems = payload.lineItems
        .filter(lineitem => this.selectedLineItem.metadata[0].clipId !== lineitem.metadata[0].clipId);
    } else {
      payload.lineItems = payload.lineItems
        .filter(lineitem => this.selectedLineItem.metadata[0].clipTitle !== lineitem.metadata[0].clipTitle);
    }
    this.loadingMask.enableLoadingMask();
    this.pausePolling = true;
    this.subscriptions.add(this.orderProgressTrackerService.updateOrder(payload).subscribe(
      data => {
        this.loadingMask.disableLoadingMask();
        this.alerts.addSuccessAlerts('<strong>' + this.selectedLineItem.metadata[0].clipTitle
          + '</strong>' + ' has been deleted from the order.');
        this.getOrderDetails();
        console.log('Success! You deleted clip ' + this.selectedLineItem.metadata[0].clipTitle + '.');
      },
      error => {
        console.log('error deleting clip');
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      }
    ));
  }

  contentChanged(event) {
    this.modifyOrderObj.instructions.description = event.content;
  }

  getFormatActivity(item: LineItem) {
    if (typeof item !== 'undefined') {
      return this.utilityService.getLineItemActivity(1, item);
    }
  }

  onOpenAddModal() {
    setTimeout(() => {
      this.initializeEditor = true;
      if (this.modalType === 'addVersion') {
        this.clearModal();
      }
    });
    if (this.modalType === 'editVersion') {
      this.populateModifyOrderObject();
    }
  }

  onOpenPublishModal() {
    setTimeout(() => {
      this.initializePublishEditor = true;
    });
  }

  populateModifyOrderObject() {
    if (this.order.metadata['orderType'].toLowerCase() === 'video') {
      this.modifyOrderObj.instructions.title = this.selectedLineItem.customConfig.version;
      this.modifyOrderObj.endpoint = this.selectedLineItem.customConfig.endpoint;
      this.modifyOrderObj.schedule.publishOn.date = moment(this.selectedLineItem.publishDateTime).format('YYYY-MM-DD');
      this.modifyOrderObj.schedule.publishOn.time = moment(this.selectedLineItem.publishDateTime).format('hh:mm A');
    } else {
      this.modifyOrderObj.instructions.description = this.order.lineItems[0].activities[0].description;
      this.selectedLineItem = this.order.lineItems[0];
      if (this.order.metadata['orderType'].toLowerCase() === 'copy') {
        this.modifyOrderObj.instructions.brandName = '';
        if (this.order.lineItems[0].activities[0].instructions.length > 0) {
          this.modifyOrderObj.instructions.brandName = this.order.lineItems[0].activities[0].instructions[0].values[0];
        }
      }
    }
    this.modifyOrderObj.schedule.dueBy.date = moment(this.selectedLineItem.dueDateTime).format('YYYY-MM-DD');
    this.modifyOrderObj.schedule.dueBy.time = moment(this.selectedLineItem.dueDateTime).format('hh:mm A');
  }

  onSelectNameNotify(event) {
    this.isLoadingAssignee = true;
    const payload = {
      orderId: event.id,
      assigneeEmail: event.assigneeEmail,
      assignedByEmail: event.assignedByEmail,
      teamId: event.teamId
    };
    this.subscriptions.add(this.ordersService.setOrderOwner(payload).subscribe(
      (data) => {
        this.ordersService.getOrderDetails(this.orderId).subscribe(
          orderData => {
            this.order['assigneeName'] = orderData.assigneeName;
            this.order['teamName'] = orderData.teamName;
            this.isLoadingAssignee = false;
          });
      },
      (error) => {
        this.alerts.addErrorAlerts('Error: Order owner could not be updated. Please try again.');
        this.isLoadingAssignee = false;
      }
    ));
  }

  onSelectTaskNameNotify(payload: any, activity) {
    activity.isLoading = true;
    this.subscriptions.add(this.activitiesService.assignActivity(payload)
    .subscribe(
      data => {
        activity.assignedUserName = data[0].assignedUserName;
        activity.assignedUserEmail = data[0].assignedUserEmail;
        activity.teamName = data[0].teamName;
        activity.teamId = data[0].teamId;
        activity.isLoading = false;
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        activity.isLoading = false;
      }
    ));
  }

  onUpdateWatchersNotify(payload) {
    let editWatchersObservable = [];
    let alertMsg;
    if (payload.toBeAdded.length === 1 && payload.toBeAdded[0] === this.userInfo.email && payload.toBeRemoved.length === 0) {
      alertMsg = 'You\'re now watching this Order. You can change your notifications in <a href="/settings/" target="_blank">User Settings</a>.';
    } else if (payload.toBeAdded.length === 0 && payload.toBeRemoved.length === 1 && payload.toBeRemoved[0] === this.userInfo.email) {
      alertMsg = 'You\'ve stopped watching this Order.';
    } else {
      alertMsg = 'Watchers have been updated successfully.';
    }
    if (payload.toBeAdded.length > 0) {
      const postPayload = {'watcherEmails': payload.toBeAdded, 'watcherAssignedBy': this.userInfo.email};
      editWatchersObservable.push(this.ordersService.watchOrder(this.orderId, postPayload));
    }
    if (payload.toBeRemoved.length > 0) {
      const postPayload = {'watcherEmails': payload.toBeRemoved, 'watcherAssignedBy': this.userInfo.email};
      editWatchersObservable.push(this.ordersService.unwatchOrder(this.orderId, postPayload));
    }
    forkJoin(editWatchersObservable).subscribe(
      (data) => {
        this.alerts.addSuccessAlerts(alertMsg);
        this.getOrderDetails();
      },
      (error) => {
        this.alerts.addErrorAlerts('There is an error watching this Order, please try again.');
      }
    );
  }

  updateOrderName(name) {
    this.orderProgressTrackerService.updateOrderName(this.order, name);
  }

  openTeamAssignmentDialog() {
    this.matDialog.open(this.tasksAssigmentDialog, {
      width: '560px',
      disableClose: true
    });
    this.userService.getAllTeams().subscribe((data: Array<any>) => {
      this.allTeams = cloneDeep (data);
      this.setTeamsAssignmentDefaultValues();
      this.constructTasksDisplayObj();
    },
    (error) => {
      console.log('Error:', error);
    });
  }

  onCloseModal() {
    this.initializeEditor = false;
    this.initializePublishEditor = false;
    this.isVideoInstructionsFormValid = true;
  }

  assignTasksLater(): void {
    this.ordersService.isNewSubmittedOrder = false;
    this.matDialog.closeAll();
  }

  clearModal() {
    this.modifyOrderObj.endpoint = '';
    this.modifyOrderObj.instructions.title = '';
    this.modifyOrderObj.instructions.description = '';
    this.modifyOrderObj.schedule.dueBy.date = 'reset';
    this.modifyOrderObj.schedule.dueBy.time = '';
    this.modifyOrderObj.schedule.publishOn.date = 'reset';
    this.modifyOrderObj.schedule.publishOn.time = '';
  }

  initializeOrderModification() {
    this.modifyOrderObj = {
      endpoint: '',
      instructions: {
        title: '',
        description: ''
      },
      schedule: {
        dueBy: {
          date: '',
          time: ''
        },
        publishOn: {
          date: '',
          time: ''
        }
      }
    };
  }

  ngOnDestroy() {
    if (this.shortPollingSubscription) {
      this.shortPollingSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
    this.loadingMask.disableLoadingMask();
  }
}
