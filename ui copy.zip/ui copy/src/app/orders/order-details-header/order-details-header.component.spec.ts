/* tslint:disable:no-unused-variable */
import { TestBed, async, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';
import 'rxjs/add/observable/of';

import { OrderStore } from '../../models/order-store';
import { UtilityService } from '../../services/utility.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { OrdersService } from '../orders/orders.service';

import { OrderDetailsHeaderComponent } from './order-details-header.component';
import { OrderDetailsHeaderService } from './order-details-header.service';

import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';
import { CatalogService } from '../../catalog/catalog.service';

xdescribe('OrderDetailsHeaderComponent', () => {
  let fixture, greeter, element, debugElem, app;
  let mockBackend, service;
  let lineItem = {
    current_state: {
      'status': "TO_DO"
    },
    metadata: {
      vm_id: 'abcd-efgh-ijkl-mnop'
    },
    activities: [
      {
        'typeId': 1,
        'assignedUserEmail': '',
        'subActivities': [
          {
            'typeId': 7,
            'assignedUserEmail': 'Samir.Patel@viacomcontractor.com',
            'current_state': {
              'status': "WAITING"
            },
          }
        ],
        'current_state': {
          'status': "TO_DO"
        },
      },
      {
        'typeId': 3,
        'assignedUserEmail': 'Samir.Patel@viacomcontractor.com',
        'subActivities': [
          {
            'typeId': 7,
            'assignedUserEmail': 'Samir.Patel@viacomcontractor.com',
            'current_state': {
              'status': "WAITING"
            },
          }
        ],
        'current_state': {
          'status': "TO_DO"
        },
      },
      {
        'typeId': 13,
        'assignedUserEmail': '',
        'subActivities': [],
        'current_state': {
          'status': "TO_DO"
        },
      }
    ]
  };
  let order = {
    id: 1111,
    to: 1233,
    order_for: 12312,
    creator: 'J Unit',
    name: 'TEST ORDER FOR J UNIT',
    metadata: {
    },
    dsid: 'VBDSID',
    current_milestone: {
      status: 'TO_DO',
      last_modified_date: '00000000',
      last_modified_by: 'J UNIT'
    },
    milestones: [{
      status: 'TO_DO',
      last_modified_date: '00000000',
      last_modified_by: 'J UNIT'
    }],
    lineItems: [lineItem],
    lineItemVmid: [lineItem]
  };

  let MockHeaderService = {
    get: () => {}
  };
  let MockOrderService = {
    getOrder: function(orderId) {
      return Observable.of(order);
    }
  };
  let MockCatalogService = {
    getItemDetails: function(vmid) {
      return Observable.of({vmid: 'abcd-efgh-ijkl-mnop', title: 'TEST CATALOG ITEM'});
    }
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule ],
      declarations: [ OrderDetailsHeaderComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        {provide: OrderDetailsHeaderService, useValue: MockHeaderService},
        {provide: OrdersService, useValue: MockOrderService},
        OrderStore,
        {
          provide: ActivatedRoute, useValue: {
            params: Observable.of({ id: 'test' })
          }
        },
        UtilityService,
        SystemAlertsService,
        EndpointProfileService,
        ConfigService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: HttpClient,
          useFactory: (http: Http)=>{ return http },
          deps: [Http]
        },
        EnvironmentService,
        ConfigurationManagerService,
        {provide: CatalogService, useValue: MockCatalogService}
      ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(OrderDetailsHeaderComponent);
    element = fixture.nativeElement;              // to access DOM element
    debugElem = fixture.debugElement;             // test helper
    //app = fixture.debugElement.componentInstance; // to access properties and methods
    app = fixture.componentInstance; // to access properties and methods
    //fixture.detectChanges();
  }));

  beforeEach(inject([OrderDetailsHeaderService, MockBackend], (s, m) => {
    service = s;
    mockBackend = m;
  }));

  it('should create header component', async(() => {
    expect(app).toBeDefined();
  }));

  it('should have orderSubHead defined', async(() => {
    app.initialize();
    expect(app.orderSubHead).toBeDefined();
  }));

  // it('should have headerInfo should have title - TEST CATALOG ITEM', async(() => {
  //   spyOn(MockHeaderService, 'get').and.returnValue(Observable.of(order));
  //   app.orderId = 1111;
  //   app.initialize();
  //   console.log('....headerInfo: ', app.headerInfo)
  //   expect(app.headerInfo.catalogInfo.title).toEqual('TEST CATALOG ITEM');
  // }));

});
