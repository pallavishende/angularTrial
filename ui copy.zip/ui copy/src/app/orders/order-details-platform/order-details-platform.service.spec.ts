/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';

import { OrderDetailsPlatformService } from './order-details-platform.service';
import { OrderStore } from '../../models/order-store';
import { Order } from '../../models/order';

import { SystemAlertsService } from '../../services/system-alerts.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { UtilityService } from '../../services/utility.service';
import { UserService } from '../../services/user.service';

import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';

xdescribe('OrderDetailsPlatformService', () => {
  let service, orderStore, mockBackend;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        OrderDetailsPlatformService,
        SystemAlertsService,
        ConfigService,
        EndpointProfileService,
        OrderStore,
        UtilityService,
        UserService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: HttpClient,
          useFactory: (http: Http) => http,
          deps: [Http],
        },
        EnvironmentService,
        ConfigurationManagerService
      ]
    });
  });
  beforeEach(inject([OrderDetailsPlatformService, OrderStore, MockBackend], (s, o, m) => {
    service = s;
    mockBackend = m;
    orderStore = o;
  }));

  it('should create an instance of the service', ()=> {
    expect(service).toBeTruthy();
  });

  it('#get should return a reference to the order stream', () => {
    let order: BehaviorSubject<Order> = new BehaviorSubject(new Order({}));
    let orderStream = order.asObservable();
    expect(service.get()).toEqual(orderStream);
  });

  it('#getOrderStore should return a reference to the order store', () => {
    expect(service.getOrderStore()).toEqual(orderStore);
  });

  it('#increasePlatforms should have 3 parameters', () => {
    expect(service.increasePlatforms.length).toEqual(3);
  });

  it('#decreasePlatforms should have 3 parameters', () => {
    expect(service.decreasePlatforms.length).toEqual(3);
  });
});
