/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';

import { OrderDetailsScheduleService } from './order-details-schedule.service';
import { OrderStore } from '../../models/order-store';
import { Order } from '../../models/order';

import { SystemAlertsService } from '../../services/system-alerts.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { UtilityService } from '../../services/utility.service';
import { UserService } from '../../services/user.service';

import { AuthHttp } from "ng2-adal/dist/core";
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';

xdescribe('OrderDetailsScheduleService', () => {
  let service, orderStore, mockBackend;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        OrderDetailsScheduleService,
        SystemAlertsService,
        ConfigService,
        EndpointProfileService,
        OrderStore,
        UtilityService,
        UserService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: AuthHttp,
          useFactory: (http: Http) => http,
          deps: [Http],
        },
        EnvironmentService,
        ConfigurationManagerService
      ]
    });
  });

  beforeEach(inject([OrderDetailsScheduleService, OrderStore, MockBackend], (s, o, m) => {
    service = s;
    mockBackend = m;
    orderStore = o;
  }));

  it('should create instance of the service', () => {
    expect(service).toBeTruthy();
  });

  it('#isValidDate should return false for only 1 parameter ', () => {
    let ddt = "2017-05-16T15:00:00.000Z";
   // expect(service.isValidDate(ddt)).toBeFalsy();
   expect(service.isValidDate(ddt)).toBeTruthy();
  });

  it('#isValidDate should return true for valid due(2017-05-16T15:00:00.000Z) and publish(2017-05-24T15:00:00.000Z) dates', () => {
    let ddt = "2017-05-16T15:00:00.000Z";
    let pdt = "2017-05-24T15:00:00.000Z";
    expect(service.isValidDate(ddt,pdt)).toBeTruthy();
  });

  it('#isValidDate should return false for same due and publish dates(2017-05-16T15:00:00.000Z)', () => {
    let ddt = "2017-05-16T15:00:00.000Z";
    let pdt = "2017-05-16T15:00:00.000Z";
    expect(service.isValidDate(ddt,pdt)).toBeFalsy;
  });

  it('#get should return a reference to the order stream', () => {
    let order: BehaviorSubject<Order> = new BehaviorSubject(new Order({}));
    let orderStream = order.asObservable();
    expect(service.get()).toEqual(orderStream);
  });

  it('#getOrderStore should return a reference to the order store', () => {
    expect(service.getOrderStore()).toEqual(orderStore);
  });

});
