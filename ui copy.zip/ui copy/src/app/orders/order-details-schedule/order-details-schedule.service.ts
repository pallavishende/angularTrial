import { Injectable } from '@angular/core';
import { OrderStore } from '../../models/order-store';
import * as moment from 'moment/moment';

@Injectable()
export class OrderDetailsScheduleService {
  order;

  constructor(private orderStore: OrderStore) { }

  get() {
    return this.orderStore.orderStream;
  }

  getOrderStore() {
    return this.orderStore;
  }

  isValidDate(dueDate, publishDate) {
    if ( dueDate !== undefined || publishDate !== undefined ) {
      return moment.utc(publishDate) > moment.utc(dueDate);
    } else {
      return false;
    }
  }

  isTooSoon(dateTimeISO) {
    const now = new Date().getTime();
    const dateTime = new Date(dateTimeISO).getTime();
    return dateTime - now < 7200000 && dateTime > now;
  }

  isPast(dateTimeISO) {
    const now = new Date().getTime();
    const dateTime = new Date(dateTimeISO).getTime();
    return dateTime < now;
  }
  
  isDateFiveDaysFurther(dateTimeISO) {
    let fiveFuture = new Date();
    fiveFuture.setDate(fiveFuture.getDate() + 5);
    const now = fiveFuture.getTime();
    const dateTime = new Date(dateTimeISO).getTime();
    return dateTime < now;
  }
}
