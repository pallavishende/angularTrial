import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as _ from 'lodash';
import * as moment from 'moment/moment';
import { Subscription } from 'rxjs';
import { Activity } from '../../models/activity';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrdersService } from '../orders/orders.service';
import { OrderDetailsScheduleService } from './order-details-schedule.service';
import { EnvironmentService } from '../../services/environment.service';

@Component({
  selector: 'app-order-details-schedule',
  templateUrl: './order-details-schedule.component.html',
  styleUrls: ['./order-details-schedule.component.scss', '../order-customization-base/order-customization-base.component.scss']
})
export class OrderDetailsScheduleComponent implements OnInit, OnDestroy {
  order;
  today;
  uniqueLineItems;
  subscriptions = new Subscription();
  endpointProfiles;
  isEnvGreaterThanUAT = false;
  reasonForDueDate = '';
  requestTypeVmn = false;
  dateType = {
    DUE: 1,
    PUBLISH: 2
  };

  constructor(
    private alerts: SystemAlertsService,
    private ordersService: OrdersService,
    private orderDetailsScheduleService: OrderDetailsScheduleService,
    private endpointProfileService: EndpointProfileService,
    private orderProgressTrackerService: OrderProgressTrackerService,
    private activatedRoute: ActivatedRoute,
    private environmentService: EnvironmentService) {
    this.alerts = alerts;
    this.isEnvGreaterThanUAT = this.environmentService.isRuntimeEnvironmentGreaterThan(3);
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe(data => {
      this.orderProgressTrackerService.saveRouteData(data);
    });
    this.today =  moment().format('YYYY-MM-DD').toString();
    this.subscriptions.add(this.orderDetailsScheduleService.get()
    .subscribe(
      data => {
        if (data.lineItems && data.lineItems.length > 0) {
          this.order = data;
          this.ordersService.setOrdersPageTitle(this.order.name + ' - Draft - Viacom Bridge');
            if (this.order.metadata.orderType.toLowerCase() !== 'video') {
            this.initializeDueDateTime();
          }
          this.subscriptions.add(this.endpointProfileService.getEndpointProfiles().subscribe(
            data => {
              this.endpointProfiles = data;
            }
          ));
        }
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  applyToAll(item, type) {
    const localOrderDetailsScheduleService = this.orderDetailsScheduleService;  // maintain ref
    const localDateType = this.dateType;  // maintain ref

    _.forEach(this.order.lineItems, function(lineItem) {
      if ( type === localDateType.DUE ) {
        _.set(lineItem, 'customConfig.dueByDate', _.get(item, 'customConfig.dueByDate'));
        _.set(lineItem, 'customConfig.dueByTime', _.get(item, 'customConfig.dueByTime'));
        _.set(lineItem, 'dueDateTime', _.get(item, 'dueDateTime'));
      } else {
        _.set(lineItem, 'customConfig.publishOnDate', _.get(item, 'customConfig.publishOnDate'));
        _.set(lineItem, 'customConfig.publishOnTime', _.get(item, 'customConfig.publishOnTime'));
        _.set(lineItem, 'publishDateTime', _.get(item, 'publishDateTime'));
      }
      if ( lineItem.publishDateTime ) {
        if ( localOrderDetailsScheduleService.isPast(_.get(lineItem, 'publishDateTime')) ) {
          _.set(lineItem, 'publishDatePastError', true);
        } else {
          _.set(lineItem, 'publishDatePastError', false);
        }
      }
      if ( lineItem.dueDateTime ) {
        if ( localOrderDetailsScheduleService.isTooSoon(_.get(lineItem, 'dueDateTime')) ) {
          _.set(lineItem, 'dateWarning', true);
        } else {
          _.set(lineItem, 'dateWarning', false);
        }
        if ( localOrderDetailsScheduleService.isPast(_.get(lineItem, 'dueDateTime')) ) {
          _.set(lineItem, 'dueDatePastError', true);
        } else {
          _.set(lineItem, 'dueDatePastError', false);
        }
        if ( lineItem.publishDateTime ) {
          if ( localOrderDetailsScheduleService.isValidDate(_.get(lineItem, 'dueDateTime'), _.get(lineItem, 'publishDateTime') )) {
            _.set(lineItem, 'dateError', false);
          } else {
            _.set(lineItem, 'dateError', true);
          }
        }
      }
    });
    this.orderDetailsScheduleService.getOrderStore().notify();
  }

  saveToModel(item) {
    if (!item.customConfig['dueByTime']) {
      item.customConfig['dueByTime'] = '12:00 PM';
    } else if (!item.customConfig['publishOnTime']) {
      item.customConfig['publishOnTime'] = '12:00 PM';
    }
    _.set(item, 'dateError', false);
    _.set(item, 'dateWarning', false);
    _.set(item, 'dueDatePastError', false);
    _.set(item, 'publishDatePastError', false);

    const dueDateTime = new Date(item.customConfig['dueByDate'] + ' ' + item.customConfig['dueByTime']);
    const publishDateTime = new Date(item.customConfig['publishOnDate'] + ' ' + item.customConfig['publishOnTime']);
    item['dueDateTime'] = moment.utc(dueDateTime).toISOString();
    item['publishDateTime'] = moment.utc(publishDateTime).toISOString();

    if (!this.timeValidator(item.customConfig['dueByTime']) || !moment(item.customConfig['dueByDate'], 'MM/DD/YYYY').isValid()) {
      item['dueDateTime'] = '';
    } else if (!this.timeValidator(item.customConfig['publishOnTime'])
    || !moment(item.customConfig['publishOnDate'], 'MM/DD/YYYY').isValid()) {
      item['publishDateTime'] = '';
    }

    this.orderDetailsScheduleService.getOrderStore().notify();

    try {
      if ( publishDateTime.toString() !== 'Invalid date' && moment(publishDateTime).isValid()) {
        if ( this.orderDetailsScheduleService.isPast(_.get(item, 'publishDateTime')) ) {
          _.set(item, 'publishDatePastError', true);
        } else {
          _.set(item, 'publishDatePastError', false);
        }
      }
      if ( dueDateTime.toString() !== 'Invalid date' && moment(dueDateTime).isValid() ) {
        if ( this.orderDetailsScheduleService.isTooSoon(_.get(item, 'dueDateTime')) ) {
          _.set(item, 'dateWarning', true);
        } else {
          _.set(item, 'dateWarning', false);
        }
        if ( this.orderDetailsScheduleService.isPast(_.get(item, 'dueDateTime')) ) {
          _.set(item, 'dueDatePastError', true);
        } else {
          _.set(item, 'dueDatePastError', false);
        }
        if ( publishDateTime.toString() !== 'Invalid date' && moment(publishDateTime).isValid()) {
          if ( this.orderDetailsScheduleService.isValidDate(_.get(item, 'dueDateTime'), _.get(item, 'publishDateTime') )) {
            _.set(item, 'dateError', false);
          } else {
            _.set(item, 'dateError', true);
          }
        }
      }
    } catch (e) {
      console.log('Date not in proper format.');
    }
  }

  saveNonVideoContentToModel(event, dataType) {
    const orderStore = this.orderDetailsScheduleService.getOrderStore();

    _.set(this.order.lineItems[0], 'dateError', false);
    _.set(this.order.lineItems[0], 'dateWarning', false);
    _.set(this.order.lineItems[0], 'dueDatePastError', false);
    _.set(this.order.lineItems[0], 'launchDatePastError', false);

    if (dataType === 'dueByDate') {
      if (!moment(event.date, 'MM/DD/YYYY').isValid()) {
        this.order.lineItems[0].dueByDate = event.date;
        this.order.lineItems[0].dueDateTime = undefined;
        orderStore.notify();
        return;
      }
      if (!this.order.lineItems[0].dueByTime) {
        this.order.lineItems[0].dueByTime = '12:00 PM';
      }
      this.order.lineItems[0].dueByDate = event.date;
    } else if (dataType === 'dueByTime') {
      if (!this.timeValidator(event.time)) {
        this.order.lineItems[0].dueByTime = event.time;
        this.order.lineItems[0].dueDateTime = undefined;
        orderStore.notify();
        return;
      } else {
        this.order.lineItems[0].dueByTime = event.time;
      }
    } else if (dataType === 'launchByDate') {
      if (!moment(event.date, 'MM/DD/YYYY').isValid()) {
        this.order.lineItems[0].launchByDate = event.date;
        if(event.isFilled && !event.isValid && this.order.metadata.orderType.toLowerCase() === 'site_app_updates') {
          this.order.lineItems[0].launchDateTime = 'notValid';
          if (!this.order.lineItems[0].launchByTime) {
            this.order.lineItems[0].launchByTime = '12:00 PM';
          }
        } else {
          this.order.lineItems[0].launchDateTime = undefined;
        }
        this.order.lineItems[0].launchDateError = event.isFilled && !event.isValid;
        orderStore.notify();
        return;
      }
      if (!this.order.lineItems[0].launchByTime) {
        this.order.lineItems[0].launchByTime = '12:00 PM';
      }
      this.order.lineItems[0].launchByDate = event.date;
      _.set(this.order.lineItems[0], 'launchDateError', false);
    } else if (dataType === 'launchByTime') {
      if (!this.timeValidator(event.time)) {
        this.order.lineItems[0].launchByTime = event.time;
        this.order.lineItems[0].launchDateTime = undefined;
        orderStore.notify();
        return;
      } else {
        this.order.lineItems[0].launchByTime = event.time;
      }
    }
    
    let request = this.order.lineItems[0].activities[0].instructions.filter(item => item.label === 'requestType')[0];

    if (this.order.lineItems[0]['dueByDate'] && this.order.lineItems[0]['dueByTime']) {
      if (moment(this.order.lineItems[0]['dueByDate'], ['YYYY-MM-DD', 'MM/DD/YYYY']).isValid()
      && this.timeValidator(this.order.lineItems[0]['dueByTime'])) {
        const dueDateTime = new Date(this.order.lineItems[0]['dueByDate'] + ' ' + this.order.lineItems[0]['dueByTime']);
        this.order.lineItems[0].dueDateTime = moment.utc(dueDateTime).toISOString();
        this.order.lineItems[0].dateWarning = this.orderDetailsScheduleService.isTooSoon(this.order.lineItems[0].dueDateTime);
        this.order.lineItems[0].dueDatePastError = this.orderDetailsScheduleService.isPast(this.order.lineItems[0].dueDateTime);
        if(this.order.metadata.orderType.toLowerCase() === 'graphics' && request && request.values[0] === 'VMN' && !this.isEnvGreaterThanUAT) {
          this.order.lineItems[0].dueDateFiveDaysError = this.orderDetailsScheduleService.isDateFiveDaysFurther(this.order.lineItems[0].dueDateTime);
        }
      }
    }
    if (this.order.lineItems[0]['launchByDate'] && this.order.lineItems[0]['launchByTime']) {
      if (moment(this.order.lineItems[0]['launchByDate'], ['YYYY-MM-DD', 'MM/DD/YYYY']).isValid()
      && this.timeValidator(this.order.lineItems[0]['launchByTime'])) {
        const launchDateTime = new Date(this.order.lineItems[0]['launchByDate'] + ' ' + this.order.lineItems[0]['launchByTime']);
        this.order.lineItems[0].launchDateTime = moment.utc(launchDateTime).toISOString();
        this.order.lineItems[0].launchDatePastError = this.orderDetailsScheduleService.isPast(this.order.lineItems[0].launchDateTime);
        this.order.lineItems[0].dateError = !this.orderDetailsScheduleService.isValidDate(this.order.lineItems[0].dueDateTime, this.order.lineItems[0].launchDateTime);
      }
    }
    if(request && request.values[0] !== 'VMN') {
      this.order.lineItems[0].launchDateTime = undefined;
    }
    orderStore.updateCurrentOrder(this.order);
  }

  updateReason(event) {

    if (typeof event === 'string') {
      let reason = event.trim() !== '' ? event : '';
      if (reason !== undefined) {
        let index = this.order.lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'dueDateReason');
        if(index >= 0) {
          this.order.lineItems[0].activities[0].instructions[index].values = [reason];
        } else {
            this.order.lineItems[0].activities[0].instructions.push({
              label: 'dueDateReason',
              values: [reason],
              type: ''
            })
        }
        this.orderDetailsScheduleService.getOrderStore().updateCurrentOrder(this.order);
      }
    }
  }

  // for non-video orders, i.e. copy and graphics
  initializeDueDateTime() {
    const currentOrderDueDateTime = this.order.lineItems[0].dueDateTime;
    if (currentOrderDueDateTime) {
      this.order.lineItems[0].dateWarning = this.orderDetailsScheduleService.isTooSoon(currentOrderDueDateTime);
      this.order.lineItems[0].dueDatePastError = this.orderDetailsScheduleService.isPast(currentOrderDueDateTime);
      if (!this.order.lineItems[0].dueByDate) {
        this.order.lineItems[0].dueByDate = moment(currentOrderDueDateTime).format('YYYY-MM-DD');
      }
      if (!this.order.lineItems[0].dueByTime) {
        this.order.lineItems[0].dueByTime = moment(currentOrderDueDateTime).format('hh:mm A');
      }
    }
    if (this.getApprovableActivities(this.order.lineItems[0].activities, 14) || this.getApprovableActivities(this.order.lineItems[0].activities, 5)) {
      const currentOrderLaunchDateTime = this.order.lineItems[0].launchDateTime;
      if (currentOrderLaunchDateTime) {
        this.order.lineItems[0].launchDateWarning = this.orderDetailsScheduleService.isTooSoon(currentOrderLaunchDateTime);
        this.order.lineItems[0].launchDatePastError = this.orderDetailsScheduleService.isPast(currentOrderLaunchDateTime);
        if (!this.order.lineItems[0].launchByDate) {
          this.order.lineItems[0].launchByDate = moment(currentOrderLaunchDateTime).format('YYYY-MM-DD');
        }
        if (!this.order.lineItems[0].launchByTime) {
          this.order.lineItems[0].launchByTime = moment(currentOrderLaunchDateTime).format('hh:mm A');
        }
      }
    }
    if(this.order.metadata.orderType.toLowerCase() === 'graphics' && !this.isEnvGreaterThanUAT) {
        let requestIndex = this.order.lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'requestType');
        let index = this.order.lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'dueDateReason');
        if(requestIndex > 0 && this.order.lineItems[0].activities[0].instructions[requestIndex].values[0] === 'VMN') {
          this.requestTypeVmn = true;
        } else {
          this.requestTypeVmn = false;
        }
        if(index > 0) {
          this.reasonForDueDate = this.order.lineItems[0].activities[0].instructions[index].values;
        } else {
          this.reasonForDueDate = '';
        }
    }
  }

  timeValidator(timeStr: string): boolean {
    if (!timeStr) {
      return false;
    }
    const parserColon = timeStr.indexOf(':');
    const parserSpace = timeStr.indexOf(' ');
    const hourStr = timeStr.substr(0, parserColon);
    const minuteStr = timeStr.substr(parserColon + 1, parserSpace - parserColon - 1);
    const periodStr = timeStr.substr(parserSpace + 1);
    const h = Number(hourStr);
    const m = Number(minuteStr);
    if (h > 0 && h <= 12) {
      if (m >= 0 && m < 60 && minuteStr.length === 2) {
        if (periodStr === 'AM' || periodStr === 'PM') {
          return true;
        }
      }
    }
    return false;
  }

  getApprovableActivities(activities: Array<Activity>, typeId): boolean {
    return (_.find(activities, {'typeId': typeId})) ? true : false;
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
