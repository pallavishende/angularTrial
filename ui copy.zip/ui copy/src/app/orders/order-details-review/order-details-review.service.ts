import { Injectable } from '@angular/core';
import { Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { OrderStore } from '../../models/order-store';

import * as _ from 'lodash';
import { listenToElementOutputs } from '@angular/core/src/view/element';

@Injectable()
export class OrderDetailsReviewService {
  order;

  constructor(private orderStore: OrderStore) { }

  get() {
    return this.orderStore.orderStream;
  }

  getOrderStore() {
    return this.orderStore;
  }

  updateOrderStore(item) {
    let orderStore = this.getOrderStore();
    orderStore.updateExistingLineItem(item);
  }

  removeLineItemsFromOrder(clipIdentifier) {
    let orderStore = this.getOrderStore();
    console.log('service > removeLineItemsFromOrder > clipTitle: ', clipIdentifier.value );
    orderStore.removeLineItemsByProperty(clipIdentifier.property, clipIdentifier.value);
  }

  getGraphicsOrderSummary(graphicsInstrFormFields, instructions) {
    
    let instructionMap = {};
    let platformList = [];
    let brandName;
    let platformNames = [];
    const orderGraphicsFormFields = graphicsInstrFormFields;
    //console.log(instructions);
    if(instructions && instructions.length > 0) {
      let requestIndex = this.getInstructionsIndex(instructions, 'requestType');
      if(requestIndex >= 0) {
        let requestType = instructions[requestIndex].values[0];
        if(requestType === 'VMN') {
          let resultForm = instructions.filter(inst => inst.type === '');
          
          if(resultForm.length > 0) {
            resultForm.map(f => {
              if(f.label !== 'platformList') {
                instructionMap[f.label] = f.values[0];
              }
            })
          }
          
          let brandIndex = this.getInstructionsIndex(instructions, 'brand');
          if(brandIndex >= 0) {
            let brandCode = instructions[brandIndex].values[0];
            brandName = orderGraphicsFormFields.BrandDropDown.filter(b => b.id === brandCode)[0];
            instructionMap['brand'] = brandName['value'];
            platformNames = brandName['options'];
          }
          
          let inx = this.getInstructionsIndex(instructions, 'platformList');
          let platformLst = [];
          if(inx >= 0) {
            
            let platformLstBkp = instructions[inx].values;
            platformNames.forEach(pltName => {
              if(platformLstBkp.findIndex(plt => plt === pltName.id) >= 0) {
                platformLst.push(pltName.id);
              }
            });

            if(platformLst && platformLst.length >= 0) {
              
              platformLst.forEach(platform => {
                const specification = orderGraphicsFormFields.RequestType[platform][0].options;
                
                let specificationMap = {};
                if(specification) {
                  specification.map(spe => {
                    specificationMap[spe.key] = spe.label;
                  });
                }
               
                let result = instructions.filter(inst => inst.type === platform);
                if(result && result.length >= 0) {
                  let options = [];
                  let specsList = [];
                  let cta = undefined;
                  result.forEach(res => {
                    if(res.label === 'CTA') {
                      let label = 'Copy';
                      cta = {label: label, value: res.values[0]};
                    } else if(res.label === 'dimensions') {
                      let label = 'Dimensions';
                      options.push({label: label, value: res.values[0]});
                    } else if(res.label === 'Description') {
                      let label = 'Description';
                      options.push({label: label, value: res.values[0]});
                    } else {
                      specsList.push(specificationMap[res.label]);
                    }
                  });
                  
                  let platFormName = brandName['options'].filter(opt => opt.id === platform)[0].value;
                  if(specsList.length > 0) {
                    options.unshift({label: 'Specs', value: specsList});
                  }
                  if(cta) {
                    options.push(cta);
                  }
                  //if(options && options.length > 0) {
                    platformList.push({platformName: platFormName, options});
                  //}
                }
              });
            }
          }
        }
      }

    }
    return {instructionMap: instructionMap, platformList: platformList};
  }

  getInstructionsIndex(instructions, label) {
    return instructions.findIndex(inst => inst.label === label);
  }
  
}
