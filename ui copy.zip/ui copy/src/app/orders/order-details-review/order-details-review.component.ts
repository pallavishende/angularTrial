import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/map';
import { LineItem } from '../../models/line-item';
import { OrdersService } from '../orders/orders.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrderDetailsReviewService } from './order-details-review.service';
import { OrderDetailsFormatService } from '../order-details-format/order-details-format.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { UserService } from '../../services/user.service';
import { OrderInstructionFormFields } from '../../models/generic-form-field';
import * as _ from 'lodash';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { EnvironmentService } from '../../services/environment.service';

const orderInstructionsFormFields = require('../../models/mock-payloads/order-instructions-form-fields.json');

@Component({
  selector: 'app-order-details-review',
  templateUrl: './order-details-review.component.html',
  styleUrls: ['./order-details-review.component.scss', '../order-customization-base/order-customization-base.component.scss'],
  providers: [OrderDetailsReviewService]
})
export class OrderDetailsReviewComponent implements OnInit, OnDestroy {
  order;
  users;
  endpointProfiles;
  subscriptions = new Subscription();
  selectedSection;
  instructionsFormFields: OrderInstructionFormFields;
  isEnvGreaterThanDev = false;
  graphicsInstrFormFields;
  requestType: string;
  instructionMap = {};
  platformList = [];

  constructor(
    private ordersService: OrdersService,
    private orderDetailsReviewService: OrderDetailsReviewService,
    private endpointProfileService: EndpointProfileService,
    private userService: UserService,
    private orderProgressTrackerService: OrderProgressTrackerService,
    private orderDetailsFormatService: OrderDetailsFormatService,
    private environmentService: EnvironmentService,
    private activatedRoute: ActivatedRoute,
    private alerts: SystemAlertsService
  ) {
    this.isEnvGreaterThanDev = this.environmentService.isRuntimeEnvironmentGreaterThan(3);
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe(data => {
      this.orderProgressTrackerService.saveRouteData(data);
    });
    this.subscriptions.add(this.orderDetailsFormatService.getOrderGraphicsFormFields().subscribe((data) => {
      this.graphicsInstrFormFields = data;
    }));
    this.subscriptions.add(this.orderDetailsReviewService.get().subscribe(
      data => {
        if (data.lineItems && data.lineItems.length > 0) {
          this.order = data;
          this.ordersService.setOrdersPageTitle(this.order.name + ' - Draft - Viacom Bridge');
          this.subscriptions.add(this.endpointProfileService.getEndpointProfiles().subscribe(
            data => {
              this.endpointProfiles = data;
              console.log('review > initialize > data > epdData > data: ', data);
            }
          ));
          if(this.order.metadata['orderType'] === 'GRAPHICS' && !this.isEnvGreaterThanDev) {
            let obj = this.orderDetailsReviewService.getGraphicsOrderSummary(this.graphicsInstrFormFields, this.order.lineItems[0].activities[0].instructions);
            let request = this.order.lineItems[0].activities[0].instructions.filter(item => item.label === 'requestType')[0] 
            this.requestType = request.values[0] ? request.values[0] : ''
            this.instructionMap = obj.instructionMap;
            this.platformList = obj.platformList;
            this.platformList.forEach(pltform => {
              pltform.options.forEach(option => {
                switch (option.label)
                {
                  case'Copy':
                    option.label = 'Copy or Special Instructions'
                    break;
                  case'SPECS':
                    option.label = 'Specs'
                    break;
                  case'Dimensions':
                    option.label = 'Custom Dimensions'
                    break;
                }
              });
            });
          }
        }
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
    this.instructionsFormFields = orderInstructionsFormFields;
  }

  getDisplayNameFromEmail(email: string) {
    let displayName = '';
    this.subscriptions.add(this.userService.getAllUsers().subscribe(
      data => {
        if ( data ) {
          this.users = data['content'];
          if ( email !== '' ) {
            let tmp = _.find(this.users, { 'login': email });
            displayName = tmp ? tmp['displayName'] : 'NA';
            return displayName;
          } else {
            displayName = 'Unassigned';
            return displayName;
          }
        }
      },
      error => {}
    ));
    return displayName;
  }

  getClipIdentifier(lineItem: LineItem) {
    const clipIdentifier = lineItem.metadata[0]['clipId'] || lineItem.metadata[0]['clipTitle'];
    return clipIdentifier;
  }

  getActivity(lineItem, typeId) {
    return _.filter(lineItem.activities, function(activity) {
      return activity['typeId'] === typeId;
    });
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
