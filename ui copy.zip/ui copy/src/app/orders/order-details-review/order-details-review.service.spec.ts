/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';

import { OrderStore } from '../../models/order-store';
import { Order } from '../../models/order';
import { OrdersService } from '../orders/orders.service';

import { SystemAlertsService } from '../../services/system-alerts.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { UtilityService } from '../../services/utility.service';
import { OrderDetailsReviewService } from './order-details-review.service';

import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';
import { UserService } from '../../services/user.service';
import { LoginService } from '../../login/login.service';
import { AdalService } from 'ng2-adal/dist/core';

xdescribe('OrderDetailsReviewService', () => {
  let service, orderStore, mockBackend;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        OrderDetailsReviewService,
        SystemAlertsService,
        ConfigService,
        EndpointProfileService,
        OrderStore,
        OrdersService,
        UtilityService,
        UserService,
        LoginService,
        AdalService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
         {
          provide: HttpClient,
          useFactory: (http: Http) => http,
          deps: [Http],
        },
        EnvironmentService,
        ConfigurationManagerService
      ]
    });
  });

  beforeEach(inject([OrderDetailsReviewService, OrderStore, MockBackend], (s, o, m) => {
    service = s;
    mockBackend = m;
    orderStore = o;
  }));

  it('should create an instance of the service', ()=> {
    expect(service).toBeTruthy();
  });
});
