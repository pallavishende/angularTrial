import { Component, OnInit, OnChanges, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, RouterStateSnapshot } from '@angular/router';
import { OrdersService } from '../orders/orders.service';
import { OrderDetailsFormatService } from './order-details-format.service';
import { OrderDetailsPlatformService } from '../order-details-platform/order-details-platform.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrderDetailsPackageService } from '../order-details-package/order-details-package.service';
import { UtilityService } from '../../services/utility.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Subscription } from 'rxjs/Subscription';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { LineItem } from '../../models/line-item';
import { Activity, Instructions } from '../../models/activity';
import { OrderInstructionFormFields } from '../../models/generic-form-field';
import { ENTER } from '@angular/cdk/keycodes';
import { EnvironmentService } from '../../services/environment.service';
import { CatalogService } from '../../catalog/catalog.service';
import { RequestformService } from '../../shared/dynamic-form/request-form.service';
import { DynamicFormBaseService } from '../../shared/dynamic-form/dynamic-form-control.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-order-details-format',
  templateUrl: './order-details-format.component.html',
  styleUrls: ['../../catalog/catalog-base/catalog-base.component.scss','./order-details-format.component.scss', '../order-customization-base/order-customization-base.component.scss'],
  providers: [
    OrderDetailsFormatService,
    OrderDetailsPlatformService,
    OrderDetailsPackageService,
    RequestformService,
    DynamicFormBaseService
  ]
})

export class OrderDetailsFormatComponent implements OnInit, OnChanges, OnDestroy {

  @ViewChild('confirmModal') confirmModal: ElementRef;

  order;
  subscriptions = new Subscription();
  dataObservable: Observable<{}>;
  selectedVersionIndex: number;
  counter: number;
  endpointProfiles;
  isNewLineitemAdded = false;
  deleteModalOptions = {
    version: 'NA',
    msg: '',
    btnMsg: '',
    action: {}
  };
  confirmModalOptions = {
    heading: '',
    msg: '',
    btnMsg: '',
    action: {}
  };
  isUpdatingOrder = false;
  instructionsFormFields: OrderInstructionFormFields;
  publishingFormFields: OrderInstructionFormFields;
  videoCopyFormFields: OrderInstructionFormFields;
  publishingFormToggle = {};
  updateCustomEditor = new Subject<any>();
  separatorKeysCodes: number[] = [ENTER];
  isEnvGreaterThanUAT = false;
  
  formControls = [];
  graphicsRequestForm: FormGroup;
  graphicsSelectedRequest = [];
  graphicsInstrFormFields;
  graphicsInstrStaticFormFields;
  graphicInstructions = [];
  addNewPlatform = true;
  platformTypeList = [];
  contenBrandName = '';
  editorDimensionTextArea = '300px';
  hideAddPlatform = false;
  graphicsBrandName = {
    id: '',
    value: '',
    options: []
  };

  graphicsRequestType = {
    id: '',
    value: ''
  };

  graphicsPLatformType = {
    id: '',
    value: ''
  };

  constructor(
    private router: Router,
    private ordersService: OrdersService,
    private orderDetailsFormatService: OrderDetailsFormatService,
    private orderDetailsPlatformService: OrderDetailsPlatformService,
    private orderDetailsPackageService: OrderDetailsPackageService,
    private orderProgressTrackerService: OrderProgressTrackerService,
    private utilityService: UtilityService,
    private endpointProfileService: EndpointProfileService,
    private alerts: SystemAlertsService,
    private activatedRoute: ActivatedRoute,
    private environmentService: EnvironmentService,
    private requestformService: RequestformService,
    private dynamicFormBaseService: DynamicFormBaseService,
    private catalogService: CatalogService,
    private loadingMaskService: LoadingMaskService,
    private fb: FormBuilder
  ) {
    this.isEnvGreaterThanUAT = this.environmentService.isRuntimeEnvironmentGreaterThan(3);
  }

  ngOnInit() {
    this.ordersService.setOrdersPageTitle('Draft - Viacom Bridge');
    this.activatedRoute.data.subscribe(data => {
      this.orderProgressTrackerService.saveRouteData(data);
    });
    
    this.initialize();
    this.loadingMaskService.enableLoadingMask();
    
    setTimeout(() => {
      if (this.order.metadata.orderType === 'GRAPHICS' && !this.isEnvGreaterThanUAT) {
        this.editorDimensionTextArea = '190px';
        this.setGraphicsDropDown();
        //this.setGraphicsOrderInstructions();
      } else {
        this.loadingMaskService.disableLoadingMask();
      }
    }, 2500);
  }

  initializeInstructionsForm() {
    this.subscriptions.add(this.orderDetailsFormatService.getOrderInstructictionsFormFields().subscribe((data: OrderInstructionFormFields) => {
      this.instructionsFormFields = data;
    }));
    this.subscriptions.add(this.orderDetailsFormatService.getOrderPublishingFormFields().subscribe((data: OrderInstructionFormFields) => {
      this.publishingFormFields = data;
    }));
    this.subscriptions.add(this.orderDetailsFormatService.getOrderVideoCopyFormFields().subscribe((data: OrderInstructionFormFields) => {
      this.videoCopyFormFields = data;
    }));
    this.subscriptions.add(this.orderDetailsFormatService.getOrderGraphicsFormFields().subscribe((data: OrderInstructionFormFields) => {
      this.graphicsInstrFormFields = data;
      this.graphicsInstrStaticFormFields = this.graphicsInstrFormFields['graphicsDetailForm'];
    }));
  }

  initialize() {
   
    this.initializeInstructionsForm();
    this.dataObservable = this.orderDetailsFormatService.get();
    this.loadingMaskService.enableLoadingMask();
    this.subscriptions.add(this.dataObservable.subscribe(
      data => {
        const snapshot: RouterStateSnapshot = this.router.routerState.snapshot;
        const orderId = snapshot.url.substring(8, snapshot.url.indexOf('/draft'));
        if (data['id'] && data['id'].toString() === orderId) {
          console.log('format > data: ', data);
          this.order = data;
          if (this.order.name) {
            this.ordersService.setOrdersPageTitle(this.order.name + ' - Draft - Viacom Bridge');
          }
          if (this.order.metadata.orderType !== 'GRAPHICS') {
            this.loadingMaskService.disableLoadingMask();
          }
          this.subscriptions.add(this.endpointProfileService.getEndpointProfiles().subscribe(
            data2 => {
              this.endpointProfiles = data2;
            }
          ));
          this.initOrderActivities();
        }
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  handleTags(event, target: Array<string>, lineItem, remove?: boolean): string {
    if (remove) {
      _.pull(target, event);
      this.updateInstructionsForm(target, 'tags', lineItem, 'publishInstructions', true);
    } else {
      const input = event.input;
      const value = event.value.trim();
      if (value) {
        // clear input field
        if (input) {
          input.value = '';
        }
        if (!target) {
          target = [];
        }
        if (_.includes(target, value)) {
          return;
        }
        target.push(value);
        this.updateInstructionsForm(target, 'tags', lineItem, 'publishInstructions', true);
      }
    }
  }

  updateInstructionsForm(value: any, valueKey: string, lineItem: LineItem, type: string, isTextType?: boolean) {
    if (typeof value === 'string') {
      value = [value];
    }
    const metadataObj = {
      'label': valueKey,
      'values': value,
      'type': ''
    };
    let lineItemActivity: Activity;
    let formFields;
    switch (type) {
      case 'videoInstructions':
        lineItemActivity = this.utilityService.getLineItemActivity(1, lineItem);
        formFields = this.instructionsFormFields;
        break;
      case 'publishInstructions':
        lineItemActivity = this.utilityService.getLineItemActivity(13, lineItem);
        formFields = this.publishingFormFields;
        break;
      case 'videoCopyInstructions':
        lineItemActivity = this.utilityService.getLineItemActivity(13, lineItem);
        formFields = this.videoCopyFormFields;
        break;
      case 'graphicsInstructions':
        lineItemActivity = this.utilityService.getLineItemActivity(5, lineItem);
        formFields = this.graphicsInstrStaticFormFields;
        break;
    }
    const selectedMetadataItemIndex = this.getArrayItemIndex(lineItemActivity.instructions, valueKey);
    if (selectedMetadataItemIndex < 0) {
      if (value[0] && value[0].trim() !== '') {
        lineItemActivity.instructions.push(metadataObj);
      }
    } else {
      if (formFields[valueKey].multiSelection) {
        lineItemActivity.instructions[selectedMetadataItemIndex].values.push(value[0]);
      } else {
        if (isTextType) {
          if (formFields[valueKey].isRequiredField) {
            if (value[0].trim() !== '') {
              lineItemActivity.instructions[selectedMetadataItemIndex].values = value;
            } else if (valueKey === 'tags') {
              lineItemActivity.instructions[selectedMetadataItemIndex].values = value;
            } else {
              lineItemActivity.instructions.splice(selectedMetadataItemIndex, 1);
            }
          } else {
            if (value[0] !== '' || valueKey === 'adTargeting') {
              lineItemActivity.instructions[selectedMetadataItemIndex].values = value;
            } else {
              lineItemActivity.instructions.splice(selectedMetadataItemIndex, 1);
            }
          }
        } else {
          lineItemActivity.instructions[selectedMetadataItemIndex] = metadataObj;
        }
      }
    }
    /**
     * syncing istructions according to type
     */
    if (type === 'videoInstructions') {
      this.orderDetailsFormatService.getOrderStore().setVideoInstructionsMetadata(this.order);
      this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
    } else if (type === 'graphicsInstructions') {
      this.orderDetailsFormatService.getOrderStore().setGraphicsInstructionsMetadata(this.order);
      this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
    } else {
      const correspondingLineItems = this.orderDetailsFormatService.getOrderStore().getCorrespondingLineItemsFromClipIdentifier(lineItem, this.order);
      this.syncPublishingInstructions(lineItemActivity.instructions, correspondingLineItems);
    }
  }

  resetVideoInstructionsForm(value: string, lineItem: LineItem) {
    const videoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    videoActivity.instructions = this.orderDetailsFormatService.setDefaultActivityInstructions('videoInstructions', value);
    videoActivity.description = '';
    const qaActivity = this.utilityService.getLineItemActivity(16, lineItem);
    if (lineItem.customConfig.endpoint === 'Viacom Sites & Apps' && value === 'Video with captioning') {
      if (!qaActivity) {
        const newQaActivity = this.orderDetailsFormatService.newActivity(16, this.utilityService.activityTypes.QA_VIDEO.description);
        lineItem.activities.push(newQaActivity);
      }
    } else {
      if (qaActivity) {
        _.remove(lineItem.activities, activity => Number(activity.typeId) === 16);
      }
    }
    this.orderDetailsFormatService.getOrderStore().setVideoInstructionsMetadata(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
  }

  togglePublishingInstructionsForm(event, lineItem: LineItem, elementId: string) {
    const correspondingLineItems = this.orderDetailsFormatService.getOrderStore().getCorrespondingLineItemsFromClipIdentifier(lineItem, this.order);
    this.publishingFormToggle[elementId] = event.target.checked;
    _.forEach(correspondingLineItems, (item: LineItem) => {
      const publishActivity = this.utilityService.getLineItemActivity(13, item);
      if (typeof publishActivity === 'undefined' && event.target.checked) {
        if (event.srcElement.name === 'publishing-instructions') {
          this.createPublishActivity(item, 'CMSdefault');
        } else {
          this.createPublishActivity(item, 'videoCopyDefault');
        }
      } else if (typeof publishActivity !== 'undefined' && event.target.checked) {
        if (event.srcElement.name === 'publishing-instructions') {
          publishActivity.instructions = publishActivity.instructions.concat(this.orderDetailsFormatService.setDefaultActivityInstructions('publishInstructions'));
        } else if (event.srcElement.name === 'video-copy-instructions') {
          publishActivity.instructions = publishActivity.instructions.concat(this.orderDetailsFormatService.setDefaultActivityInstructions('videoCopyInstructions'));
        }
      } else if (typeof publishActivity !== 'undefined' && !event.target.checked) {
        if (event.srcElement.name === 'publishing-instructions') {
          publishActivity.instructions = this.deleteFormFieldInstructions(publishActivity.instructions, this.publishingFormFields);
        } else if (event.srcElement.name === 'video-copy-instructions') {
          publishActivity.instructions = this.deleteFormFieldInstructions(publishActivity.instructions, this.videoCopyFormFields);
        }
      }
    });
    this.orderDetailsFormatService.getOrderStore().setPublishInstructionsMetadata(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
  }

  deleteFormFieldInstructions(instructions, formField) {
    if (!instructions || instructions.length <= 0) {
      return [];
    }
    _.forEach(_.keys(formField), key => {
      _.remove(instructions, metadata => metadata['label'] === key);
    });
    return instructions;
  }

  syncPublishingInstructions(instructions: Array<Instructions>, lineItems) {
    const rawInstructions = _.map(instructions, (instruction) => {
      return {
        label: instruction.label,
        values: instruction.values
      };
    });
    _.forEach(lineItems, (item: LineItem) => {
      const publishActivity = this.utilityService.getLineItemActivity(13, item);
      if (typeof publishActivity === 'undefined') {
        this.createPublishActivity(item, rawInstructions);
      } else if (typeof publishActivity !== 'undefined') {

        publishActivity.instructions = rawInstructions;
      }
    });
    this.orderDetailsFormatService.getOrderStore().setPublishInstructionsMetadata(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
  }

  createPublishActivity(item, instructions?) {
    // 1. create if publish content activity does not exist
    const publishActivityObj = _.find(item.activities, (activity) => {
      return activity['typeId'] === this.utilityService.activityTypes.PUBLISH_VIDEO.type;
    });
    if (publishActivityObj === undefined) {
      const activityObj = new Activity();
      activityObj.quantity = 1;
      activityObj.typeId = this.utilityService.activityTypes.PUBLISH_VIDEO.type;
      activityObj.description = this.utilityService.activityTypes.PUBLISH_VIDEO.description;
      activityObj.generationMode = this.utilityService.activityGenerationMode.Automatic;
      if (instructions === 'CMSdefault') {
        activityObj.instructions = this.orderDetailsFormatService.setDefaultActivityInstructions('publishInstructions');
      } else if (instructions === 'videoCopyDefault') {
        activityObj.instructions = this.orderDetailsFormatService.setDefaultActivityInstructions('videoCopyInstructions');
      } else {
        activityObj.instructions = instructions || [];
      }

      this.orderDetailsPackageService.createActivityObj(activityObj, item);
    }
  }

  increaseStillFrames(lineItem: LineItem) {
    const videoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    const stillFramesMetadataIndex = this.getArrayItemIndex(videoActivity.instructions, 'stillFrames');
    if (stillFramesMetadataIndex > -1) {
      videoActivity.instructions[stillFramesMetadataIndex].values[0]++;
      this.orderDetailsFormatService.getOrderStore().setInstructionsMetadata(this.order);
    }
  }

  decreaseStillFrames(lineItem: LineItem) {
    const videoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    const stillFramesMetadataIndex = this.getArrayItemIndex(videoActivity.instructions, 'stillFrames');
    if (stillFramesMetadataIndex > -1) {
      const stillFramesQuantity = videoActivity.instructions[stillFramesMetadataIndex].values[0];
      if (stillFramesQuantity > 1) {
        videoActivity.instructions[stillFramesMetadataIndex].values[0]--;
      }
      this.orderDetailsFormatService.getOrderStore().setInstructionsMetadata(this.order);
    }
  }

  getTotalStills(lineItem: LineItem): number {
    const videoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    const stillFramesMetadataIndex = this.getArrayItemIndex(videoActivity.instructions, 'stillFrames');
    if (stillFramesMetadataIndex > -1) {
      return videoActivity.instructions[stillFramesMetadataIndex].values[0];
    } else {
      return 0;
    }
  }

  checkboxHandler(event, metadataType, lineItem: LineItem, value?) {
    const videoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    const metadataIndex = this.getArrayItemIndex(videoActivity.instructions, metadataType);
    let valueIndex;
    if (metadataIndex && videoActivity.instructions[metadataIndex]) {
      valueIndex = _.indexOf(videoActivity.instructions[metadataIndex].values, value);
    }
    switch (metadataType) {
      case 'stillFrames':
        if (event.target.checked) {
          const stillFramesMetadata = {
            label: metadataType,
            values: [1]
          };
          videoActivity.instructions.push(stillFramesMetadata);
        } else {
          const stillFramesMetadataIndex = this.getArrayItemIndex(videoActivity.instructions, metadataType);
          videoActivity.instructions.splice(stillFramesMetadataIndex, 1);
        }
        break;
      default:
        if (event.target.checked) {
          if (metadataIndex > -1) {
            videoActivity.instructions[metadataIndex].values.push(value);
          } else {
            const metadataPayload = {
              'label': metadataType,
              'values': [value]
            };
            videoActivity.instructions.push(metadataPayload);
          }
        } else {
          videoActivity.instructions[metadataIndex].values.splice(valueIndex, 1);
          if (videoActivity.instructions[metadataIndex].values.length === 0) {
            videoActivity.instructions.splice(metadataIndex, 1);
          }
        }
        break;
    }
    if (value === 'Deliver/include transcript file') {
      this.updateInstructionsForm('', 'budgetCode', lineItem, 'videoInstructions', true);
    }
    // if slate and graphics becomes none, clear slatesAndGraphicsSourceInfo form field
    if (metadataType === 'slatesAndGraphics' && metadataIndex === -1) {
      this.updateInstructionsForm('', 'slatesAndGraphicsSourceInfo', lineItem, 'videoInstructions', true);
    }
    this.orderDetailsFormatService.getOrderStore().setInstructionsMetadata(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
  }

  publishingInstructionsCheckboxHandler(event, metadataType: string, lineItem: LineItem, value?: string) {
    const publishActivity = this.utilityService.getLineItemActivity(13, lineItem);
    switch (metadataType) {
      case 'hideVideoPageToggle':
      case 'includeBetNowApp':
        if (event.target.checked) {
          const metadata = {
            label: metadataType,
            values: [true]
          };
          publishActivity.instructions.push(metadata);
        } else {
          const metadataIndex = this.getArrayItemIndex(publishActivity.instructions, metadataType);
          publishActivity.instructions.splice(metadataIndex, 1);
        }
        break;

      case 'adTargeting':
        if (event.target.checked) {
          if (typeof value === 'undefined') {
            value = '';
          }
          const adTargetingMetadata = {
            label: metadataType,
            values: [value]
          };
          publishActivity.instructions.push(adTargetingMetadata);
        } else {
          const adTargetingMetadataIndex = this.getArrayItemIndex(publishActivity.instructions, metadataType);
          publishActivity.instructions.splice(adTargetingMetadataIndex, 1);
        }
        break;

      case 'secondarySiteCategory':
        if (event.target.checked) {
          const secondarySiteCategoryMetadataIndex = this.getArrayItemIndex(publishActivity.instructions, metadataType);
          if (secondarySiteCategoryMetadataIndex > -1) {
            publishActivity.instructions[secondarySiteCategoryMetadataIndex].values.push(value);
          } else {
            const slatesAndGraphicsMetadata = {
              'label': metadataType,
              'values': [value]
            };
            publishActivity.instructions.push(slatesAndGraphicsMetadata);
          }
        } else {
          const slatesAndGraphicsMetadataIndex = this.getArrayItemIndex(publishActivity.instructions, metadataType);
          const valueIndex = _.indexOf(publishActivity.instructions[slatesAndGraphicsMetadataIndex].values, value);
          publishActivity.instructions[slatesAndGraphicsMetadataIndex].values.splice(valueIndex, 1);
          if (publishActivity.instructions[slatesAndGraphicsMetadataIndex].values.length === 0) {
            publishActivity.instructions.splice(slatesAndGraphicsMetadataIndex, 1);
          }
        }
        break;
    }
    const viacomSiteAndAppLineItems = this.orderDetailsFormatService.getOrderStore().getCorrespondingLineItemsFromClipIdentifier(lineItem, this.order);
    this.syncPublishingInstructions(publishActivity.instructions, viacomSiteAndAppLineItems);
    this.orderDetailsFormatService.getOrderStore().setInstructionsMetadata(this.order);
  }

  getArrayItemIndex(array: Array<any>, itemKey: string): number {
    let itemIndex = -1;
    _.forEach(array, (value, index) => {
      if (value.label === itemKey) {
        itemIndex = index;
        return;
      }
    });
    return itemIndex;
  }

  initOrderActivities() {
    // init activities on page loads and on adding versions, to obtain activity id for uploading attachment metadata
    // only called by video publishing orders
    let modified = false;
    const composeActivity = this.orderDetailsFormatService.newActivity(1, '');
    const publishActivity = this.orderDetailsFormatService.newActivity(13);
    const qaActivity = this.orderDetailsFormatService.newActivity(16, this.utilityService.activityTypes.QA_VIDEO.description);
    _.forEach(this.order.lineItems, (item) => {
      if (item['activities'] === undefined || !item['activities'].length) {
        item['activities'] = [];
        item['activities'].push(composeActivity);
        item['activities'].push(publishActivity);
        if (item.customConfig && item.customConfig.endpoint === 'Viacom Sites & Apps' && this.isVideoWithCaptioning(item)) {
          item.activities.push(qaActivity);
        }
        modified = true;
      }
    });
    if (modified) {
      this.orderProgressTrackerService.saveOrder(this.order, '', () => { this.isUpdatingOrder = false; });
    }
  }

  isVideoWithCaptioning(lineItem: LineItem) {
    const composeActivity = this.utilityService.getLineItemActivity(1, lineItem);
    if (composeActivity && composeActivity.instructions) {
      const versionType = _.find(composeActivity.instructions, instruction => instruction['label'] === 'versionType');
      if (versionType && versionType['values'][0] === 'Video with captioning') {
        return true;
      }
    }
    return false;
  }

  getCorrespondingVersions(lineItem: LineItem): Array<any> {
    const lineItemVersions = this.orderDetailsFormatService.getOrderStore().getCorrespondingLineItemsFromClipIdentifier(lineItem, this.order);
    return lineItemVersions;
  }

  addItem(lineItem: LineItem, platform) {
    this.isUpdatingOrder = true;
    this.orderDetailsPlatformService.increasePlatforms(this.order, lineItem, platform);
    this.isNewLineitemAdded = true;
    this.initOrderActivities();
  }

  saveToModel(item: LineItem, version, event) {
    const formatActivity = this.getFormatActivity(item);
    _.set(item, 'customConfig.version', version);
    if (formatActivity === undefined) {
      this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
    } else {
      if (event.content === undefined || event.content.toString().replace(/&nbsp;|\s/g, '') === '') {
        formatActivity.description = '';
      } else {
        formatActivity.description = event.content;
      }
    }
    this.orderDetailsFormatService.getOrderStore().notify();
  };

  saveNonVideoContentToModel(event) {
    if (event.content !== undefined) {
      const content = event.content.toString().replace(/&nbsp;|\s/g, '');
      if ((content !== '') || (content === '' && (this.order.lineItems[0].activities[0].description !== '' &&
        this.order.lineItems[0].activities[0].description !== undefined))) {
        this.order.lineItems[0].activities[0].description = event.content;
        this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
      }
    }
  }

  saveNonVideoContentToModelBrand(event) {
    if (typeof event === 'string') {
      let brandName = event.trim() !== '' ? event : '';
      if (brandName !== undefined) {
        let metadataObj;
        if(this.order.lineItems[0].activities[0].instructions && this.order.lineItems[0].activities[0].instructions.length > 0) {
          this.order.lineItems[0].activities[0].instructions[0].values = [brandName];
        } else {
          metadataObj = [{
            'label': 'brandName',
            'values': [brandName]
          }];
          this.order.lineItems[0].activities[0].instructions = metadataObj;
        }
        this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
      }
    }
  }

  applyInstructionsToAllVersions(lineItem: LineItem) {
    const correspondingVersions = this.getCorrespondingVersions(lineItem);
    const parentVideoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    _.forEach(correspondingVersions, (version) => {
      console.log('version id and line item:', version, lineItem);
      if (version.id !== lineItem.id) { // different lineItem
        const videoActivity = this.utilityService.getLineItemActivity(1, version);
        let rawParentInstructionMetadata = [];
        _.forEach(parentVideoActivity.instructions, (instruction) => {
          // deal with invalid aspect ratio fore viacom site & app
          if (version.customConfig.endpoint && version.customConfig.endpoint === 'Viacom Sites & Apps'
          && instruction.label === 'aspectRatio' && (instruction.values[0] === '1 : 1' || instruction.values[0] === '9 : 16')) {
            if (version.videoInstructionsMetadata['aspectRatio']) {
              rawParentInstructionMetadata.push({
                label: instruction.label,
                values: version.videoInstructionsMetadata['aspectRatio']
              });
            } else {
              rawParentInstructionMetadata.push({label: instruction.label, values: ['16 : 9']}); // default aspect ratio
            }
          } else {
            rawParentInstructionMetadata.push({label: instruction.label, values: instruction.values});
          }
        });
        videoActivity.instructions = rawParentInstructionMetadata;
        videoActivity.description = parentVideoActivity.description;
      }
    });
    this.orderDetailsFormatService.getOrderStore().setVideoInstructionsMetadata(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
    this.updateCustomEditor.next(
      {
        description: parentVideoActivity.description,
        parentIdentifier: this.getLineItemClipIdentifier(lineItem)
      });
  }


  updateAttachmentsMetadata(activity, event) {
    event.activityId = activity.id;
    event.source = 'S3';
    this.subscriptions.add(this.orderDetailsFormatService.updateAttachmentsMetadata([event]).subscribe(
      data => {
        _.find(activity.input.attachments, { 'name': data[0].name })['id'] = data[0].id;
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      }
    ));
  }

  updateTrackerStatus(activity, event) {
    const isUploading = event.uploadingInProgressQueue.length > 0;
    activity.input.isUploading = isUploading;
    if (typeof activity.input.isUploading !== 'undefined' && !isUploading) {
      delete activity.input.isUploading;
    }
    this.orderDetailsFormatService.getOrderStore().notify();
  }

  isAttachmentsUploading() {
    for (let i = 0; i < this.order.lineItems.length; i++) {
      const lineItemAttachments = this.getFormatActivity(this.order.lineItems[i]).input;
      if (lineItemAttachments && lineItemAttachments.isUploading) {
        return true;
      }
    }
    return false;
  }

  saveVersionToModel(item: LineItem, version: string) {
    _.set(item, 'customConfig.version', version);
    this.orderDetailsFormatService.getOrderStore().notify();
  }

  getFormatActivity(item: LineItem) {
    return _.find(item.activities, { 'typeId': 1 });
  }

  deleteVersion(lineItem) {
    this.deleteModalOptions.version =
      _.get(lineItem, 'customConfig.version') === undefined ? '' : _.get(lineItem, 'customConfig.version').toString();
    this.deleteModalOptions.msg = `This clip version will be removed from the order and can’t be undone.`;
    this.deleteModalOptions.btnMsg = 'YES, DELETE VERSION';
    this.deleteModalOptions.action = () => {
      const orderStore = this.orderDetailsFormatService.getOrderStore();
      orderStore.removeLineItem(lineItem);
      this.orderProgressTrackerService.saveOrder(this.order, _.get(lineItem, 'customConfig.version') + ' has been removed from the order.');
    };
  }

  getTotalsForActivity(lineItem, endpoint, typeId, i) {
    const arr = [];
    _.forEach(lineItem['activities'], (item, li) => {
      if (item['typeId'] === typeId) {
        arr.push(item);
      }
    });
    return arr.length;
  }

  changeCounter(direction, i, lineItem: LineItem, typeId, endpoint: string) {
    this.selectedVersionIndex = i;
    if (i === this.selectedVersionIndex) {
      if (this.counter === 1 && direction === 'minus') {
        return false;
      }
      if (direction === 'plus') {
        this.counter = (this.getTotalStills(lineItem) + 1);
      } else {
        this.counter = (this.getTotalStills(lineItem) - 1);
      }
      const lineItemIndex = _.indexOf(lineItem.activities, _.find(lineItem.activities, { typeId: typeId }));
      lineItem.activities[lineItemIndex].quantity = this.counter;
    }
  }

  getLineItemClipIdentifier(lineItem: LineItem) {
      if (typeof lineItem.metadata[0]['clipId'] !== 'undefined' && lineItem.metadata[0]['clipId'] !== null) {
        return lineItem.metadata[0]['clipId'];
      } else {
        return lineItem.metadata[0]['clipTitle'];
      }
  }

  onKeypress(event) {
    if (event.code === 'Enter') {
      return false;
    }
  }

  getAspectRatioIcon(label: string) {
    return 'ratio-' + label.replace(':', '-').replace(/[^0-9-]/g, '');
  }

  setGraphicsDropDown() {
    let graphicFormFields = this.graphicsInstrFormFields;
    
    const brandNameList = graphicFormFields.BrandDropDown.map(x => x);

    let vmid = _.get(this.order, 'metadata.vmId') === undefined ? '' : _.get(this.order, 'metadata.vmId').toString();
    const contentType = this.order.metadata['contentType'];
      if ( vmid !== '' ) {
        let catalogPromise = this.catalogService.getItemDetails(vmid, contentType).toPromise();
        catalogPromise.then(
          data => {
            try {
              if (contentType === 'BRAND' && data.minimumBrands.length > 0) {
                this.contenBrandName = data.minimumBrands[0].name;
              } else if ((contentType === 'SERIES' || contentType === 'SPECIAL' || contentType === 'EPISODE') && data.contentDetails) {
                this.contenBrandName = data.contentDetails.originBrandName ? data.contentDetails.originBrandName : '';
              }

              if(!this.contenBrandName) {
                this.contenBrandName = brandNameList[0].value;
              }
              this.setDropDownValues(graphicFormFields, brandNameList);
              
            } catch(e) {
              this.graphicsBrandName = brandNameList[0];
              this.setDropDownValues(graphicFormFields, brandNameList);
            }
            this.setGraphicsOrderInstructions();
          },
          error => {
            this.graphicsBrandName = brandNameList[0];
            this.setGraphicsOrderInstructions();
          });
        }    
  }

  setDropDownValues(graphicFormFields, brandNameList) {
    if(this.order.lineItems[0].activities[0].instructions && this.order.lineItems[0].activities[0].instructions.length > 0) {
        
      let requestIndex = this.order.lineItems[0].activities[0].instructions.findIndex(inst => inst.label === 'requestType');
      let index = this.order.lineItems[0].activities[0].instructions.findIndex(inst => inst.label === 'brand');
      
      if(requestIndex >= 0) {
        let reqTypeValue = this.order.lineItems[0].activities[0].instructions[requestIndex].values[0];
        let reqDropdownIndex = graphicFormFields.RequestTypeDropDown.findIndex(req => req.id === reqTypeValue);
        if(reqDropdownIndex >= 0) {
          this.graphicsRequestType = graphicFormFields.RequestTypeDropDown[reqDropdownIndex];
        } else {
          this.graphicsRequestType = graphicFormFields.RequestTypeDropDown[1];
        }
      } else {
        this.graphicsRequestType = graphicFormFields.RequestTypeDropDown[1];
        this.order.lineItems[0].activities[0].instructions.push({
          label: 'requestType',
          values: [this.graphicsRequestType.id],
          type: ''
        });
      }
      
      if(index >= 0) {
        let brandIndex = brandNameList.findIndex(b => b.id === this.order.lineItems[0].activities[0].instructions[index].values[0]);
        if(brandIndex >= 0) {
          this.graphicsBrandName = Object.assign({}, brandNameList[brandIndex]);
        } else {
          this.graphicsBrandName = Object.assign({}, brandNameList[0]);
        }
      } else {
        this.graphicsBrandName = Object.assign({}, brandNameList[0]);
        this.order.lineItems[0].activities[0].instructions.push({
          label: 'brand',
          values: [this.graphicsBrandName.id],
          type: ''
        });
      }
    } else {
      this.graphicsRequestType = graphicFormFields.RequestTypeDropDown[1];
      this.order.lineItems[0].activities[0].instructions.push({
        label: 'requestType',
        values: [this.graphicsRequestType.id],
        type: ''
      });
      
      if(this.contenBrandName && this.contenBrandName !== 'n/a') {
        this.graphicsBrandName = brandNameList.filter(brand => brand.value === this.contenBrandName)[0];
        if(!this.graphicsBrandName) {
          this.graphicsBrandName = brandNameList[0];
        }
      } else {
        this.graphicsBrandName = brandNameList[0];
      }
      this.order.lineItems[0].activities[0].instructions.push({
        label: 'brand',
        values: [this.graphicsBrandName.id],
        type: ''
      });
    }
  }

  setGraphicsOrderInstructions() {
    let result;
    //const listBrandOptions = this.graphicsBranedName.options.map(x => x);
    this.platformTypeList = this.graphicsBrandName.options.map(x => x);
    this.platformTypeList.forEach(p => p.display = true);
    this.hideAddPlatform = true;
    
    this.graphicsRequestForm = undefined;
    this.formControls = [];
    this.graphicsSelectedRequest = [];
    
    let platformIndx = this.order.lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'platformList');
    if(platformIndx >= 0) {
      result = this.order.lineItems[0].activities[0].instructions[platformIndx].values;
    } else {
      result = _.uniqBy(this.order.lineItems[0].activities[0].instructions, (inst)=> {
        return inst['type'];
      });
      
      result = result.filter(res => res['type'].length > 0);
      let platformList = result.map(res => res.type);
      result = platformList;
      if(platformList.length > 0) {
        this.order.lineItems[0].activities[0].instructions.push({
          label: 'platformList',
          values: platformList,
          type: ''
        })
      }
    }

    let platformLstBkp = result;
    result = [];
    this.platformTypeList.forEach(pltName => {
      if(platformLstBkp.findIndex(plt => plt === pltName.id) >= 0) {
        result.push(pltName.id);
      }
    });
  
    if(result && result.length > 0) {
      this.addNewPlatform = false;
      result.forEach(res => {
        let index = this.platformTypeList.findIndex(list => list.id === res);
        if(index >= 0) {
          this.platformTypeList[index].display = false;
        }
        
        if(!this.graphicsRequestForm) {
          this.intializeRequestType(this.platformTypeList[index]);
        } else {
          this.addRequestDynamicForm(this.platformTypeList[index]);
        }
        this.hideAddPlatform = this.platformTypeList.filter(p => p.display === false).length <= 0 ? false : true;
      });
      
    } else {
      this.addNewPlatform = true;
    }
    
    this.loadingMaskService.disableLoadingMask();
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
  }

  intializeRequestType(platformType) {
    this.graphicsRequestForm = undefined;
    this.formControls = [];
    this.graphicsSelectedRequest = [];
    this.addNewPlatform = false;
    let graphicsInstrFormData = Object.assign({}, this.graphicsInstrFormFields);
    
    const formField = Object.assign({}, graphicsInstrFormData.RequestType);
    this.graphicsSelectedRequest.push(platformType.id);
    let instructionsFormFields = this.order.lineItems[0].activities[0].instructions.filter(ins => ins.type === platformType.id);
    
    this.clearFormFields(formField, platformType);
    
    this.formControls[0] = this.requestformService.getForm(formField, platformType, instructionsFormFields);
    this.formControls[0].requestType = platformType;
    
    this.graphicsRequestForm = this.fb.group({
      'Request': this.fb.array([
        this.dynamicFormBaseService.toFormGroup(this.formControls[0])
      ])
    });
    
    let instructions = [];
    
    this.graphicsRequestForm.valueChanges.subscribe((formValues) => {
      if(this.order && this.order.lineItems[0].activities[0].instructions) {
        instructions = this.order.lineItems[0].activities[0].instructions;
      }
      //instructions = [];
      this.graphicsSelectedRequest.forEach((req, graphicindex) => {
        let formObj = formValues.Request[graphicindex];
        if(formObj) {
          Object.keys(formObj).forEach(function(key,index) {
            let indexInst = instructions.findIndex(j => j.label === key && j.type === req);

            if(formObj[key] && ((typeof formObj[key] === 'string' &&  formObj[key].length > 0 ) || (typeof formObj[key] === 'boolean'))) {

              if(indexInst >= 0) {
                instructions[indexInst].values = [formObj[key]];
              } else {
                instructions.push({
                  label: key,
                  values: [formObj[key]],
                  type: req
                });
              }
            } else if(indexInst >= 0) {
              instructions.splice(indexInst, 1);
              if(key === 'Custom') {
                formObj['dimensions'] = '';
                let indexdelete = instructions.findIndex(j => j.label === 'dimensions' && j.type === req);
                instructions.splice(indexdelete, 1);
              }
            }
          });
        }
        this.order.lineItems[0].activities[0].instructions = instructions;
        //console.log(this.order.lineItems[0].activities[0].instructions);
        this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
      })

    });
  }

  addRequestDynamicForm(platformType) {
    this.addNewPlatform = false;
    const formField = Object.assign({}, this.graphicsInstrFormFields.RequestType);
    this.graphicsSelectedRequest.push(platformType.id);
    this.clearFormFields(formField, platformType);
    this.formControls.push(this.requestformService.getForm(formField, platformType, this.order.lineItems[0].activities[0].instructions));
    this.formControls[this.formControls.length -1].requestType = platformType;
    const control = <FormArray>this.graphicsRequestForm.controls['Request'];
    control.push( this.dynamicFormBaseService.toFormGroup(this.formControls[this.formControls.length -1]));
  }

  getSelectedBrandName() {
    return this.graphicsBrandName;
  }

  getSelectedRequestType() {
    return this.graphicsRequestType;
  }

  loadBrandPlatform(brandName) {
    //this.graphicsInstrFormFields = Object.assign({}, graphicsInstrFormFields);
    this.graphicsBrandName = brandName;
    this.platformTypeList = brandName.options;
    this.platformTypeList.forEach(p => p.display = true);
    this.hideAddPlatform = true;
    this.graphicsSelectedRequest = [];
    this.graphicsRequestForm = undefined;
    this.formControls = [];
    this.addNewPlatform = true;
    this.order.lineItems[0].activities[0].description = '';
    let instructionDetails = ['noOfDelivarables', 'assetLocation', 'fileDropOffLocation', 'dueDateReason'];

    if(this.order.lineItems[0]) {
      this.order.lineItems[0].dueDateTime = undefined;
      this.order.lineItems[0].launchDateTime = undefined;
    }
    
    if(this.order.lineItems[0].activities[0].instructions && this.order.lineItems[0].activities[0].instructions.length > 0) {
      
      instructionDetails.forEach(ins => {
        let inx = this.order.lineItems[0].activities[0].instructions.findIndex(list => list.label === ins);
        if(inx > 0) {
          this.order.lineItems[0].activities[0].instructions.splice(inx, 1);
        }
      });

      let instructions = this.order.lineItems[0].activities[0].instructions;
      let count = this.order.lineItems[0].activities[0].instructions.length;

      while(count > 0) {
        instructions.forEach((ins, index) => {
          if(ins.type !== '') {
            this.order.lineItems[0].activities[0].instructions.splice(index, 1);
          }
        });
        count = this.order.lineItems[0].activities[0].instructions.filter(f => f.type !== '').length;
      }

      delete this.order.lineItems[0].activities[0].instructions;
      this.order.lineItems[0].activities[0]['instructions'] = instructions;

      let brandIndex = this.order.lineItems[0].activities[0].instructions.findIndex(list => list.label === 'brand');
      if(brandIndex >= 0) {
        this.order.lineItems[0].activities[0].instructions[brandIndex].values = [brandName.id];
      }
      let index = this.order.lineItems[0].activities[0].instructions.findIndex(list => list.label === 'platformList');
      if(index >= 0) {
        this.order.lineItems[0].activities[0].instructions[index].values = [];
      }
    }
    //console.log(this.order.lineItems[0].activities[0].instructions);
      this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
      this.orderDetailsFormatService.getOrderStore().setGraphicsInstructionsMetadata(this.order);
  }

  loadRequestType(requestType) {
    //this.graphicsInstrFormFields = Object.assign({}, graphicsInstrFormFields);
    this.graphicsRequestType = requestType;
    this.graphicsSelectedRequest = [];
    this.graphicsRequestForm = undefined;
    this.formControls = [];
    this.addNewPlatform = true;
    this.order.lineItems[0].activities[0].description = '';
    if(this.order.lineItems[0]) {
      this.order.lineItems[0].dueDateTime = undefined;
      this.order.lineItems[0].launchDateTime = undefined;
    }
      if(this.order && this.order.lineItems[0].activities[0].instructions) {
        let brandIndex = this.order.lineItems[0].activities[0].instructions.findIndex(inst => inst.label === 'brand');
        let reqIndex = this.order.lineItems[0].activities[0].instructions.findIndex(inst => inst.label === 'requestType');
        let dueDateIndx = this.order.lineItems[0].activities[0].instructions.findIndex(inst => inst.label === 'dueDateReason');
        let instructions;
        let requestType;
        let dateResponse;
        
        if(brandIndex >= 0) {
          instructions = this.order.lineItems[0].activities[0].instructions[brandIndex];
        }
        if(reqIndex >= 0) {
          requestType = this.order.lineItems[0].activities[0].instructions[reqIndex];
          requestType.values = [this.graphicsRequestType.id];
        } else {
          requestType = {
            label: 'requestType',
            values: [this.graphicsRequestType.id],
            type: ''
          };
        }
        if(dueDateIndx >= 0) {
          dateResponse = this.order.lineItems[0].activities[0].instructions[dueDateIndx];
        }
        
        let inst = this.order.lineItems[0].activities[0].instructions;
        let count = this.order.lineItems[0].activities[0].instructions.length;
        while(count > 0) {
          inst.forEach((ins, index) => {
            if(ins.type !== '') {
              this.order.lineItems[0].activities[0].instructions.splice(index, 1);
            }
          });
          count = this.order.lineItems[0].activities[0].instructions.filter(f => f.type !== '').length;
        }
        this.order.lineItems[0].activities[0].instructions = [];

        if(this.graphicsRequestType.id === 'VMN') {
          if(brandIndex < 0) {
            this.order.lineItems[0].activities[0].instructions.push({
              label: 'brand',
              values: [this.graphicsBrandName.id],
              type: ''
            })
            this.platformTypeList = this.graphicsBrandName.options;
            this.platformTypeList.forEach(p => p.display = true);
          } else if(instructions) {
            this.order.lineItems[0].activities[0].instructions.push(instructions);
          }
          
        }
        if(dateResponse) {
          this.order.lineItems[0].activities[0].instructions.push(dateResponse);
        }
        if(requestType) {
          this.order.lineItems[0].activities[0].instructions.push(requestType);
        }
      }

      this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
      this.orderDetailsFormatService.getOrderStore().setGraphicsInstructionsMetadata(this.order);
  }

  onDeleteFormGroupReset(event) {
    if(this.order && this.order.lineItems[0].activities[0].instructions) {
    
      let instructions = this.order.lineItems[0].activities[0].instructions;
      let count = this.order.lineItems[0].activities[0].instructions.length;
      while(count > 0) {
        instructions.forEach((ins, index) => {
          if(ins.type === event) {
            this.order.lineItems[0].activities[0].instructions.splice(index, 1);
          }
        });
        count = this.order.lineItems[0].activities[0].instructions.filter(f => f.type === event).length;
      }
      
      let index = this.order.lineItems[0].activities[0].instructions.findIndex(list => list.label === 'platformList');
      if(index >= 0) {
        let values = this.order.lineItems[0].activities[0].instructions[index].values;
        this.order.lineItems[0].activities[0].instructions[index].values.splice([values.findIndex(val => val === event)], 1);
      }
      this.setGraphicsOrderInstructions();
    }
  }

  setNewPlatformTemplate() {
    this.addNewPlatform = !this.addNewPlatform;
  }

  getNewPlatformTemplate() {
    return this.addNewPlatform;
  }

  getSelectedPlatform() {
    return this.graphicsPLatformType;
  }

  loadDynamicForm(platformType) {
    let index = this.platformTypeList.findIndex(list => list.id === platformType.id);
    if(index >= 0) {
      this.platformTypeList[index].display = false;
    }
    this.hideAddPlatform = this.platformTypeList.filter(p => p.display === true).length <= 0 ? false : true;
    let result;
    let platformIndx = this.order.lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'platformList');
    if(platformIndx >= 0) {
      this.order.lineItems[0].activities[0].instructions[platformIndx].values.push(platformType.id);
    } else {
      this.order.lineItems[0].activities[0].instructions.push({
        label: 'platformList',
        values: [platformType.id],
        type: ''
      })
    }
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
    if(!this.graphicsRequestForm) {
      this.intializeRequestType(platformType);
    } else {
      this.addRequestDynamicForm(platformType);
    }
    //this.setNewPlatformTemplate();
  }

  changeRequest(type, typeObj) {
    if(type === 'requestType') {
      this.confirmModalOptions.heading = `Are You Sure You Want To Change the Request Type?`
      this.confirmModalOptions.msg = `Changing the Request Type will clear the form.`;
      this.confirmModalOptions.btnMsg = 'CHANGE REQUEST TYPE';
      this.confirmModalOptions.action = () => {
        this.loadRequestType(typeObj);
      };
    } else {
      this.confirmModalOptions.heading = `Are You Sure You Want To Change the Brand?`
      this.confirmModalOptions.msg = `Changing the Brand will reset the platform fields.`;
      this.confirmModalOptions.btnMsg = 'CHANGE BRAND';
      this.confirmModalOptions.action = () => {
        this.loadBrandPlatform(typeObj);
      };
    }
  }

  openModal(type, typeObj) {
    if(type === 'requestType') {
      this.confirmModalOptions.heading = `Are You Sure You Want To Change the Request Type?`
      this.confirmModalOptions.msg = `Changing the Request Type will clear the form.`;
      this.confirmModalOptions.btnMsg = 'CHANGE REQUEST TYPE';
      this.confirmModalOptions.action = () => {
        this.loadRequestType(typeObj);
      };
    } else {
      this.confirmModalOptions.heading = `Are You Sure You Want To Change the Brand?`
      this.confirmModalOptions.msg = `Changing the Brand will reset the platform fields.`;
      this.confirmModalOptions.btnMsg = 'CHANGE BRAND';
      this.confirmModalOptions.action = () => {
        this.loadBrandPlatform(typeObj);
      };
    }
    //this.confirmModal.show();
  }

  clearFormFields(formField, platformType) {
    if(formField[platformType.id] && formField[platformType.id][0]) {
      let formFields = formField[platformType.id][0].options;
      if(formFields) {
        formFields.forEach(f => {
          f.value = '';
        });
      }
      let formFieldsDesc = formField[platformType.id][0];
      if(formFieldsDesc) {
        formFieldsDesc.value = '';
      }
    }
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
    // this.loadingMask.disableLoadingMask();
  }

  ngOnChanges() {
    this.orderDetailsFormatService.getOrderStore().notify();
  }
}
