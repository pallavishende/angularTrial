import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderInstructionsFormComponent } from './order-instructions-form.component';

xdescribe('OrderInstructionsFormComponent', () => {
  let component: OrderInstructionsFormComponent;
  let fixture: ComponentFixture<OrderInstructionsFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderInstructionsFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderInstructionsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
