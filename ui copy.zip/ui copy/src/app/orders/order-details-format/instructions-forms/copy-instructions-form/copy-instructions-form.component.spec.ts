import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CopyInstructionsFormComponent } from './copy-instructions-form.component';

describe('CopyInstructionsFormComponent', () => {
  let component: CopyInstructionsFormComponent;
  let fixture: ComponentFixture<CopyInstructionsFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CopyInstructionsFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CopyInstructionsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
