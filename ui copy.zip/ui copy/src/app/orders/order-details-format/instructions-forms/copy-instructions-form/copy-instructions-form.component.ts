import { Component, OnInit, OnChanges, SimpleChanges, Input, Output, EventEmitter } from '@angular/core';
import { cloneDeep, forEach, has } from 'lodash';
import { LineItem } from '../../../../models/line-item';

@Component({
  selector: 'app-copy-instructions-form',
  templateUrl: './copy-instructions-form.component.html',
  styleUrls: ['./../instructions-forms.scss']
})
export class CopyInstructionsFormComponent implements OnInit, OnChanges {

  @Input() selectedLineItem;
  @Output() updatedCopyInstructions = new EventEmitter<any>();
  @Output() isValid = new EventEmitter<any>();

  instructionsFormObj;
  selectedLineItemRef: LineItem;
  instructionsRef;
  initializeEditor: boolean;

  constructor() { }

  ngOnInit() {
    this.setInstructionsFormObj();
    this.updatedCopyInstructions.emit(this.instructionsFormObj);
  }

  setInstructionsFormObj() {
    this.instructionsFormObj = {
      videoTitle: [''],
      videoDescription: [''],
      shortTitle: [''],
      shortDescription: [''],
      browserTitle: []
    };
    if (this.instructionsRef) {
      forEach(this.instructionsRef, (value, key) => {
        if (has(this.instructionsFormObj, key)) {
          this.instructionsFormObj[key] = value;
        }
      });
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (typeof changes['selectedLineItem'] !== 'undefined' &&
      typeof changes['selectedLineItem'].currentValue !== 'undefined') {
      this.selectedLineItemRef = cloneDeep(this.selectedLineItem.endpoint_info['Viacom Sites & Apps'][0]);
      if (this.selectedLineItemRef['videoCopyInstructionsMetadata']) {
        this.instructionsRef = this.selectedLineItemRef['videoCopyInstructionsMetadata'];
      } else {
        this.instructionsRef = null;
      }
      this.setInstructionsFormObj();
      this.updatedCopyInstructions.emit(this.instructionsFormObj);
      this.isValid.emit(this.validateInstructionsFormObj());
    }
  }

  validateInstructionsFormObj(): boolean {
    if (this.instructionsFormObj.videoTitle[0].trim() && this.instructionsFormObj.videoTitle[0].length <= 140
    && this.instructionsFormObj.videoDescription[0].trim()
    && this.instructionsFormObj.shortTitle[0].trim() && this.instructionsFormObj.shortTitle[0].length <= 60
    && this.instructionsFormObj.shortDescription[0].trim() && this.instructionsFormObj.shortDescription[0].length <= 60) {
      return true;
    } else {
      return false;
    }
  }

  updateInstructionsForm(value: string, valueKey: string) {
    this.instructionsFormObj[valueKey] = [value];
    this.isValid.emit(this.validateInstructionsFormObj());
  }
}
