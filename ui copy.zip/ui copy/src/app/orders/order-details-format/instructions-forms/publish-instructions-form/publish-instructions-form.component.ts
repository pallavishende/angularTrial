import { Component, OnInit, OnChanges, SimpleChanges, Input, Output, EventEmitter } from '@angular/core';
import { cloneDeep, forEach, has, pull, includes } from 'lodash';
import { LineItem } from '../../../../models/line-item';
import { ENTER } from '@angular/cdk/keycodes';


@Component({
  selector: 'app-publish-instructions-form',
  templateUrl: './publish-instructions-form.component.html',
  styleUrls: ['./../instructions-forms.scss']
})
export class PublishInstructionsFormComponent implements OnInit, OnChanges {
  @Input() selectedLineItem;
  @Input() instructionsFormFields;
  @Output() updatedPublishInstructions = new EventEmitter<any>();
  @Output() isValid = new EventEmitter<any>();

  instructionsFormObj;
  selectedLineItemRef: LineItem;
  instructionsRef;
  initializeEditor: boolean;
  separatorKeysCodes: number[] = [ENTER];

  constructor() { }

  ngOnInit() {
    this.setInstructionsFormObj();
    this.initializeCustomEditor();
    this.updatedPublishInstructions.emit(this.instructionsFormObj);
  }

  setInstructionsFormObj() {
    this.instructionsFormObj = {
      subFolder: [''],
      subFranchise: [this.instructionsFormFields['subFranchise'].defaultValue],
      primarySiteCategory: [this.instructionsFormFields['primarySiteCategory'].defaultValue],
      secondarySiteCategory: [],
      tags: [''],
      hideVideoPageToggle: [false],
      includeBetNowApp: [false],
      adTargeting: [false],
      additionalPublishNotes: ['']
    };
    if (this.instructionsRef) {
      forEach(this.instructionsRef, (value, key) => {
        if (has(this.instructionsFormObj, key)) {
          this.instructionsFormObj[key] = value;
        }
      });
    }
  }

  initializeCustomEditor() {
    setTimeout(() => {
      this.initializeEditor = true;
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (typeof changes['selectedLineItem'] !== 'undefined' &&
      typeof changes['selectedLineItem'].currentValue !== 'undefined') {
      this.selectedLineItemRef = cloneDeep(this.selectedLineItem.endpoint_info['Viacom Sites & Apps'][0]);  // lodash clone
      if (this.selectedLineItemRef['publishInstructionsMetadata']) {
        this.instructionsRef = this.selectedLineItemRef['publishInstructionsMetadata'];
      } else {
        this.instructionsRef = null;
      }
      this.setInstructionsFormObj();
      this.updatedPublishInstructions.emit(this.instructionsFormObj);
      this.isValid.emit(this.validateInstructionsFormObj());
    }
  }

  validateInstructionsFormObj(): boolean {
    pull(this.instructionsFormObj.tags, '');
    if (this.instructionsFormObj.subFolder[0].trim()
    && this.instructionsFormObj.tags.length > 0
    && this.instructionsFormObj.adTargeting[0] !== '') {
      return true;
    } else {
      return false;
    }
  }

  handleTags(event, target: Array<string>, remove?: boolean): string {
    if (remove) {
      pull(target, event);
      this.updateInstructionsForm(target, 'tags');
    } else {
      const input = event.input;
      const value = event.value.trim();
      if (value) {
        // clear input field
        if (input) {
          input.value = '';
        }
        if (!target) {
          target = [];
        }
        if (includes(target, value)) {
          return;
        }
        target.push(value);
        this.updateInstructionsForm(target, 'tags');
      }
    }
  }

  updateInstructionsForm(value: any, valueKey: string) {
    if (valueKey === 'tags') {
      this.instructionsFormObj[valueKey] = value;
    } else {
      this.instructionsFormObj[valueKey] = [value];
    }
    this.isValid.emit(this.validateInstructionsFormObj());
  }

  checkboxHandler(event, type, value?) {
    switch (type) {
      case 'secondarySiteCategory':
        if (event.target.checked) {
          this.instructionsFormObj.secondarySiteCategory.push(value);
        } else {
          pull(this.instructionsFormObj.secondarySiteCategory, value); // lodash method
        }
        break;
    }
  }

  contentChanged(event) {
    let eventContent;
    if (typeof event.content === 'undefined' || event.content.toString().replace(/&nbsp;|\s/g, '') === '') {
      eventContent = '';
    } else {
      eventContent = event.content;
    }
    this.instructionsFormObj.additionalPublishNotes[0] = eventContent;
  }
}
