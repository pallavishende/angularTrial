import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { ConfigService } from '../../services/config.service';
import { BehaviorSubject } from 'rxjs';
import 'rxjs/add/operator/map';
import { HttpClient } from '@angular/common/http';

import { OrderStore } from '../../models/order-store';
import { Activity, Instructions } from '../../models/activity';
import { LineItem } from '../../models/line-item';
import { UtilityService } from '../../services/utility.service';

const orderInstructionsFormFields = require('../../models/mock-payloads/order-instructions-form-fields.json');
const orderPublishingFormFields = require('../../models/mock-payloads/order-publishing-form-fields.json');
const orderVideoCopyFormFields = require('../../models/mock-payloads/order-video-copy-form-fields.json');
const orderGraphicsFormFields = require('../../models/mock-payloads/order-graphic-request-instructions.json');

@Injectable()
export class OrderDetailsFormatService {
  order;

  constructor(
    private authHttp: HttpClient,
    private configService: ConfigService,
    private utilityService: UtilityService,
    private orderStore: OrderStore) { }

  get() {
    return this.orderStore.orderStream;
  }

  getOrderStore() {
    return this.orderStore;
  }

  newActivity(type: number, description?: string) {
    const activity = new Activity();
    activity.description = description ? description : '';
    if (type === this.utilityService.activityTypes.CREATE_VIDEO.type) {
      activity.typeId = type;
      activity.input = { attachments: [] };
      activity.instructions = this.setDefaultActivityInstructions('videoInstructions');
      activity.subActivities = [];
    }
    if (type === this.utilityService.activityTypes.PUBLISH_VIDEO.type) {
      activity.typeId = type;
      activity.quantity = 1;
      activity.description = this.utilityService.activityTypes.PUBLISH_VIDEO.description;
      activity.generationMode = this.utilityService.activityGenerationMode.Automatic;
    }
    if (type === this.utilityService.activityTypes.QA_VIDEO.type) {
      activity.typeId = type;
    }
    return activity;
  }

  setDefaultActivityInstructions(formField: string, versionType: string = 'Video with captioning'): Array<Instructions> {
    const defaultMetadata = [];
    if (formField === 'videoInstructions') {
      defaultMetadata.push({
        label: 'versionType',
        values: [versionType]
      },
      {
        label: 'aspectRatio',
        values: ['16 : 9']
      },
      {
        label: 'fileDropOffLocation',
        values: ['']
      });
      switch (versionType) {
        case 'Video with captioning':
        case 'Caption file only':
          defaultMetadata.push({
            label: 'captions',
            values: ['Deliver a closed caption file (SRT, SCC, etc.)']
          });
          break;
        case 'Still frames only':
          defaultMetadata.push({
            label: 'stillFrames',
            values: [1]
          });
          break;
      }
    } else if (formField === 'publishInstructions') {
      defaultMetadata.push(
        {
          label: 'subFranchise',
          values: ['Acceptance Speech']
        },
        {
          label: 'primarySiteCategory',
          values: ['Shows']
        }
      );
    } else if (formField === 'videoCopyInstructions') {
      // as for now, this act like placeholder to keep some property living so videoCopyInstructionsMetadata won't be deleted when update form
      defaultMetadata.push(
        {
          label: 'videoTitle',
          values: ['']
        }
      );
    }
    return defaultMetadata;
  }

  createActivity(lineItem: LineItem, activity: Activity) {
    let orderStore = this.getOrderStore();
    orderStore.addActivity(activity, lineItem);
  }

  deleteItem(lineItem) {
    this.orderStore.removeLineItem(lineItem);
  }

  updateAttachmentsMetadata(payload) {
    const header = new Headers();
    header.append('Content-type', 'application/json');
    const body = payload;
    return this.authHttp.post(this.configService.fileHandlerUrl + '-metadata', body)
      .map((response: any) => response);
  }

  /**
   * return an observable of a mock payload
   * that will be replaced by an http call
   * in the future
   */
  getOrderInstructictionsFormFields() {
    return Observable.of(orderInstructionsFormFields);
  }

  getOrderPublishingFormFields() {
    return Observable.of(orderPublishingFormFields);
  }

  getOrderVideoCopyFormFields() {
    return Observable.of(orderVideoCopyFormFields);
  }

  getOrderGraphicsFormFields() {
    return Observable.of(orderGraphicsFormFields);
  }

}
