/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';

import { OrderStore } from '../../models/order-store';
import { Order } from '../../models/order';
import { OrdersService } from '../orders/orders.service';

import { SystemAlertsService } from '../../services/system-alerts.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { UtilityService } from '../../services/utility.service';
import { OrderDetailsFormatService } from './order-details-format.service';
import { UserService } from '../../services/user.service';
import { AdalService } from "ng2-adal/dist/core";
import { HttpClient } from '@angular/common/http';
import { LoginService } from "../../login/login.service";
import { RouterTestingModule } from '@angular/router/testing';
import { SecretService } from "../../services/secret.service";
import { ConfigurationManagerService} from '../../configuration/configuration-manager.service';
import { EnvironmentService } from '../../services/environment.service';

xdescribe('OrderDetailsFormatService', () => {
  let service, orderStore, mockBackend;
  let users = {
    content: [
      {id: 2351, login: "Meghan.Besse@viacommix.com", firstName: "Meghan", lastName: "Besse", displayName: 'Meghan Besse'},
      {id: 1551, login: "Samir.Patel@viacomcontractor.com", firstName: "Samir", lastName: "Patel", displayName: 'Samir Patel'},
      {id: 1601, login: "Saransh.Ahlawat@viacomcontractor.com", firstName: "Saransh", lastName: "Ahlawat", displayName: 'Saransh Ahlawat'},
      {id: 1552, login: "Luis.Velez@viacommix.com", firstName: "Luis", lastName: "Velez", displayName: 'Luis Velez'}
    ]
  };
  let MockUserService = {
    getUserLoginInfo: function() {
      return users.content[0];
    }
  }
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      providers: [
        OrderDetailsFormatService,
        SystemAlertsService,
        ConfigService,
        EndpointProfileService,
        OrderStore,
        OrdersService,
        UtilityService,
        MockBackend,
        { provide: UserService, useValue: MockUserService },
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: HttpClient,
          useFactory: (http: Http)=>{ return http },
          deps: [Http]
        },
        AdalService,
        LoginService,
        SecretService,
        ConfigurationManagerService,
        EnvironmentService
      ]
    });
  });

  beforeEach(inject([OrderDetailsFormatService, OrderStore, MockBackend], (s, o, m) => {
    service = s;
    mockBackend = m;
    orderStore = o;
  }));

  it('should create an instance of the service', ()=> {
    expect(service).toBeTruthy();
  });

  it('#newActivity should create a new activity of type 1', () => {
    let result = service.newActivity('new video activity');
    expect(result.typeId).toEqual(1);
  })
});
