import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderLinkingComponent } from './order-links.component';

xdescribe('OrderLinkingComponent', () => {
  let component: OrderLinkingComponent;
  let fixture: ComponentFixture<OrderLinkingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderLinkingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderLinkingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
