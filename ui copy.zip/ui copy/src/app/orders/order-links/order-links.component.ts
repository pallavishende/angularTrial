import { Component, TemplateRef, OnInit, Input, OnDestroy } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { OrdersService } from '../orders/orders.service';
import { MatDialog } from '@angular/material';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { UtilityService } from '../../services/utility.service';
import { Subscription } from 'rxjs';
import * as _ from 'lodash';

@Component({
  selector: 'app-order-links',
  templateUrl: './order-links.component.html',
  styleUrls: ['./order-links.component.scss']
})
export class OrderLinkingComponent implements OnInit, OnDestroy {
  @Input() order;
  linkedOrders: Array<any>;
  searchResults: Array<any>;
  selectedOrder;
  searchObj;
  subscriptions = new Subscription();
  expanded = false;
  isDefaultSearchResult = true;
  isLoadingSearchResult = false;
  constructor(
    private ordersService: OrdersService,
    private utilityService: UtilityService,
    private dialog: MatDialog,
    private alerts: SystemAlertsService,
    private formBuilder: FormBuilder
  ) {}

  openDialog(ref: TemplateRef<any>, width, height) {
    this.dialog.open(ref, {
      width: width + 'px',
      height: height + 'px'
    });
  }

  initSearchResults() {
    if (typeof(this.searchResults) === 'undefined') {
      this.getSearchOrderDetails('');
    }
  }

  createSearchForm() {
    this.searchObj = this.formBuilder.group({
      query: ''
    });
    this.subscriptions.add(this.searchObj.get('query').valueChanges.debounceTime(500).distinctUntilChanged().subscribe(() => this.getSearchOrderDetails()));
  }

  getContentDetails(metadata) {
    let contentMetadata = {};
    contentMetadata['originBrandName'] = metadata['brand'];
    contentMetadata['seriesTitle'] = metadata['series'];
    contentMetadata['seasonTitle'] = metadata['season'];
    contentMetadata['episodeNumber'] = metadata['episode'];
    contentMetadata['title'] = metadata['episodeTitle'];
    contentMetadata['movieAndSpecial'] = metadata['movieAndSpecial'];
    return this.utilityService.getHeaderForContentType(contentMetadata, metadata['contentType']);
  }

  getOrderRoute(order) {
    if (order.currentMilestone['status'] !== 'DRAFT') {
      return '/orders/' + order['id'] + '/order-detail';
    } else if (order.lineItems.length === 0) {
      return '/orders/' + order['id'] + '/draft/endpoint';
    } else {
      return '/orders/' + order['id'] + '/draft/';
    }
  }

  isLinked(id) {
    return _.indexOf(_.map(this.order.relatedOrders, 'id'), id) !== -1;
  }

  sortLinkedOrders(orders) {
    // sort by orderType as prior key, then order name in alphabet sequence
    const orderTypeSequence = ['VIDEO', 'COPY', 'GRAPHICS', 'SITE_APP_UPDATES'];
    return _.sortBy(orders, [order => {return _.indexOf(orderTypeSequence, order.metadata.orderType); }, order => order.name.toLowerCase()]);
  }

  updateOrder(orderToUpdate?) {
    this.subscriptions.add(this.ordersService.getOrder(this.order.id).subscribe(
      data => {
        this.order = data;
        if (orderToUpdate && orderToUpdate.isUpdating) {
          orderToUpdate.isUpdating = false;
        }
        this.getLinkedOrderDetails(_.map(data.relatedOrders, 'id'));
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  linkOrder(targetOrder) {
    const orderId = targetOrder.id;
    targetOrder.isUpdating = true;
    if (orderId !== this.order.id) {
      this.subscriptions.add(this.ordersService.linkOrders(this.order.id, [orderId]).subscribe(
        data => {
          this.updateOrder(targetOrder);
        },
        error => {
          this.alerts.addErrorAlerts('Sorry, there was a problem linking this order');
        }
      ));
    }
  }

  removeLinkedOrder(targetOrder) {
    const orderId = targetOrder.id;
    targetOrder.isUpdating = true;
    this.subscriptions.add(this.ordersService.unlinkOrders(this.order.id, [orderId]).subscribe(
      data => {
        this.updateOrder(targetOrder);
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem unlinking this order');
      }
    ));
  }

  getSearchOrderDetails(query?) {
    this.isLoadingSearchResult = true;
    if (typeof(query) === 'undefined') {
      query = this.searchObj.get('query').value;
    }
    const ordersQueryParam = {ordersSearchTerm: query};
    this.subscriptions.add(this.ordersService.getOrders(ordersQueryParam).subscribe(
      data => {
        this.isLoadingSearchResult = false;
        this.searchResults = data.content;
        if (query === '') {
          this.isDefaultSearchResult = true;
        } else {
          this.isDefaultSearchResult = false;
        }
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        this.isLoadingSearchResult = false;
      }
    ));
  }

  getLinkedOrderDetails(ordersId: Array<number>) {
    if (!ordersId || ordersId.length <= 0) {
      this.linkedOrders = [];
      return;
    }
    const ordersQueryParam = {ordersId: ordersId};
    this.subscriptions.add(this.ordersService.getOrders(ordersQueryParam).subscribe(
      data => {
        this.linkedOrders = this.sortLinkedOrders(data.content);
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  ngOnInit() {
    this.getLinkedOrderDetails(_.map(this.order.relatedOrders, 'id'));
    this.createSearchForm();
    this.subscriptions.add(this.ordersService.getLinkedOrdersObservable().skip(1).subscribe(
      data => {
        this.updateOrder();
      }
    ));
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
