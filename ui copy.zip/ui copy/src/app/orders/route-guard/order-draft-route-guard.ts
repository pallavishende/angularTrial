import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { OrdersService } from '../orders/orders.service';
import { NavigationService } from '../../services/navigation.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrderStore } from '../../models/order-store';
import { find } from 'lodash';

@Injectable()
export class OrderDraftRouteGuard implements CanActivate {
    constructor(
        private router: Router,
        private ordersService: OrdersService,
        private navigationService: NavigationService,
        private orderStore: OrderStore,
        private orderProgressTrackerService: OrderProgressTrackerService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (!this.navigationService.isRouteGuardCheckDisabled()) {
            return this.ordersService.getOrder(route.params['id']).map((rawOrder) => {
                this.orderStore.loadInitialModel(rawOrder, rawOrder.metadata.orderType);
                this.orderStore.orderStream
                .first(data => data.lineItems && data.lineItems.length > 0)
                .subscribe(
                    data => {
                        if (data.currentMilestone.status !== 'DRAFT') {
                            this.router.navigate(['orders', route.params['id'], 'order-detail']);
                        }
                        const stepProgressArr = this.orderProgressTrackerService.generateOrderProgress(data.lineItems, data.lineItemsClipId, data.metadata['orderType'].toLowerCase());
                        let lastCompletedStep;
                        const routeStep = state.url.substring(state.url.lastIndexOf('/') + 1);
                        const currentStep = find(stepProgressArr, step => step['step'] === routeStep);
                        // redirect when given route is unreachable or when no step specified
                        if (data.metadata['orderType'].toLowerCase() === 'video') {
                            if (state.url.substring(state.url.lastIndexOf('/') + 1) === 'draft' || !currentStep || ! currentStep.stepReady) {
                            lastCompletedStep = this.orderProgressTrackerService.getLastCompletedOrderStep(data.lineItems, data.lineItemsClipId);
                            this.orderProgressTrackerService.saveRouteData({ 'section': lastCompletedStep.step });
                            this.router.navigate(['orders', route.params['id'], 'draft', lastCompletedStep.step]);
                            }
                        } else {
                            if (state.url.substring(state.url.lastIndexOf('/') + 1) === 'draft' || !currentStep || ! currentStep.stepReady) {
                            lastCompletedStep = this.orderProgressTrackerService.getLastCompletedNonVideoOrderStep(data);
                            this.orderProgressTrackerService.saveRouteData({ 'section': lastCompletedStep.step });
                            this.router.navigate(['orders', route.params['id'], 'draft', lastCompletedStep.step]);
                            }
                        }
                    }
                );
                return true;
            }).catch(error => {
                if (error.status === 404) {
                    console.log('order not exist');
                    this.router.navigate(['invalid-request'], { queryParams: { returnUrl: state.url }});
                }
                return Observable.of(false);
            });
        } else {
            this.navigationService.clearRouteGuardCheck();
            return true;
        }
    }
}
