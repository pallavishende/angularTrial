import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { UserService } from '../../services/user.service';
import { StorageService } from '../../services/storage.service';

@Injectable()
export class OrderListRouteGuard implements CanActivate {

  constructor(private router: Router, private userService: UserService, private storageService: StorageService) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return this.userService.getMyTeams().map(data => {
      if (state.url === '/orders/my-teams-orders' && data.length === 0) {
        this.storageService.resetOrdersObjInLocal();
        this.router.navigateByUrl('/orders/my-orders');
      }
      return true;
    });

  }
}
