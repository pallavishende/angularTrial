import { Injectable } from '@angular/core';
import { OrderStore } from '../../models/order-store';

import * as _ from 'lodash';

import { UtilityService } from '../../services/utility.service';
import { UserService } from '../../services/user.service';
import { Activity } from '../../models/activity';
import { SubActivity } from '../../models/sub-activity';
import { LineItem } from '../../models/line-item';
import { Order } from '../../models/order';

@Injectable()
export class OrderDetailsPackageService {
  order: Order;

  constructor(private orderStore: OrderStore, private utilityService: UtilityService) { }

  get() {
    return this.orderStore.orderStream;
  }

  getOrderStore() {
    return this.orderStore;
  }

  createActivityObj(activityObj: Activity, lineItem: LineItem) {
    let orderStore = this.getOrderStore();
    orderStore.addActivity(activityObj, lineItem);
  }

  removeActivityObj(activity: Activity, lineItem: LineItem){
    let orderStore = this.getOrderStore();

    let activityObj  = _.find(lineItem.activities, function(item) {
        return item['typeId'] === activity.typeId;
    });
    orderStore.removeActivity(activityObj, lineItem);
  }

}
