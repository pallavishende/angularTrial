import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, RouterStateSnapshot } from '@angular/router';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrderDetailsReviewService } from '../order-details-review/order-details-review.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { OrderDetailsFormatService } from '../order-details-format/order-details-format.service';
import { Order } from '../../models/order';
import { LineItem } from '../../models/line-item';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { UserService } from '../../services/user.service';
import { EnvironmentService } from '../../services/environment.service';
import 'rxjs/add/operator/map';
import { Subscription } from 'rxjs/Subscription';
import * as _ from 'lodash';

@Component({
  selector: 'app-order-details-side-bar',
  templateUrl: './order-details-side-bar.component.html',
  styleUrls: ['./order-details-side-bar.component.scss', '../order-customization-base/order-customization-base.component.scss'],
  providers: [ OrderProgressTrackerService, OrderDetailsReviewService ]
})
export class OrderDetailsSideBarComponent implements OnInit, OnDestroy {
  order: Order;
  users;
  orderId: number;
  endpointProfiles;
  subscriptions = new Subscription();
  isReady: boolean = false;
  showSidebarDetails: boolean;
  brandName: string;
  requestType: string;
  instructionMap = {};
  platformList = [];
  deleteModalOptions = {
    version: 'NA',
    msg: '',
    btnMsg: '',
    action: {}
  };
  isUpdatingOrder = false;
  graphicsInstrFormFields;
  isEnvGreaterThanUAT = false;

  constructor(
    private orderProgressTrackerService: OrderProgressTrackerService,
    private endpointProfileService: EndpointProfileService,
    private router: Router,
    private orderDetailsReviewService: OrderDetailsReviewService,
    private alerts: SystemAlertsService,
    private userService: UserService,
    private orderDetailsFormatService: OrderDetailsFormatService,
    private environmentService: EnvironmentService
  ) {
    this.isEnvGreaterThanUAT = this.environmentService.isRuntimeEnvironmentGreaterThan(3);
  }

  ngOnInit() {

    this.subscriptions.add(this.orderDetailsFormatService.getOrderGraphicsFormFields().subscribe((data) => {
      this.graphicsInstrFormFields = data;
    }));
    this.subscriptions.add(this.orderProgressTrackerService.get()
    .subscribe(
      data => {
        const snapshot: RouterStateSnapshot = this.router.routerState.snapshot;
        const orderId = snapshot.url.substring(8, snapshot.url.indexOf('/draft'));
        if (data['id'] && data['id'].toString() === orderId) {
          this.order = data;
          if(this.order.metadata['orderType'] === 'GRAPHICS' && !this.isEnvGreaterThanUAT) {
            let obj = this.orderDetailsReviewService.getGraphicsOrderSummary(this.graphicsInstrFormFields, this.order.lineItems[0].activities[0].instructions);
            this.instructionMap = obj.instructionMap;
            this.brandName = this.instructionMap['brand'] ? this.instructionMap['brand'] : '';
            let request = this.order.lineItems[0].activities[0].instructions.filter(item => item.label === 'requestType')[0]
            this.requestType = request && request.values[0] ? request.values[0] : '';
            this.platformList = obj.platformList;
            this.platformList.forEach(plat => {
              plat.options.forEach(p => {
                if(p.label === 'Specs') {
                  p.value = p.value.join(', ');
                  //p.value = p.value.substring(0, p.value.length - 2);
                }
              })
            })
          }
          console.log('this is sidebar:', this.order);
          this.orderId = this.order.id;
          this.subscriptions.add(this.endpointProfileService.getEndpointProfiles().subscribe(
            data => {
              this.endpointProfiles = data;
            }
          ));
          this.isReady = this.order.lineItems.length === 0 && this.order.id > 0;
          this.getUpdatingOrdersStatus(this.order.lineItems);
          /*if (this.order['groupedLineItemsByClipId']) {
            this.order = this.orderProgressTrackerService.setLineItemsApproveVideoAssignee(this.order);
          }*/
        }
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  getDisplayNameFromEmail(email: string): string {
    return this.userService.getDisplayNameFromEmail(email);
  }

  getClipIdentifier(lineItem: LineItem) {
    if (lineItem.metadata.length) {
      const clipIdentifier = lineItem.metadata[0]['clipId'] || lineItem.metadata[0]['clipTitle'];
      return clipIdentifier;
    }
  }

  getApproveVideoAssignee(lineItem: LineItem): string {
    const clipIdentifier = lineItem.metadata['clipId'] || lineItem.metadata['clipTitle'];
    // this.order = this.orderProgressTrackerService.setLineItemsApproveVideoAssignee(this.order);
    if (this.order['groupedLineItemsByClipId'][clipIdentifier] &&
    this.order['groupedLineItemsByClipId'][clipIdentifier].approveVideoAssignee) {
      return this.getDisplayNameFromEmail(this.order['groupedLineItemsByClipId'][clipIdentifier].approveVideoAssignee);
    } else  {
      return '';
    };
  }

  deleteClip(clipMetadata) {
    if (this.order.metadata['isFullEpisode']) {

    }
    if (clipMetadata.clipTitle) {
      this.deleteModalOptions.version = clipMetadata.clipTitle.toString();
      console.log('TESTING THIS STUFF:', this.deleteModalOptions);
    }
    this.deleteModalOptions.msg = `All info in this clip, and the clip versions, will be removed from the order and can’t be undone.`;
    this.deleteModalOptions.btnMsg = 'YES, DELETE CLIP';
    let clipIdentifier = {
      value: clipMetadata.clipId || clipMetadata.clipTitle,
      property: clipMetadata.clipId ? 'clipId' : 'clipTitle'
    };
    this.deleteModalOptions.action = () => {
      this.orderDetailsReviewService.removeLineItemsFromOrder(clipIdentifier);
      this.orderProgressTrackerService.saveOrder(this.order, clipMetadata.clipTitle + ' has been removed from the order.');
    };
  }

  deleteVersion(lineItem) {
    this.deleteModalOptions.version = _.get(lineItem, 'customConfig.version').toString();
    this.deleteModalOptions.msg = `This clip version will be removed from the order and can’t be undone.`;
    this.deleteModalOptions.btnMsg = 'YES, DELETE VERSION';
    this.deleteModalOptions.action = () => {
      this.orderProgressTrackerService.getOrderStore().removeLineItem(lineItem);
      console.log('deleteVersion > order: ', this.order);
      this.orderProgressTrackerService.saveOrder(this.order, _.get(lineItem, 'customConfig.version') + ' has been removed from the order.');
    }
  }

  getTotals(lineItem, endpoint) {
    if (lineItem.endpoint_info) {
      return lineItem.endpoint_info[endpoint].length;
    }
  }

  hasMoreThenOne(clipId, clipTitle) {
    return _.filter(this.order.lineItems, (lineItem) => {
      return lineItem['metadata'][0]['clipId'] === clipId || lineItem['metadata'][0]['clipTitle'] === clipTitle;
    });
  }

  getActivity(lineItem, typeId) {
    return _.filter(lineItem.activities, (activity) => {
      return activity['typeId'] === typeId;
    });
  }

  getQuantity(item) {
    return this.getActivity(item, 2)[0];
  }

  getDate(lineItem, dateProp) {
    if (_.get(lineItem, dateProp) !== 'Invalid date' ) {
      return _.get(lineItem, dateProp);
    }
  }

  getUpdatingOrdersStatus(lineItems) {
    this.isUpdatingOrder = false;
    lineItems.forEach((lineItem) => {
      const composeContent = _.find(lineItem['activities'], {'typeId': 1});
      if (composeContent) {
        if (composeContent['input']['isUploading']) {
          this.isUpdatingOrder = true;
        }
      }
    });
  }

  getInstructionsIndex(instructions, label) {
    return instructions.findIndex(inst => inst.label === label);
  }

  isInstructionsAvailable() {
    return !(this.order.lineItems[0].activities[0].subActivities[0].assignedUserEmail ||
      this.order.lineItems[0].dueDateTime || 
      this.order.lineItems[0].launchDateTime || this.brandName || 
      (this.order.metadata['orderType'] === 'COPY' && this.order.lineItems[0].activities[0].instructions[0] && this.order.lineItems[0].activities[0].instructions[0].values[0] !== ''));
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
