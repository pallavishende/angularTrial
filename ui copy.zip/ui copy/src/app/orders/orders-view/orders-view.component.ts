import { Component, OnInit } from '@angular/core';
import { StorageService } from '../../services/storage.service';
import { UserService } from '../../services/user.service';
import { EnvironmentService } from '../../services/environment.service';

@Component({
  selector: 'app-orders-view',
  templateUrl: './orders-view.component.html',
  styleUrls: ['./orders-view.component.scss']
})
export class OrdersViewComponent implements OnInit {
  teamName = '';

  constructor( private storageService: StorageService, private userService: UserService, private environmentService: EnvironmentService) {}

  clearOrdersObjFromlocal() {
    this.storageService.resetOrdersObjInLocal();
  }

  ngOnInit() {
    this.userService.getMyTeamsInfo().subscribe((data) => {
      if (data.length > 0) {
        this.teamName = data[0].name;
      }
    });
  }
}
