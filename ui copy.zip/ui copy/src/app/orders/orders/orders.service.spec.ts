/* tslint:disable:no-unused-variable */
import { TestBed, async, inject } from '@angular/core/testing';
import { OrdersService } from './orders.service';
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod, Headers} from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { ConfigService } from '../../services/config.service';
import { UserService } from '../../services/user.service';
import { SecretService } from '../../services/secret.service';
import { StorageService } from '../../services/storage.service';
import { AdalService } from 'ng2-adal/dist/core';
import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';
import { LoginService } from '../../login/login.service';

describe('OrderSservice', () => {

  let ordersValues = {
    orders: [
      {id: 1, prop: "hi"},
      {id: 2, prop: "hello"},
      {id: 3, prop: "good-bye"}
    ]
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      providers: [
        OrdersService,
        ConfigService,
        MockBackend,
        UserService,
        LoginService,
        SecretService,
        StorageService,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        AdalService,
        {
            provide: HttpClient,
            useFactory: (http: Http) => http,
            deps: [Http]
        },
        EnvironmentService,
        ConfigurationManagerService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  });

  it('should create the service', inject([OrdersService], (service: OrdersService) => {
    expect(service).toBeTruthy();
  }));

  it('#getOrders should call endpoint and return success response', inject([OrdersService, MockBackend], (service: OrdersService, mockBackend: MockBackend) => {

    mockBackend.connections.subscribe((connection: MockConnection) => {
        let options = new ResponseOptions({
          body: JSON.stringify(ordersValues)
        });

        let header = new Headers();
        header.append('Content-Type', 'application/json');
        connection.mockRespond(new Response(options));
      });

      let subject = service;


      // subject
      //   .getOrders()
      //   .subscribe((data) => {
      //     expect(data).toEqual(ordersValues);
      //   });
  }));

  // fit('#deleteOrder should call endpoint delete an order', inject([OrdersService, MockBackend], (service: OrdersService, mockBackend: MockBackend) => {
  //
  //   mockBackend.connections.subscribe((connection: MockConnection) => {
  //       let options = new ResponseOptions(
  //         ordersValues.orders
  //       );
  //
  //       let header = new Headers();
  //       header.append('Content-Type', 'application/json');
  //       connection.mockRespond(new Response(options));
  //     });
  //
  //     let subject = service;
  //
  //     subject
  //       .deleteOrder(1)
  //       .subscribe((data) => {
  //         expect(data).toEqual(
  //           ordersValues.orders
  //         );
  //       });
  // }));

  xit('#getOrder should call endpoint and return one order', inject([OrdersService, MockBackend], (service: OrdersService, mockBackend: MockBackend) => {

    mockBackend.connections.subscribe((connection: MockConnection) => {
        let options = new ResponseOptions({
          body: JSON.stringify(ordersValues.orders)
        });

        let header = new Headers();
        header.append('Content-Type', 'application/json');
        connection.mockRespond(new Response(options));
      });

      let subject = service;

      subject
        .getOrder(1)
        .subscribe((data) => {
          expect(data._body).toEqual(ordersValues.orders);
        });
  }));

  xit('#getRawOrder should call endpoint and return one order', inject([OrdersService, MockBackend], (service: OrdersService, mockBackend: MockBackend) => {

    mockBackend.connections.subscribe((connection: MockConnection) => {
        let options = new ResponseOptions({
          body: JSON.stringify(ordersValues.orders)
        });

        let header = new Headers();
        header.append('Content-Type', 'application/json');
        connection.mockRespond(new Response(options));
      });

      let subject = service;

      subject
        .getRawOrder(1)
        .subscribe((data) => {
          expect(data['_body']).toEqual(ordersValues.orders);
        });
  }));

  xit('#modifyOrder should change the order object', inject([OrdersService, MockBackend],
  (service: OrdersService, mockBackend: MockBackend) => {

    mockBackend.connections.subscribe((connection: MockConnection) => {
        let options = new ResponseOptions({
          body: JSON.stringify(ordersValues.orders)
        });

        let header = new Headers();
        header.append('Content-Type', 'application/json');
        connection.mockRespond(new Response(options));
      });

      let subject = service;

      subject
        .modifyOrder(1, {prop: 'later'})
        .subscribe((data) => {
          expect(data._body).toEqual(ordersValues.orders);
        });
  }));

  // fit('#placeOrder should place the order', inject([OrdersService, MockBackend], (service: OrdersService, mockBackend: MockBackend) => {
  //
  //   mockBackend.connections.subscribe((connection: MockConnection) => {
  //       let options = new ResponseOptions({
  //         body: ordersValues.orders
  //       });
  //
  //       let header = new Headers();
  //       header.append('Content-Type', 'application/json');
  //       connection.mockRespond(new Response(options));
  //     });
  //
  //     let subject = service;
  //
  //     subject
  //       .placeOrder(1)
  //       .subscribe((data) => {
  //         expect(data).toEqual(ordersValues.orders);
  //       });
  // }));


});
