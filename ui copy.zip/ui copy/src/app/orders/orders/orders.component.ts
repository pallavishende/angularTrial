import { Component, OnInit, OnDestroy, HostListener, ApplicationRef } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { OrdersService } from './orders.service';
import { CatalogService } from '../../catalog/catalog.service';
import { ActivatedRoute } from '@angular/router';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { Order } from '../../models/order';
import { UserService } from '../../services/user.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { EnvironmentService } from '../../services/environment.service';
import { NavigationService } from '../../services/navigation.service';
import { StorageService } from '../../services/storage.service';
import * as _ from 'lodash';
import * as moment from 'moment/moment';
import { UtilityService } from '../../services/utility.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.scss', '../order-customization-base/order-customization-base.component.scss']
})

export class OrdersComponent implements OnInit, OnDestroy {
  subscriptions = new Subscription();
  model: any = {};
  ordersObj;
  persistedOrdersObj;
  teamInfo;
  loginInfo;
  showLineItems = true;
  clicked: Number;
  selectedOrder;
  modalMode;
  parentOrderId;
  nameOfItem;
  orders: Array<any>;
  pageCount = 0;
  pageNumber = 0;
  isLoadingData: boolean;
  orderType;
  sortInAsc = false;
  sortColumn = 'last_modified_date';  // by default the table is sorted by last created order
  filterObj: Object = {};
  dateFilterObj: Object = {};
  filterNames: Array<any> = [];
  favoriteTeamList;
  dateFilterIndex = 8; // please also change this when adding new filters, currently have 7 regular filters
  showCalendars = false;
  customStartDate = '';
  customEndDate = '';
  dateQuery = '';
  fullFilterQuery = '';
  numberOfFiltersToShow = [5, 5, 5, 5, 5, 5];
  searchObj: FormGroup;
  validSearchInput: boolean;
  selectedFilters: Object = {};
  ordersQueryParamsObj = {
    ordersType: '',
    ordersSearchTerm: '',
    filterSearchTerms: [],
    filterQuery: '',
    startDate: '',
    endDate: ''
  };
  isEnvironmentGreaterThanUAT;

  @HostListener('window:scroll', [])
  onWindowScroll() {
    const scrollPercentage = (((window.scrollY + window.innerHeight) / document.scrollingElement.scrollHeight)) * 100;
    if (scrollPercentage >= 98 && this.orders && !this.isLoadingData) {
      if (this.orders.length < this.ordersObj.totalElements) {
        this.isLoadingData = true;
        this.pageNumber = this.pageCount + 2;
        this.pageCount++;
        this.isLoadingData = true;
        this.resetSortObj();
        this.getOrders();
      }
    }
  }

  constructor(
    private ordersService: OrdersService,
    private catalogService: CatalogService,
    private navigationService: NavigationService,
    private userService: UserService,
    private utilityService: UtilityService,
    private environmentService: EnvironmentService,
    private storageService: StorageService,
    private loadingMask: LoadingMaskService,
    private alerts: SystemAlertsService,
    private activeRoute: ActivatedRoute,
    private searchFormBuilder: FormBuilder,
    private appRef: ApplicationRef
  ) { }

  ngOnInit() {
    this.isEnvironmentGreaterThanUAT = this.environmentService.isRuntimeEnvironmentGreaterThan(3);
    this.loadingMask.enableLoadingMask('orders');
    this.createSearchForm();
    this.orderType = this.activeRoute.snapshot.url[0].path;
    this.navigationService.setActiveOrdersListTab(this.orderType);
    this.userService.getMyTeams().subscribe((teamsData) => {
      this.teamInfo = teamsData;
      this.initialize();
    });
    this.loginInfo = this.userService.getUserLoginInfo();
  }

  createSearchForm() {
    this.searchObj = this.searchFormBuilder.group({
      searchTerm: ''
    });
    this.subscriptions.add(this.searchObj.get('searchTerm').valueChanges.debounceTime(500).distinctUntilChanged().subscribe(
      () => this.searchOrders())
    );
  }

  searchOrders() {
    const searchTerm = this.searchObj.get('searchTerm').value;
    this.ordersQueryParamsObj.ordersSearchTerm = searchTerm;
    this.resetOrders();
    this.isLoadingData = true;
    this.loadingMask.enableLoadingMask('orders');
    this.getOrders();
  }

  getOrders(pageNumber?: number) {
    let pageSize;
    if (pageNumber === undefined) {
      pageNumber = this.pageNumber;
    } else {
      pageSize = this.orders.length;
    }
    this.setOrdersToLocalStorage();

    this.subscriptions.add(this.ordersService.getOrders(this.ordersQueryParamsObj, pageNumber, pageSize).subscribe(
      data => {
        this.loadingMask.disableLoadingMask();

        this.ordersObj = data;
        if (pageNumber === 0) {
          this.orders = this.ordersObj.content;
        } else {
          this.orders.push.apply(this.orders, this.ordersObj.content);
        }
        this.isLoadingData = false;
        this.updateLastSubmittedOrder();
        this.appRef.tick();
      },
      error => {
        this.loadingMask.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  updateLastSubmittedOrder(): void {
    const lastSubmittedOrderId = this.ordersService.getLastSubmittedOrderId();
    if (lastSubmittedOrderId && this.orderType !== 'my-drafts') {
      const lastSubmittedOrderIndex = _.indexOf(this.orders, _.find(this.orders, { id: lastSubmittedOrderId }));
      if (this.orders[lastSubmittedOrderIndex] && this.orders[lastSubmittedOrderIndex].currentMilestone.status === 'DRAFT') {
        setTimeout(() => {
          this.subscriptions.add(this.ordersService.getOrderDetails(lastSubmittedOrderId).subscribe(
            (data) => {
              this.orders[lastSubmittedOrderIndex].currentMilestone.status = data.currentMilestone.status;
              this.ordersService.clearLastSubmittedOrderId();
            }
          ));
        }, 2000);
      }
    }
  }


  resetOrders() {
    this.pageNumber = 0;
    this.pageCount = 0;
    this.resetSortObj();
  }

  // begin filter methods
  // make sure to change dateFilterIndex too when adding or removing filters
  getFilters() {
    let filtersObservable;

    if (this.teamInfo && this.teamInfo[0]) {
      filtersObservable = this.ordersService.getFilters(this.orderType, this.teamInfo[0].id);
    } else {
      filtersObservable = this.ordersService.getFilters(this.orderType);
    }

    this.subscriptions.add(filtersObservable.subscribe(
      data => {
        this.filterObj = data;
        this.filterNames = [];
        if (this.filterObj['teamQueue'] && this.filterObj['teamQueue'].length > 0 && this.orderType === 'all-orders') {
          this.filterNames.push('teamQueue');
          let filterArray = this.filterObj['teamQueue'];
          if (!this.isEnvironmentGreaterThanUAT) {
            this.sortByFavoriteList(filterArray);
          }
        }
        if (this.filterObj['orderTypes'] && this.filterObj['orderTypes'].length > 0) { this.filterNames.push('orderTypes'); }
        if (this.filterObj['ownedBy'] && this.filterObj['ownedBy'].length > 0) {
          this.filterNames.push('ownedBy');
          this.filterObj['ownedBy'] = _.orderBy(this.filterObj['ownedBy'], 'label');
        }
        if (this.filterObj['team'] && this.filterObj['team'].length > 0) {
          this.filterNames.push('team');
          this.filterObj['team'] = _.orderBy(this.filterObj['team'], 'label');
        }
        if (this.filterObj['brands'] && this.filterObj['brands'].length > 0) { this.filterNames.push('brands'); }
        if (this.filterObj['series'] && this.filterObj['series'].length > 0) {
          this.filterNames.push('series');
          this.filterObj['series'] = _.orderBy(this.filterObj['series'], 'label'.toLowerCase());
        }
        if (this.filterObj['moviesAndSpecials'] && this.filterObj['moviesAndSpecials'].length > 0) { this.filterNames.push('moviesAndSpecials'); }
        if (this.filterObj['statuses'] && this.filterObj['statuses'].length > 0) { this.filterNames.push('statuses'); }

      },
      error => {
        console.log('order filters error:', error);
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      }
    ));

    this.dateFilterObj = {
      content: [
        { 'label': 'Today', 'id': 'today' },
        { 'label': 'Last 7 Days', 'id': 'week' },
        { 'label': 'Last 30 Days', 'id': 'twoWeeks' },
        { 'label': 'Custom', 'id': 'custom' }
      ]
    };
  }

  sortByFavoriteList(filterArray) {
    this.loadingMask.enableLoadingMask();
    filterArray.forEach(arr => {
      arr['checked'] = false;
      arr['order'] = 100;
    });
    let favoriteTeamObservable = this.userService.getFavoritedTeams(this.loginInfo.email);
    this.subscriptions.add(favoriteTeamObservable.subscribe(
    data => {
      this.favoriteTeamList = data;
      if(this.favoriteTeamList.length > 0) {
        let count = 1;
        this.favoriteTeamList.forEach(favoriteObj => {
           let filteredObj = filterArray.filter(obj => obj.id === favoriteObj.id)[0];
           filteredObj['order'] = count;
           filteredObj['checked'] = favoriteObj.favorite;
           count++;
        });

        filterArray = filterArray.sort((a, b) => {return a.order - b.order});
      }
      this.loadingMask.disableLoadingMask();
    }, error => {
      this.loadingMask.disableLoadingMask();
      this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
    }));
  }

  teamFavoriteStatus(filterItem) {
    filterItem.checked = !filterItem.checked;
    this.loadingMask.enableLoadingMask();
    if (filterItem.checked) {
      let body = {
        userEmail: this.loginInfo.email
      };
      let subUrl = filterItem.id + '/followers';
      this.userService.postFavoritedTeams(subUrl, body).subscribe(postData => {
        this.sortByFavoriteList(this.filterObj['teamQueue']);
      }, error => {
        this.loadingMask.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      });
    } else {
      let subUrl = filterItem.id + '/followers?userEmail=' + this.loginInfo.email;
      this.userService.deleteFavoritedTeam(subUrl).subscribe(deleteData => {
        this.sortByFavoriteList(this.filterObj['teamQueue']);
      }, error => {
        this.loadingMask.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      });

    }
  }

  displayFilterName(filterGroupName) {
    if (filterGroupName === 'teamQueue') { return 'Team Queues'; }
    if (filterGroupName === 'brands') { return 'Brand'; }
    if (filterGroupName === 'series') { return 'Series'; }
    if (filterGroupName === 'moviesAndSpecials') { return 'Movies and Specials'; }
    if (filterGroupName === 'ownedBy') { return 'Owner'; }
    if (filterGroupName === 'team') { return 'Owner (Team)'; }
    if (filterGroupName === 'statuses') { return 'Status'; }
    if (filterGroupName === 'orderTypes') { return 'Order Types'; }
  }

  formatLabel(label, filterName) {
    if (filterName === 'team' || filterName === 'teamQueue') {
      return label;
    } else if (filterName === 'brands') {
      if (label === 'na' || label === 'n/a') {
        return 'No Brand / Acquired';
      } else {
        return label;
      }
    } else if (label === 'SITE_APP_UPDATES') {
      return 'Site & App Updates';
    } else if (label === 'VIDEO') {
      return 'Video Publishing';
    } else {
      let tmpLabel = label || '';
      tmpLabel = tmpLabel.replace('_', ' ').toLowerCase();
      return tmpLabel.replace(/\w\S*/g, (word) => {
        return word.charAt(0).toUpperCase() + word.substr(1).toLowerCase();
      });
    }
  }

  onChangeFilter(filterGroupIndex, e, filterItemIndex, filterItem) {
    const valueToSubmit = e.target.title;

    const filterTermsArr = this.ordersQueryParamsObj.filterSearchTerms;
    if (filterGroupIndex === _.indexOf(this.filterNames, 'teamQueue')) { this.fullFilterQuery = 'teams=' + valueToSubmit; }
    if (filterGroupIndex === _.indexOf(this.filterNames, 'ownedBy')) { this.fullFilterQuery = 'ownedBy=' + valueToSubmit; }
    if (filterGroupIndex === _.indexOf(this.filterNames, 'team')) { this.fullFilterQuery = 'ownerTeam=' + valueToSubmit; }
    if (filterGroupIndex === _.indexOf(this.filterNames, 'brands')) { this.fullFilterQuery = 'brands=' + valueToSubmit; }
    if (filterGroupIndex === _.indexOf(this.filterNames, 'series')) { this.fullFilterQuery = 'series=' + valueToSubmit; }
    if (filterGroupIndex === _.indexOf(this.filterNames, 'moviesAndSpecials')) { this.fullFilterQuery = 'moviesAndSpecials=' + valueToSubmit; }
    if (filterGroupIndex === _.indexOf(this.filterNames, 'statuses')) { this.fullFilterQuery = 'statuses=' + valueToSubmit; }
    if (filterGroupIndex === _.indexOf(this.filterNames, 'orderTypes')) { this.fullFilterQuery = 'orderTypes=' + valueToSubmit; }
    if (!this.selectedFilters.hasOwnProperty(filterGroupIndex)) {
      this.selectedFilters[filterGroupIndex] = [];
    }

    if (e.target.checked) {
      if (filterGroupIndex === this.dateFilterIndex) {
        this.selectedFilters[this.dateFilterIndex] = [];
        this.showCalendars = false;
        this.clearCustomDates();
        _.forEachRight(filterTermsArr, (item) => {
          if (item.includes('fromDate=')) {
            filterTermsArr.splice(filterTermsArr.indexOf(item, 1));
          }
        });
        if (filterItemIndex === 3) { // custom date filter
          this.showCalendars = true;
          this.selectedFilters[filterGroupIndex].push(filterItemIndex, filterItem.id);
          return;
        } else {
          this.setDateFilter(filterItemIndex, 'checked');
          this.fullFilterQuery = this.dateQuery;
        }
      }

      this.selectedFilters[filterGroupIndex].push(filterItemIndex, filterItem.id);
      this.isLoadingData = true;
      filterTermsArr.push(this.fullFilterQuery);
      this.ordersQueryParamsObj.filterQuery = filterTermsArr.join('&');
      this.resetPageNumberAndGetOrders();

    } else {
      if (this.selectedFilters.hasOwnProperty(filterGroupIndex)) {
        this.selectedFilters[filterGroupIndex].splice(this.selectedFilters[filterGroupIndex].indexOf(filterItemIndex), 1);
        this.selectedFilters[filterGroupIndex].splice(this.selectedFilters[filterGroupIndex].indexOf(filterItem.id), 1);
      }

      if (filterGroupIndex === this.dateFilterIndex) {
        if (filterItemIndex === 3) { // custom date filter
          if (this.customStartDate || this.customEndDate) {
            this.clearCustomDates();
            filterTermsArr.splice(filterTermsArr.indexOf(this.fullFilterQuery), 1);
            this.ordersQueryParamsObj.filterQuery = filterTermsArr.join('&');
            this.resetPageNumberAndGetOrders();
          }
          this.showCalendars = false;
          return;
        } else {
          this.setDateFilter(filterItemIndex, 'unchecked');
          this.fullFilterQuery = this.dateQuery;
        }
      }

      this.isLoadingData = true;
      filterTermsArr.splice(filterTermsArr.indexOf(this.fullFilterQuery), 1);
      this.ordersQueryParamsObj.filterQuery = filterTermsArr.join('&');
      this.resetPageNumberAndGetOrders();
    }
  }

  getActiveFilters(filterGroup, filterItem) {
    if (this.selectedFilters[filterGroup] && this.selectedFilters[filterGroup].indexOf(filterItem) !== -1) {
      return true;
    }
  }

  setDateFilter(filterItemIndex, state) {
    let startDate, endDate;
    if (state === 'checked') {
      switch (filterItemIndex) {
        case 0: // today
          startDate = moment().utc().startOf('day').format('YYYY-MM-DD');
          endDate = moment().utc().endOf('day').format('YYYY-MM-DD');
          this.dateQuery = 'fromDate=' + startDate + '&toDate=' + endDate;
          break;
        case 1: // last seven days
          startDate = moment().utc().startOf('day').subtract(7, 'days').format('YYYY-MM-DD');
          endDate = moment().utc().endOf('day').subtract(1, 'days').format('YYYY-MM-DD');
          this.dateQuery = 'fromDate=' + startDate + '&toDate=' + endDate;
          break;
        case 2: // last 14 days
          startDate = moment().utc().startOf('day').subtract(30, 'days').format('YYYY-MM-DD');
          endDate = moment().utc().endOf('day').subtract(1, 'days').format('YYYY-MM-DD');
          this.dateQuery = 'fromDate=' + startDate + '&toDate=' + endDate;
          break;
      }
    }
  }

  getResultsByCustomDate(date, end) {
    const filterTermsArr = this.ordersQueryParamsObj.filterSearchTerms;
    if (end === 'from') {
      if (this.customStartDate === moment.utc(date).format('YYYY-MM-DD')) {
        return;
      }
      this.customStartDate = date;
      this.customStartDate = moment.utc(this.customStartDate).format('YYYY-MM-DD');
      this.ordersQueryParamsObj.startDate = this.customStartDate;
    }
    if (end === 'to') {
      if (this.customEndDate === moment.utc(date).endOf('day').format('YYYY-MM-DD')) {
        return;
      }
      this.customEndDate = date;
      this.customEndDate = moment.utc(this.customEndDate).endOf('day').format('YYYY-MM-DD');
      this.ordersQueryParamsObj.endDate = this.customEndDate;
    }
    this.dateQuery = 'fromDate=' + this.customStartDate + '&toDate=' + this.customEndDate;
    if (date) {
      if (this.customStartDate && this.customEndDate) {
        this.fullFilterQuery = this.dateQuery;
        _.forEachRight(filterTermsArr, (item) => {
          if (_.includes(item, 'fromDate=')) {
            filterTermsArr.splice(filterTermsArr.indexOf(item), 1);
          }
        });
        filterTermsArr.push(this.fullFilterQuery);
        this.ordersQueryParamsObj.filterQuery = filterTermsArr.join('&');
        this.resetPageNumberAndGetOrders();
      }
    } else {
      if (this.customStartDate === 'Invalid date' && this.customEndDate === 'Invalid date') {
        filterTermsArr.splice(filterTermsArr.indexOf(this.fullFilterQuery), 1);
        this.ordersQueryParamsObj.filterQuery = filterTermsArr.join('&');
        this.customStartDate = '';
        this.customEndDate = '';
        this.resetPageNumberAndGetOrders();
      } else {
        return false;
      }
    }
  }

  clearFilterChecks(filterGroupIndex) {
    const filterTermsArr = this.ordersQueryParamsObj.filterSearchTerms;
    if (filterGroupIndex === this.dateFilterIndex) {
      this.showCalendars = false;
      this.customStartDate = '';
      this.customEndDate = '';
    }
    this.selectedFilters[filterGroupIndex].length = 0;
    let substr = '';
    if (filterGroupIndex === _.indexOf(this.filterNames, 'ownedBy')) { substr = 'ownedBy='; }
    if (filterGroupIndex === _.indexOf(this.filterNames, 'team')) { substr = 'teams='; }
    if (filterGroupIndex === _.indexOf(this.filterNames, 'brands')) { substr = 'brands='; }
    if (filterGroupIndex === _.indexOf(this.filterNames, 'series')) { substr = 'series='; }
    if (filterGroupIndex === _.indexOf(this.filterNames, 'statuses')) { substr = 'statuses='; }
    if (filterGroupIndex === _.indexOf(this.filterNames, 'orderTypes')) { substr = 'orderTypes='; }
    if (filterGroupIndex === this.dateFilterIndex) { substr = 'fromDate='; }

    this.isLoadingData = true;

    _.forEachRight(filterTermsArr, (item) => {
      if (_.includes(item, substr)) {
        filterTermsArr.splice(filterTermsArr.indexOf(item), 1);
      }
    });
    this.ordersQueryParamsObj.filterQuery = filterTermsArr.join('&');
    this.resetPageNumberAndGetOrders();
  }

  clearSearchAndFilters(e, keepSearchTerm?: boolean) {
    e.preventDefault();
    _.forEach(this.selectedFilters, (item) => {
      item.length = 0;
    });
    this.clearCustomDates();
    this.showCalendars = false;
    this.isLoadingData = true;
    if (!keepSearchTerm) {
      this.searchObj.patchValue({ 'searchTerm': '' });
    }
    this.ordersQueryParamsObj.filterSearchTerms = [];
    this.ordersQueryParamsObj.filterQuery = '';
    this.resetPageNumberAndGetOrders();
  }

  clearCustomDates() {
    this.ordersQueryParamsObj.startDate = '';
    this.ordersQueryParamsObj.endDate = '';
    this.customStartDate = '';
    this.customEndDate = '';
  }

  resetPageNumberAndGetOrders() {
    this.resetOrders();
    this.loadingMask.enableLoadingMask('orders');
    this.getOrders();
  }

  // end filter methods

  clipsOnly(lineItems, archiveOnly?) {
    const customLineitems = lineItems.filter(lineItem => lineItem['metadata'][0]['clipId'] == null);
    lineItems = lineItems.filter(lineItem => lineItem['metadata'][0]['clipId']);
    if (archiveOnly) {
      return _.uniqBy(lineItems, (lineItem) => {
        return lineItem['metadata'][0]['clipId'];
      }).concat(customLineitems);
    } else {
      return _.uniqBy(lineItems, (lineItem) => {
        return lineItem['metadata'][0]['clipId'];
      });
    }
  }

  // retrieving clip details on demand and store in ordered array
  getClips(item, index: number) {
    const lineItems = item.lineItems;
    // for every lineItems, if clip is empty then make backend calls
    for (let i = 0; i < this.orders[index]['lineItems'].length; i++) {
      if (!this.orders[index]['lineItems'][i]['metadata'][0]['clip']) {
        let dsId = [];
        let clipId = [];
        _.forEach(lineItems, (lineitem) => {
          dsId.push(lineitem['metadata'][0]['dsId']);
        });
        dsId = _.uniq(dsId);
        // for every different dsId make one call
        for (let j = 0; j < dsId.length; j++) {
          _.forEach(lineItems, (lineitem) => {
            if (lineitem['metadata'][0]['clipId']) {
              clipId.push(lineitem['metadata'][0]['clipId']);
            }
          });
          clipId = _.uniq(clipId);
          if (clipId.length > 0) {
            this.subscriptions.add(this.catalogService.getClips(item['metadata']['vmId'], dsId[j], clipId).subscribe(
              data => {
                data = data['content'];
                for (let n = 0; n < this.orders[index]['lineItems'].length; n++) {
                  if (this.orders[index]['lineItems'][n]['metadata'][0]['dsId'] === dsId[j]) {
                    const clipInfo = data['assetMaterial']['clips']
                      .find(clip => clip['id'] === this.orders[index]['lineItems'][n]['metadata'][0]['clipId']);
                    this.orders[index]['lineItems'][n]['metadata'][0]['clip'] = clipInfo;
                    if (!clipInfo) {
                      this.orders[index]['lineItems'][n]['metadata'][0]['clip'] = [];
                    }
                  }
                }
              },
              error => {
                console.log('Error: couldn\'t fetch clip details');
                this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
              }
            ));
          } else {
            for (let n = 0; n < this.orders[index]['lineItems'].length; n++) {
              if (this.orders[index]['lineItems'][n]['metadata'][0]['dsId'] === dsId[j]) {
                this.orders[index]['lineItems'][n]['metadata'][0]['clip'] = [];
              }
            }
          }
        }
        return;
      }
    }
  }

  deleteOrder() {
    this.loadingMask.enableLoadingMask('orders');
    this.subscriptions.add(this.ordersService.deleteOrder(this.selectedOrder.id).subscribe(
      data => {
        delete this.selectedOrder;
        // getOrders() disables the loading mask
        this.getOrders(0);  // 0 is the page number
        this.getFilters();
        this.resetSortObj();
      },
      error => {
        this.loadingMask.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        delete this.selectedOrder;
        console.log('error');
      }
    ));
  }

  cancelOrder() {
    this.loadingMask.enableLoadingMask('orders');
    this.subscriptions.add(this.ordersService.cancelOrder(this.selectedOrder.id)
      .subscribe(
        data => {
          delete this.selectedOrder;
          // getOrders() disables the loading mask
          this.getOrders(0);  // 0 is the page number
          this.getFilters();
          this.resetSortObj();
        },
        error => {
          this.loadingMask.disableLoadingMask();
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
          delete this.selectedOrder;
          console.log('error');
        }
      ));
  }

  sortOrdersData(property: string) {
    this.sortColumn = property;
    if (this.sortInAsc) {
      this.sortInAsc = !this.sortInAsc;
      if (property === 'name') {
        this.orders = _.orderBy(this.orders, [order => order.name.toLowerCase()], 'desc');
      } else if (property === 'orderNumber') {
        this.orders = _.orderBy(this.orders, [order => order.id], 'desc');
      } else if (property === 'type') {
        this.orders = _.orderBy(this.orders, [order => order.metadata.orderType.toLowerCase()], 'desc');
      } else if (property === 'content') {
        this.orders = _.orderBy(this.orders, [order => this.getContentDetails(order.metadata)], 'desc');
      } else if (property === 'assigneeName') {
        this.orders = _.orderBy(this.orders, [order => {
          if (order.assigneeName && order.assigneeName !== 'UNASSIGNED') {
            return order.assigneeName;
          } else if (order.teamName) {
            return order.teamName;
          } else { return ''; }
        }], 'desc');
      } else {
        this.orders = _.orderBy(this.orders, property, 'desc');
      }
    } else {
      this.sortInAsc = true;
      if (property === 'name') {
        this.orders = _.orderBy(this.orders, [order => order.name.toLowerCase()]);
      } else if (property === 'orderNumber') {
        this.orders = _.orderBy(this.orders, [order => order.id]);
      } else if (property === 'type') {
        this.orders = _.orderBy(this.orders, [order => order.metadata.orderType.toLowerCase()]);
      } else if (property === 'content') {
        this.orders = _.orderBy(this.orders, [order => this.getContentDetails(order.metadata)]);
      } else if (property === 'assigneeName') {
        this.orders = _.orderBy(this.orders, [order => {
          if (order.assigneeName && order.assigneeName !== 'UNASSIGNED') {
            return order.assigneeName;
          } else if (order.teamName) {
            return order.teamName;
          } else { return ''; }
        }]);
      } else {
        this.orders = _.orderBy(this.orders, property);
      }
    }
  }

  resetSortObj() {
    delete this.sortInAsc;
    delete this.sortColumn;
  }

  showMoreFilterItems(filterItemName, filterGroupIndex) {
    this.numberOfFiltersToShow[filterGroupIndex] = this.filterObj[filterItemName].length;
    this.setOrdersToLocalStorage();
  }

  selectOrder(order: Order) {
    if (order.currentMilestone['status'] !== 'DRAFT') {
      return '/orders/' + order['id'] + '/order-detail';
    } else if (order.lineItems.length === 0) {
      return '/orders/' + order['id'] + '/draft/endpoint';
    } else {
      return '/orders/' + order['id'] + '/draft/';
    }
  }

  getUserInitial(createdBy) {
    return createdBy.charAt(0);
  }

  jumpToTop() {
    window.scroll({
      top: 0,
      behavior: 'smooth'
    });
  }

  getOrdersObjFromLocalStorage() {
    this.persistedOrdersObj = JSON.parse(this.storageService.getOrdersObjFromLocal());
    if (this.persistedOrdersObj) {
      this.ordersQueryParamsObj = this.persistedOrdersObj['ordersQueryParamsObj'];
      this.numberOfFiltersToShow = this.persistedOrdersObj['numberOfFiltersToShow'];
      this.setPersistedFilters();
      this.setSearchTerm();
    }
  }

  setOrdersToLocalStorage() {
    this.persistedOrdersObj = {
      ordersQueryParamsObj: this.ordersQueryParamsObj,
      selectedFilters: this.selectedFilters,
      numberOfFiltersToShow: this.numberOfFiltersToShow || []
    };
    this.storageService.setOrdersObjToLocal(this.persistedOrdersObj);
  }

  setPersistedFilters() {
    if (this.persistedOrdersObj['selectedFilters']) {
      this.selectedFilters = this.persistedOrdersObj['selectedFilters'];
      if (this.selectedFilters[this.dateFilterIndex] && this.selectedFilters[this.dateFilterIndex].indexOf('custom') !== -1) {
        this.customStartDate = this.ordersQueryParamsObj.startDate;
        this.customStartDate = this.customStartDate;
        this.customEndDate = this.ordersQueryParamsObj.endDate;
        this.customEndDate = this.customEndDate;
        this.showCalendars = true;
      }
    }
  }

  setSearchTerm() {
    if (this.ordersQueryParamsObj['ordersSearchTerm']) {
      this.searchObj.get('searchTerm').setValue(this.ordersQueryParamsObj['ordersSearchTerm']);
    }
  }

  getContentDetails(metadata) {
    let contentMetadata = {};
    contentMetadata['originBrandName'] = metadata['brand'];
    contentMetadata['seriesTitle'] = metadata['series'];
    contentMetadata['seasonTitle'] = metadata['season'];
    contentMetadata['episodeNumber'] = metadata['episode'];
    contentMetadata['title'] = metadata['episodeTitle'];
    contentMetadata['movieAndSpecial'] = metadata['movieAndSpecial'];
    return this.utilityService.getHeaderForContentType(contentMetadata, metadata['contentType']);
  }



  initialize() {
    this.getOrdersObjFromLocalStorage();
    let orderPageTitle;
    switch (this.orderType) {
      case 'my-orders':
        this.ordersQueryParamsObj.ordersType = 'ownedBy=' + this.userService.getUserLoginInfo().email;
        orderPageTitle = 'My Orders';
        break;
      case 'my-drafts':
      this.ordersQueryParamsObj.ordersType = 'ownedBy=' + this.userService.getUserLoginInfo().email + '&statuses=DRAFT';
        orderPageTitle = 'My Drafts';
        break;
      case 'my-teams-orders':
      if (this.teamInfo && this.teamInfo[0]) {
        this.ordersQueryParamsObj.ordersType = 'teams=' + this.teamInfo[0].id;
        orderPageTitle = 'My Team\'s Orders';
      }
        break;
      case 'all-orders':
        this.ordersQueryParamsObj.ordersType = '';
        orderPageTitle = 'All Orders';
        break;
      case 'watching':
        this.ordersQueryParamsObj.ordersType = '&watcherEmail=' + this.userService.getUserLoginInfo().email;
        orderPageTitle = 'Watchers';
        break;
    }
    this.ordersService.setOrdersPageTitle(orderPageTitle + ' - Viacom Bridge');
    this.getFilters();
    this.getOrders();
  }

  getDisplayTeamFilter(filterType, orderType) {
    let filterStatus = true;
    if (filterType === 'team') {
      if(orderType === 'my-drafts' || orderType === 'my-orders') {
        filterStatus = false;
      }
    } else if (filterType === 'statuses' && orderType === 'my-drafts') {
      filterStatus = false;
    }
    return filterStatus;
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
