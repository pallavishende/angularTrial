import { Injectable } from '@angular/core';
import { OrderStore } from '../../models/order-store';

import * as _ from 'lodash';
import { UtilityService } from '../../services/utility.service';

@Injectable()
export class OrderDetailsApprovalService {
  order;

  constructor(private orderStore: OrderStore, private utilityService: UtilityService) { }

  get() {
    return this.orderStore.orderStream;
  }

  getOrderStore() {
    return this.orderStore;
  }

}
