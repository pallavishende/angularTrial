/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';

import { OrderDetailsApprovalService } from './order-details-approval.service';
import { OrderStore } from '../../models/order-store';
import { Order } from '../../models/order';

import { SystemAlertsService } from '../../services/system-alerts.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { UtilityService } from '../../services/utility.service';
import { UserService } from '../../services/user.service';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';

import { HttpClient } from '@angular/common/http';

xdescribe('OrderDetailsApprovalService', () => {
  let service, orderStore, mockBackend;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        OrderDetailsApprovalService,
        SystemAlertsService,
        ConfigService,
        EndpointProfileService,
        OrderStore,
        UserService,
        UtilityService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: HttpClient,
          useFactory: (http: Http) => http,
          deps: [Http],
        },
        EnvironmentService,
        ConfigurationManagerService
      ]
    });
  });

  beforeEach(inject([OrderDetailsApprovalService, OrderStore, MockBackend], (s, o, m) => {
    service = s;
    mockBackend = m;
    orderStore = o;
  }));

  it('should create an instance of the service', ()=> {
    expect(service).toBeTruthy();
  });

  it('#get should return a reference to the order stream', () => {
    let order: BehaviorSubject<Order> = new BehaviorSubject(new Order({}));
    let orderStream = order.asObservable();
    expect(service.get()).toEqual(orderStream);
  });

  it('#getOrderStore should return a reference to the order store', () => {
    expect(service.getOrderStore()).toEqual(orderStore);
  });

});
