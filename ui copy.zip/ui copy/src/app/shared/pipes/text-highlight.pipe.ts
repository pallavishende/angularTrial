import { Pipe, PipeTransform } from '@angular/core';
// this pipe is for bolding matched query in assign users
// for consistancy with backend api, only match start of first or last name
@Pipe({
  name: 'textHighlight'
})
export class TextHighlightPipe implements PipeTransform {
  transform(content: string, query: string, matchGlobal: boolean): string {
    const pattern = '^' + query + '|\\s' + query;
    const regex = new RegExp(pattern, 'i');
    const globalRegex = new RegExp(query, 'i');
    if (matchGlobal) {
      return query ? content.replace(globalRegex, (match) => `<b>${match}</b>`) : content;
    } else {
      return query ? content.replace(regex, (match) => `<b>${match}</b>`) : content;
    }
  }
}
