import { TextHighlightPipe } from './text-highlight.pipe';

describe('TextHighlightPipe', () => {
  it('create an instance', () => {
    const pipe = new TextHighlightPipe();
    expect(pipe).toBeTruthy();
  });
});
