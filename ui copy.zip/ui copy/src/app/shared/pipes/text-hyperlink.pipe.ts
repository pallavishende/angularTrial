import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'textHyperLink'
})
export class TextHyperLinkPipe implements PipeTransform {
  transform(content: string) {
    let text = content.toString();
    if(text.match( /(href)|(src)/i )) {
      return text; // text already has a hyper link in it
    }
    let exp = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
    let text1 = text.replace(exp, "<a target='_blank' href='$1'>$1</a>");
    let exp2 = /(^|[^\/])(www\.[\S]+(\b|$))/gim;
    let emailPattern = /[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}/;
    var matched_str = text1.match(emailPattern);
    //console.log(text2.replace(emailPattern, `<a href='mailto:"${matched_str}>${matched_str}</a>`));
    return text1.replace(exp2, '$1<a target="_blank" href="http://$2">$2</a>');
  }
}
