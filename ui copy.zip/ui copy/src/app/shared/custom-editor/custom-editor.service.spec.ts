import { TestBed, inject } from '@angular/core/testing';

import { CustomEditorService } from './custom-editor.service';

describe('CustomEditorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CustomEditorService]
    });
  });

  it('should be created', inject([CustomEditorService], (service: CustomEditorService) => {
    expect(service).toBeTruthy();
  }));
});
