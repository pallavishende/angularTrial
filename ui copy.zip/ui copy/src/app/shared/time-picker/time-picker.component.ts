import { Component, OnChanges, Input, Output, EventEmitter, ElementRef, ViewChild} from '@angular/core';

@Component({
  selector: 'app-time-picker',
  templateUrl: './time-picker.component.html',
  styleUrls: ['./time-picker.component.scss']
})
export class TimePickerComponent implements OnChanges {

  @ViewChild('inputHour') inputHour: ElementRef;
  @ViewChild('inputMinute') inputMinute: ElementRef;
  @ViewChild('inputPeriod') inputPeriod: ElementRef;

  @Input() storedTime: string;
  @Output() onContentChange = new EventEmitter<any>();

  isValid = true;
  hour: string;
  minute: string;
  period: string;
  focusType = 'unfocused';
  focusedInput = '';
  // holding a key and let go of other key that was pressed later will cause keyup order change
  // this keeps track of how many keys are not released
  KeysHolding = 0;

  constructor(
    private elementRef: ElementRef
  ) {}

  outputTime() {
    this.storedTime = this.hour + ':' + this.minute + ' ' + this.period;
    let isValidOutput = false;

    const h = Number(this.hour);
    const m = Number(this.minute);
    if (h > 0 && h <= 12) {
      if (m >= 0 && m < 60 && this.minute.length === 2) {
        if (this.period === 'AM' || this.period === 'PM') {
          isValidOutput = true;
        }
      }
    }

    const payload = {
      time: this.storedTime,
      isValid: isValidOutput
    };
    return payload;
  }

  // this validation is for visual notification, unfinished input in considered valid
  validate() {
    const h = Number(this.hour);
    const m = Number(this.minute);
    if ((h > 0 && h <= 12) || this.hour === '0') {
      if ((m >= 0 && m < 60 && this.minute.length === 2) || this.minute === ''
      || (m >= 0 && m < 6 && this.minute.length === 1 && this.focusedInput === 'minute')) {
        if (this.period === 'AM' || this.period === 'PM') {
          this.isValid = true;
          return;
        }
      }
    }
    this.isValid = false;
  }

  handleBorderStyle() {
    if (!this.isValid) {
      this.focusType = 'time-picker-error';
    } else {
      if (!this.focusedInput) {
        this.focusType = 'time-picker-unfocused';
      } else {
        this.focusType = 'time-picker-focused';
      }
    }
  }

  onKeyPress(e) {
    this.KeysHolding ++;
    if (e.key === 'Enter') {
      e.preventDefault();
    }
  }

  onKeyUp(e) {
    this.KeysHolding --;
    if (e.key === 'Tab' || this.KeysHolding > 0) {
      this.KeysHolding = 0;
      return;
    }
    this.KeysHolding = 0;
    // hour input >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (e.target.name === 'hour') {
      this.hour = e.target.value.replace(/\D/g, '');
      const h = Number(this.hour);
      if (h > 2 && h < 10) {
        if (this.hour.length === 2) {
          this.hour = this.hour.replace(/^0/, '');
          this.period = 'AM';
        }
        this.inputMinute.nativeElement.focus();
      } else if (h > 12 && h < 24) {
        this.hour = String(h - 12);
        this.period = 'PM';
        this.inputMinute.nativeElement.focus();
      } else if (e.target.value === '00' || e.target.value === '24') {
        this.hour = '12';
        this.period = 'AM';
        this.inputMinute.nativeElement.focus();
      } else if (e.target.value.length === 2) {
        if (this.hour === '01' || this.hour === '02') {
          this.period = 'AM';
        }
        this.hour = this.hour.replace(/^0/, '');
        this.inputMinute.nativeElement.focus();
      }
      if (e.key === 'Enter' || e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        this.inputMinute.nativeElement.focus();
      } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        this.inputHour.nativeElement.focus();
      }
    }

    // minute input >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (e.target.name === 'minute') {
      this.minute = e.target.value.replace(/\D/g, '');

      if (e.target.value.length === 2) {
        this.inputPeriod.nativeElement.focus();
      }
      if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        this.inputHour.nativeElement.focus();
      } else if (e.key === 'Enter' || e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        this.inputPeriod.nativeElement.focus();
      }
    }

    // period input >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (e.target.name === 'period') {
      this.period = e.target.value.replace(/[^apmAPM]/g, '').toUpperCase();
      if (e.key !== 'Backspace') {
        if (e.target.value === 'a' || e.target.value === 'A') {
          this.period = 'AM';
        } else if (e.target.value === 'p' || e.target.value === 'P') {
          this.period = 'PM';
        }
      }
      if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        this.period = this.period === 'AM' ? 'PM' : 'AM';
        this.inputPeriod.nativeElement.focus();
      }else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        this.inputMinute.nativeElement.focus();
      } else if (e.key === 'Enter' || e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        this.inputPeriod.nativeElement.focus();
      }
    }

    this.validate();
    this.handleBorderStyle();
    this.onContentChange.emit(this.outputTime());
  }

  onFocus(e) {
    this.focusedInput = e.target.name;
    this.handleBorderStyle();
    e.target.select();
  }

  onBlur(e) {
    if (this.focusedInput === e.target.name) {
      this.focusedInput = '';
    }
    // below are some number tweaks that happens after blur to avoid error notice while typing
    if (e.target.name === 'hour') {
      if (this.hour === '0') {
        this.hour = '12';
        this.period = 'AM';
      }
    }
    if (e.target.name === 'minute') {
      if (this.minute.length !== 2) {
        if (this.minute === '') {
          this.minute = '00';
        } else if (Number(this.minute) < 6) {
          this.minute = this.minute + '0';
        } else {
          this.isValid = false;
        }
      }
    }
    this.validate();
    this.handleBorderStyle();
    this.onContentChange.emit(this.outputTime());
  }

  ngOnChanges() {
    const parserColon = this.storedTime.indexOf(':');
    const parserSpace = this.storedTime.indexOf(' ');
    this.hour = this.storedTime.substr(0, parserColon);
    this.minute = this.storedTime.substr(parserColon + 1, parserSpace - parserColon - 1);
    this.period = this.storedTime.substr(parserSpace + 1);
    this.validate();
    this.handleBorderStyle();
  }

}
