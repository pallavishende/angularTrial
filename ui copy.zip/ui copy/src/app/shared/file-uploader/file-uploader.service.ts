import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import { ConfigService } from '../../services/config.service';

@Injectable()
export class FileUploaderService {

  constructor(private httpClient: HttpClient, private configService: ConfigService) { }

  downloadAttachedFile(fileId) {
    return this.httpClient.get(`${this.configService.fileHandlerUrl}/${fileId}`, {responseType: 'blob'}).map(response => <Blob>response);
  }

  downloadAllAttachedFiles(fileIdArray: Array<string>) {
    return this.httpClient.get(`${this.configService.fileHandlerUrl}?ids=${fileIdArray.join(',')}`,
    {responseType: 'blob'}).map(response => <Blob>response);
  }

  deleteAttachedFile(fileId) {
    return this.httpClient.delete(`${this.configService.fileHandlerUrl}-metadata/${fileId}`, { responseType: 'text' }).retryWhen(error => {
      return error.flatMap((error) => {
        return Observable.of(error.status).delay(200);
      }).take(5).concat(Observable.throw({error}));
    });
  }

}
