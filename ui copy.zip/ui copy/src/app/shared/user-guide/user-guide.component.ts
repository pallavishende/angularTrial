import { Component, OnInit, SecurityContext } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-user-guide',
  templateUrl: './user-guide.component.html',
  styleUrls: ['./user-guide.component.scss']
})
export class UserGuideComponent implements OnInit {

  public pdfEmbedHtml: SafeHtml;

  constructor(private sanitizer: DomSanitizer, private title: Title) { }

  ngOnInit() {
    const pdfUrl = '../../../assets/viacom-bridge-user-guide.pdf';
    this.setEmbeddedPdf(pdfUrl);
    this.setPageTitle();
  }

  public setEmbeddedPdf(pdfurl: string) {
    const pdfEmbed = '<object data="' + pdfurl + '" type="application/pdf" width="960px" height="600px" class="embed-responsive-item">' +
      'Object ' + pdfurl + ' failed' +
      '</object>';

    this.pdfEmbedHtml = this.sanitizer.bypassSecurityTrustHtml(pdfEmbed);
  }

  setPageTitle() {
    this.title.setTitle('User Guide - Viacom Bridge');
  }


}
