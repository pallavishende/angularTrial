import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class LoadingMaskService {

  loadingState: boolean;
  loadingAnimator: string;
  disableUserInput = false;
  timeOut0;
  timeOut1;
  timeOut2;
  configObj = {
    'default': {
      'message0': '',
      'message1': 'Still loading…',
      'timeout1': 8000,
      'message2': 'Sorry, this is taking a few more moments. You may want to refresh your browser to try again.',
      'timeout2': 15000 },
    'itemDetails': {
      'message0': 'Loading version details…',
      'message1': 'Still retrieving details, sometimes this takes a moment…',
      'timeout1': 8000 },
    'orders': {
      'message0': 'Loading orders…',
      'message1': 'Still retrieving orders, sometimes this takes a moment…',
      'timeout1': 8000 }
  };

  constructor() {
  }

  enableLoadingMask(type?: string): void {
    if (!type) {
      type = 'default';
    }
    this.timeOut0 = setTimeout(() => {
      this.loadingState = true;
      this.loadingAnimator = this.configObj[type]['message0'];
      this.disableUserInput = true;
    }, 400);

    this.timeOut1 = setTimeout(() => {
      this.loadingAnimator = this.configObj[type]['message1'];
    }, this.configObj[type]['timeout1']);
    if (type === 'default') {
      this.timeOut2 = setTimeout(() => {
        this.loadingAnimator = this.configObj[type]['message2'];
      }, this.configObj[type]['timeout2']);
    }
  }

  disableLoadingMask(): void {
    this.loadingState = false;
    clearTimeout(this.timeOut0);
    clearTimeout(this.timeOut1);
    clearTimeout(this.timeOut2);
    this.loadingAnimator = '';
    this.disableUserInput = false;
  }
}
