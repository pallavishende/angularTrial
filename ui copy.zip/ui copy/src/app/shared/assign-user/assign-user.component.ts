import { Component, OnInit, OnChanges, OnDestroy, Input, Output, EventEmitter, ElementRef, ViewChild } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { UserService } from '../../services/user.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-assign-user',
  templateUrl: './assign-user.component.html',
  styleUrls: ['./assign-user.component.scss'],
  host: {
    '(document:click)': 'handleClick($event)',
  }
})
export class AssignUserComponent implements OnInit, OnChanges, OnDestroy {

  @ViewChild('userInput') userInput: ElementRef;
  userLoginInfo;
  userInputValue;
  users;
  assigneeEmail;
  teamId;
  displayNames = [];
  filteredList = [];
  userNameSubscription;
  query = '';
  showNoSuggestion = false;

  @Input() assignedUser: any; // display name
  @Input() teamName: string;
  @Input() parentId: any;
  @Input() usersOnly: boolean; // not including teams
  @Input() isReadOnly: any;
  @Input() parentComponent: string;
  @Input() autoFocus: boolean;
  @Input() isAssignEventSuccessful: Observable<boolean>;

  @Output() selectNameNotify: EventEmitter<any> = new EventEmitter<any>();
  @Output() removeNameNotify: EventEmitter<any> = new EventEmitter<any>();

  constructor(
    private userService: UserService,
    private elementRef: ElementRef
  ) { }

  ngOnInit() {
    this.focusToInput();
    this.userLoginInfo = this.userService.getUserLoginInfo();
    if (typeof this.isAssignEventSuccessful !== 'undefined') {
      this.isAssignEventSuccessful.subscribe((isSuccessful) => {
      if (!isSuccessful) {
        this.focusToInput();
      }
    });
    }
  }

  focusToInput(): void {
    if (this.autoFocus) {
      this.userInput.nativeElement.focus();
    }
  }

  handleClick(event) {
    let clickedComponent = event.target;
    let inside = false;
    do {
      if (clickedComponent === this.elementRef.nativeElement) {
        inside = true;
      }
    clickedComponent = clickedComponent.parentNode;
    } while (clickedComponent);
    if (!inside) {
      this.filteredList = [];
    }
  }

  // auto-complete methods
  filter(e) {
    e.stopImmediatePropagation();
    // if old search doesn't have any suggestion, don't update no-suggestion holder
    if (this.filteredList.length > 0) {
      this.showNoSuggestion = false;
    }
    this.displayNames = [];
    this.filteredList = [];
    this.query = e.target.value;
    if (e.target.value) {
      if (this.userNameSubscription) {
        this.userNameSubscription.unsubscribe();
      }
      if (this.usersOnly) {
        this.userNameSubscription = this.userService.getUsers(e.target.value, 5).subscribe(
          data => {
            if (data.content) {
              this.users = data.content;
            }
            this.displayNames = [];
            _.forEach(this.users, (item) => {
              let name = item.displayName;
              let email = item.login;
              this.displayNames.push({'name': name, 'email': email});
            });
            this.filteredList = _.orderBy(this.displayNames, [user => user.name.toLowerCase()], ['asc']);
            this.showNoSuggestion = true;
          },
          error => {
            console.log('get users error');
          }
        );
      } else {
        this.userNameSubscription = this.userService.getUsersAndTeams(e.target.value, 5).subscribe(
          data => {
            this.users = data;
            if (this.users) {
              _.forEach(this.users, (item) => {
                let name = item.name;
                let email = item.id;
                this.displayNames.push({'name': name, 'email': email});
              });
              this.filteredList = _.orderBy(this.displayNames, [user => user.name.toLowerCase()], ['asc']);
            }
            this.showNoSuggestion = true;
          },
          error => {
            console.log('get users error');
          }
        );
      }
    }
  }

  clickEvent(e) {
    this.showNoSuggestion = false;
  }

  onBlur(e) {
    e.preventDefault();
    e.stopPropagation();
    this.showNoSuggestion = false;
    this.ngOnChanges();
  }

  onFocus(e) {
    e.target.select();
  }

  isTeamId(email: string) {
    return !_.includes(email, '@');
  }

  getIcon(email, name?) {
    if (this.isTeamId(email) && name) {
      return name.charAt(0).toUpperCase();
    } else {
      return email.charAt(0).toUpperCase();
    }
  }

  selectName(filteredName, e) {
    e.preventDefault();
    e.stopPropagation();
    let assigneeName;
    let teamName;
    if (this.isTeamId(filteredName.email)) {
      this.assigneeEmail = null;
      assigneeName = null;
      this.teamId = filteredName.email;
      teamName = filteredName.name;
    } else {
      this.assigneeEmail = filteredName.email;
      assigneeName = filteredName.name;
      this.teamId = null;
      teamName = null;
    }
    const payload = {
      id: this.parentId,
      assigneeEmail: this.assigneeEmail,
      assigneeName: assigneeName,
      teamId: this.teamId,
      teamName: teamName,
      assignedByEmail: this.userLoginInfo.email
    };
    this.selectNameNotify.emit(payload);
    this.filteredList = [];
    this.query = '';
  }

  clearEnteredName (e) {
    e.preventDefault();
    e.stopPropagation();
    this.filteredList = [];
    if (this.query) {
      return;
    } else {
      const payload = {
        id: this.parentId
      };
      this.removeNameNotify.emit(payload);
    }
  }

  ngOnChanges() {
    if (this.assignedUser === 'UNASSIGNED') {
      if (this.teamName) {
        this.userInputValue = this.teamName;
      } else {
        this.userInputValue = '';
      }
    } else {
      this.userInputValue = this.assignedUser;
    }
  }

  ngOnDestroy() {
    if (this.userNameSubscription) {
      this.userNameSubscription.unsubscribe();
    }
  }
}
