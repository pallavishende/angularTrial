import { Component, OnInit, OnChanges, ViewChild, ElementRef, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import * as Pikaday from 'pikaday';
import * as moment from 'moment/moment';

@Component({
  selector: 'app-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['../../../../node_modules/pikaday/scss/pikaday.scss', './date-picker.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DatePickerComponent implements OnInit, OnChanges {
  @ViewChild('datepicker') datepicker: ElementRef;
  @Input() storedDate: string;
  @Input() min: string;
  @Output() onContentChange = new EventEmitter<any>();
  pikaday: Pikaday;
  isValid = true;
  filled = false;

  constructor(
    private elementRef: ElementRef
  ) { }

  ngOnInit() {
    this.pikaday = new Pikaday({
      field: this.datepicker.nativeElement,
      format: 'MM/DD/YYYY',
      minDate: (this.min ? moment(this.min).toDate() : undefined),
    });
    if (this.storedDate) {
      this.pikaday.setDate(moment(this.toISOformat(this.storedDate), 'YYYY-MM-DD').toDate());
    }
  }

  validate(date: string) {
    // "filled" property for displaying red border when content exists and is wrong
    this.filled = false;
    if (this.datepicker.nativeElement.value) {
      this.filled = true;
    } else {
      this.filled = false;
    }
    if (moment(this.toISOformat(date), 'YYYY-MM-DD').isValid()) {
      this.isValid = true;
      return true;
    } else {
      this.isValid = false;
      return false;
    }
  }

  toISOformat(date: string) {
    if (date.indexOf('/') !== -1) {
      return date.slice(6, 10) + '-' + date.slice(0, 2) + '-' + date.slice(3, 5);
    } else {
      return date;
    }
  }

  outputDate() {
    if (this.validate(this.datepicker.nativeElement.value)) {
      this.storedDate = this.datepicker.nativeElement.value;
    }
    const payload = {
      date: this.storedDate,
      isValid: this.isValid,
      isFilled: this.filled
    };
    if (!this.isValid) {
      payload.date = '';
    }
    return payload;
  }

  emitDate() {
    this.onContentChange.emit(this.outputDate());
  }

  onKeyUp() {
    this.validate(this.datepicker.nativeElement.value);
  }

  ngOnChanges() {
    if (this.pikaday) {
      if (this.storedDate === 'reset') {
        this.pikaday.setDate(null);
      } else if (this.storedDate) {
        this.pikaday.setDate(moment(this.toISOformat(this.storedDate), 'YYYY-MM-DD').toDate());
      }
      if (this.min) {
        if (this.min === 'reset') {
          this.pikaday.setMinDate(moment().toDate());
        } else {
          this.pikaday.setMinDate(this.min ? moment(this.toISOformat(this.min), 'YYYY-MM-DD').toDate() : undefined);
        }
      }
      this.validate(this.datepicker.nativeElement.value);
    }
  }
}
