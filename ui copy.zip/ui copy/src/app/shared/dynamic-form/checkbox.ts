import { DynamicFormBase } from './dynamic-form-base';

export class Checkbox extends DynamicFormBase<string> {
  controlType = 'checkbox';
  options: {key: string, value: string}[] = [];
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.options = options['options'] || [];
    this.type = options['type'] || '';
  }
}