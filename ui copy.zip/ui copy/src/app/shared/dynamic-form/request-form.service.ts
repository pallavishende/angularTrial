import { Injectable }       from '@angular/core';;
import { DynamicFormBase } from './dynamic-form-base';
import { Textbox } from './textbox';
import { Textarea } from './Textarea';
import { dropdown } from './dropdown';
import { Checkbox } from './checkbox';
import { Label } from './Label'
 
@Injectable()
export class RequestformService {

  // TODO: get from a remote source of question metadata
  // TODO: make asynchronous
  getForm(formFields, requesyType, instructions) {
    let instructionsForm: DynamicFormBase<any>[] = [];
    
    formFields[requesyType.id].forEach(field => {
      let formFieldsModify = Object.assign({}, field);
      let fieldValue = instructions.filter(inst => inst.label === field.key && inst.type === requesyType.id);
      if(fieldValue.length > 0) {
        formFieldsModify.value = fieldValue[0].values[0];
        formFieldsModify.hidden = false;
      }
      let newFormField;
      switch (formFieldsModify.type)
      {
        case'dropdown':
          newFormField = new dropdown(formFieldsModify);
          instructionsForm.push(newFormField);
          break;
        case'textbox':
          newFormField = new Textbox(formFieldsModify);
          instructionsForm.push(newFormField);
          break;
        case'textarea':
          newFormField = new Textarea(formFieldsModify);
          instructionsForm.push(newFormField);
          break;
        case'label':
          newFormField = new Label(formFieldsModify);
          instructionsForm.push(newFormField);
          formFieldsModify.options.forEach(val => {
            val.checked = false;
            let fieldValue = instructions.filter(inst => inst.label === val.key && inst.type === requesyType.id);
            if(fieldValue.length > 0) {
              val.checked = fieldValue[0].values[0];
              val.value = val.checked;
            }
            newFormField = new Checkbox(val);
            instructionsForm.push(newFormField);
          })
      }
    });
    return instructionsForm.sort((a, b) => a.order - b.order);
  }
}