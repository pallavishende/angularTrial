import { DynamicFormBase } from './dynamic-form-base';

export class Label extends DynamicFormBase<string> {
  controlType = 'label';
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.type = options['type'] || '';
  }
}