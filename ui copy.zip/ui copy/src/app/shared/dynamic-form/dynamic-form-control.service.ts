import { Injectable }   from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DynamicFormBase } from './dynamic-form-base';

@Injectable()
export class DynamicFormBaseService {

  constructor() { }

  toFormGroup(dyamicForm: DynamicFormBase<any>[] ) {
    let group: any = {};

    dyamicForm.forEach(formControl => {
      group[formControl.key] = formControl.required ? new FormControl(formControl.value || '', Validators.required)
                                              : new FormControl(formControl.value || '');
    });
    return new FormGroup(group);
  }
}