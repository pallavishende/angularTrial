import { Component, Input, Output, EventEmitter, OnInit }  from '@angular/core';
import { FormGroup, FormArray, Validators } from '@angular/forms'
import { DynamicFormBase } from './dynamic-form-base';
import { DynamicFormBaseService } from './dynamic-form-control.service';
import * as _ from 'lodash';
 
@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss'],
  providers: [ DynamicFormBaseService ]
})
export class DynamicFormComponent implements OnInit {
 
  @Input() formControls: DynamicFormBase<any>[] = [];
  @Input() form: FormGroup;
  @Output() onDeleteFormGroup = new EventEmitter<any>();

  payLoad = '';
  formErrors = {
    Request: this.RequestErrors()
  };
  validationMessages = {
    Request: {
    }
  };
 
  constructor() {}
 
  ngOnInit() {
    
  }
 
  onSubmit() {
    this.payLoad = JSON.stringify(this.form.value);
  }

  updateInstructionsForm(event, prameterName, index) {
    let Request = <FormArray>this.form['controls'].Request;
    let x = index;
      let X = <FormGroup>Request.at(index);
      X.value[prameterName] = event;
  }

  updateCheckbox(event, prameterName, index) {
    if(prameterName === 'Custom') {
        let controls = this.formControls[index];
        _.forEach(controls, (ctrl) => {
          if(ctrl.key === 'dimensions') {
            ctrl.hidden = !event;
            if(!event) {
              ctrl.value = '';
              let Request = <FormArray>this.form['controls'].Request;
              let X = <FormGroup>Request.at(index);
              X.controls['dimensions'].setValue('',  {onlySelf: false, emitEvent: true});
            }
          }
        });
      }
  }

  removeFormGroup(requestType) {
    this.onDeleteFormGroup.emit(requestType);
  }

  isValid(key) { return this.form.controls[key].valid; }

  RequestErrors() {
    return [{

    }]
  }
}