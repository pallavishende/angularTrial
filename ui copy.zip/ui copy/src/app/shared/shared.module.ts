import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { FileUploadModule } from 'ng2-file-upload';
import { FilePreviewComponent } from './file-uploader/file-preview/file-preview.component';
import { ModalModule } from 'ng2-modal';

import { SiteHeaderComponent } from './site-header/site-header.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { TasksComponent } from './tasks/tasks.component';
import { SharedBaseComponent } from './shared-base/shared-base.component';
import { SharedRoutesModule } from './shared-routes.module';
import { HtmlFormatDirective } from '../directives/html-format.directive';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDialogModule } from '@angular/material/dialog';
import { MatTabsModule } from '@angular/material/tabs';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { StatusDirective } from '../directives/status.directive';
import { StickyDivDirective } from '../directives/sticky-div.directive';
import { AssignUserComponent } from './assign-user/assign-user.component';
import { TextHighlightPipe } from './pipes/text-highlight.pipe';
import { TextHyperLinkPipe } from './pipes/text-hyperlink.pipe';

import { ActivitiesService } from '../activities/activities.service';
import { CustomEditorComponent } from './custom-editor/custom-editor.component';
import { TimePickerComponent } from './time-picker/time-picker.component';
import { UserGuideComponent } from './user-guide/user-guide.component';
import { DatePickerComponent } from './date-picker/date-picker.component';
import { FileUploaderComponent } from './file-uploader/file-uploader.component';
import { FileUploaderService } from './file-uploader/file-uploader.service';
import { AwsS3ConfigService } from '../services/aws-s3-config.service';
import { InlineEditorComponent } from './inline-editor/inline-editor.component';
import { CreateOrderComponent } from './create-order/create-order.component';
import { WatchersComponent } from './watchers/watchers.component';
import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    SharedRoutesModule,
    ReactiveFormsModule,
    FormsModule,
    FileUploadModule,
    ModalModule,
    MatSidenavModule,
    MatExpansionModule,
    MatDialogModule,
    MatTabsModule,
    MatChipsModule,
    MatFormFieldModule,
    MatIconModule
  ],
  declarations: [
    SiteHeaderComponent,
    NotificationsComponent,
    TasksComponent,
    SharedBaseComponent,
    HtmlFormatDirective,
    StatusDirective,
    StickyDivDirective,
    TextHighlightPipe,
    TextHyperLinkPipe,
    AssignUserComponent,
    TimePickerComponent,
    DatePickerComponent,
    CustomEditorComponent,
    FileUploaderComponent,
    UserGuideComponent,
    FilePreviewComponent,
    InlineEditorComponent,
    CreateOrderComponent,
    WatchersComponent,
    DynamicFormComponent
  ],
  exports: [
    MatSidenavModule,
    MatExpansionModule,
    MatDialogModule,
    MatTabsModule,
    MatChipsModule,
    MatFormFieldModule,
    MatIconModule,
    SiteHeaderComponent,
    HtmlFormatDirective,
    StatusDirective,
    StickyDivDirective,
    TextHighlightPipe,
    TextHyperLinkPipe,
    AssignUserComponent,
    TimePickerComponent,
    DatePickerComponent,
    FileUploaderComponent,
    CustomEditorComponent,
    InlineEditorComponent,
    CreateOrderComponent,
    WatchersComponent,
    DynamicFormComponent
  ],
  providers: [ ActivitiesService, AwsS3ConfigService, FileUploaderService ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SharedModule { }
