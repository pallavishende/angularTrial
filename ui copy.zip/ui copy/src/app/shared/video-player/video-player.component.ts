import { Component, ElementRef, Input, EventEmitter, ViewChild, OnChanges, Output } from '@angular/core';
import { SystemAlertsService } from '../../services/system-alerts.service';
import * as Hls from 'hls.js';

@Component({
  selector: 'app-video-player',
  templateUrl: './video-player.component.html',
  styleUrls: ['./video-player.component.scss']
})
export class VideoPlayerComponent implements OnChanges {

  @ViewChild('videoPlayer') videoPlayer: ElementRef;
  @ViewChild('volumeSlider') volumeSlider;
  @ViewChild('seeker') seeker;
  @Input() selectedClip: any;
  @Output() nextClip = new EventEmitter<string>();

  video: HTMLVideoElement;
  hlsObj: Hls;
  clipLoaded = false;
  isPlaying = false;
  muted = false;
  currentTime;
  selectedClipSource: string;
  clipDuration: string;

  constructor(
    private alerts: SystemAlertsService
  ) { }

  loadVideoSource(): void {
    if (typeof this.selectedClip !== 'undefined' && this.selectedClip.clipDetails.StreamingUrl) {
      if (!this.containsClipTimeOffset(this.selectedClip.clipDetails.StreamingUrl)) {
        this.setClipTimeOffset(this.selectedClip.clipDetails.StreamingUrl);
      }
      this.hlsObj.loadSource(this.selectedClip.clipDetails.StreamingUrl);
      this.clipLoaded = true;
      this.isPlaying = true;
      this.video.play();
      this.clipDuration = this.selectedClip.duration;
    } else {
      this.alerts.addErrorAlerts('The video you\'re trying to play can\'t be found. If this problem continues, contact support.');
      this.isPlaying = false;
      this.clipLoaded = false;
    }
  }

  loadVideo(): void {
    this.video = this.videoPlayer.nativeElement;
    this.hlsObj = new Hls();
    this.hlsObj.attachMedia(this.video);
    this.loadVideoSource();
    this.currentTime = this.getTimeInfo(this.video.currentTime);
  }

  getTimeInfo(seconds: number): string {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor(seconds / 60);
    seconds = seconds % 3600;
    seconds = Math.floor(seconds % 60);
    const secs = seconds.toString().length < 2 ? `0${seconds}` : seconds;
    const mins = minutes.toString().length < 2 ? `0${minutes}` : minutes;
    const hrs = hours.toString().length < 2 ? `0${hours}` : hours;
    return `${hrs}:${mins}:${secs}`;
  }

  updateCurrentTime() {
   this.currentTime = this.getTimeInfo(this.video.currentTime);
  }

  playVideo() {
    this.video.play();
  }

  pauseVideo() {
    this.video.pause();
  }

  getClip(clip: string) {
    this.nextClip.emit(clip);
  }

  toggleMute() {
    this.muted = !this.muted;
  }

  changeVolume() {
    let volume;
    volume = (this.volumeSlider.nativeElement.value) / 10;
    if (volume === 0) {
      this.muted = true;
    } else {
      this.muted = false;
    }
    (<HTMLVideoElement>this.video).volume = volume;
  }

  enterFullscreen() {
    this.video.webkitRequestFullScreen();
  }

  seek($event) {
    if (this.clipLoaded) {
      let goto;
      goto = this.video.duration * ($event.target.value / 100);
      this.video.currentTime = goto;
    }
  }

  updateSeek() {
    if (this.isPlaying) {
      let seekElement, newTime;
      seekElement = this.seeker.nativeElement;
      newTime = this.video.currentTime * (100 / this.video.duration);
      seekElement.value = newTime;
    }
  }

  resetVideo() {
    this.isPlaying = false;
    this.seeker.nativeElement.value = 0;
    this.currentTime = '0:00:00';
  }

  containsClipTimeOffset(streamingUrl: string): boolean {
    if (streamingUrl.includes('start') && streamingUrl.includes('end')) {
      return true;
    }
    return false;
  }

  getParameterByName(name, url) {
    name = name.replace(/[\[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) {
      return null;
    }
    if (!results[2]) {
      return '';
    }
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  }

  setClipTimeOffset(streamingUrl: string): void {
    const startTime = this.getParameterByName('start', streamingUrl);
    const endTime = this.getParameterByName('end', streamingUrl);
    const clipIn = Math.round(parseFloat(this.getParameterByName('clipin', streamingUrl)));
    const clipOut = Math.round(parseFloat(this.getParameterByName('clipout', streamingUrl)));
    if (startTime) {
      streamingUrl = streamingUrl.replace('start=' + startTime, 'start=' + clipIn);
    } else {
      streamingUrl = streamingUrl + '&start=' + clipIn;
    }
    if (endTime) {
      streamingUrl.replace('end=' + endTime, 'end=' + clipOut);
    } else {
      streamingUrl = streamingUrl + '&end=' + clipOut;
    }
    this.selectedClip.streamingUrl = streamingUrl;
  }

  ngOnChanges() {
    if (typeof this.selectedClip !== 'undefined') {
      this.loadVideo();
    } else {
      if (this.video) {
        this.resetVideo();
        this.clipLoaded = false;
        this.hlsObj.detachMedia();
      }
    }
  }

}
