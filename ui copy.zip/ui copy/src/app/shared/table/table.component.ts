import {
  Component, OnChanges, OnDestroy, Input, Output, EventEmitter,
  ElementRef, ViewChild, ViewChildren, QueryList
} from '@angular/core';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { UserService } from '../../services/user.service';
import { ActivitiesService } from '../../activities/activities.service';
import { NavigationService } from '../../services/navigation.service';
import * as _ from 'lodash';
import * as moment from 'moment/moment';
import { UtilityService } from '../../services/utility.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
  host: {
    '(document:click)': 'handleClick($event)',
  },
})
export class TableComponent implements OnChanges, OnDestroy {

  sortAsc = true;
  headerClicked: any;
  userList: Array<any> = [];
  filteredList: Array<any> = [];
  query = '';
  showNoSuggestion = false;
  selectedInput;
  myElement;
  selectedItem;
  showDropDown = false;
  hasTempUserIcon = false;
  tempInitial = '';
  userNameSubscription: any;

  @ViewChildren('assignCheckBox') assignCheckBox: QueryList<ElementRef>;
  @ViewChild('selectAllCheckBox') selectAllCheckBox: ElementRef;

  @Input() users: any;
  @Input() data: any;
  @Input() dataProps: any;
  @Input() configObj: {};
  @Input() htmlString: any;
  @Input() displayNames: any;
  @Input() assignedActivities: any;
  @Input() bulkAssignIdxArr: any;
  @Input() uncheckAssignBoxes: any;
  @Input() uncheckSelectAllBox: any;
  @Input() loadingUsers: Array<number> = [];

  @Output() checkChangeNotify = new EventEmitter<any>();
  @Output() selectNameNotify = new EventEmitter<any>();
  @Output() removeNameNotify = new EventEmitter<any>();
  @Output() selectContentNotify = new EventEmitter<any>();
  @Output() clickSortNotify = new EventEmitter<any>();
  @Output() loadingUsersNotify = new EventEmitter<any>();

  constructor(
    private userService: UserService,
    private utilityService: UtilityService,
    private activitiesService: ActivitiesService,
    private _sanitizer: DomSanitizer,
    private _elementRef: ElementRef,
    private router: Router,
    private navigationService: NavigationService
  ) {
    this.myElement = _elementRef;
  }

  checkChange(e, item, i) {
    let payload = {
      event: e,
      item: item,
      index: i
    };
    this.checkChangeNotify.emit(payload);
  }

  checkChangeAll(e) {
    if (this.assignCheckBox) {
      this.assignCheckBox.forEach((element) => {
        element.nativeElement.checked = e.target.checked;
      });
    }
    this.checkChange(e, this.data, 'all');
  }

  selectContent(e) {
    let payload = {
      event: e
    };
    this.selectContentNotify.emit(payload);
  }

  clickSort(e, headerIndex) {
    this.headerClicked = headerIndex;
    this.sortAsc = !this.sortAsc;
    let sortByProp = (headerIndex > 0) ? this.configObj['reorderedObjProps'][headerIndex - 1] : 'assignedUserName';
    let sortObj = {
      sortByProp: sortByProp,
      headerIndex: headerIndex,
      sortAsc: this.sortAsc
    };
    this.clickSortNotify.emit(sortObj);
  }

  goToActivityDetail(id, activityId) {
    return '/tasks/' + id + '/' + this.utilityService.getActivityRouteByTypeId(activityId);
  }

  setPreviousUrl(): void {
    let activityListUrl;
    activityListUrl = this.router.url;
    this.navigationService.setActivityDetailsPreviousUrl(activityListUrl);
  }

  getActivityStatus(item, prop) {
    if (item.startWorkStatusValue && item[prop] === 'TO_DO') {
      return 'IN_PROGRESS';
    } else {
      return this.renderDataContent(item[prop], 4);
    }
  }

  renderDataContent(content, i) {
    if (!content) {
      return ' — ';
    }
    if (i === 0) {
      return this.utilityService.getActivityNameByTypeId(content);
    }
    if (i === _.indexOf(this.configObj['reorderedObjProps'], 'dueDate')) {
      return moment(content).format('MM/DD/YYYY' + ', ' + 'hh:mm a');
    }
    return content;
  }

  getContentDetails(metadata) {
    return this.activitiesService.getContentDetails(metadata);
  }

  renderContentAndSanitize(content) {
    return this._sanitizer.bypassSecurityTrustHtml(content);
  }

  getUserInitial(assignee) {
    if (assignee) {
      return assignee.charAt(0);
    }
  }

  handleClick(event) {
    let clickedComponent = event.target;
    let inside = false;
    do {
      if (clickedComponent === this._elementRef.nativeElement) {
        inside = true;
      }
      clickedComponent = clickedComponent.parentNode;
    } while (clickedComponent);
    if (!inside) {
      this.filteredList = [];
    }
  }

  filter(e, i) {
    e.stopImmediatePropagation();
    // if old search doesn't have any suggestion, don't update no-suggestion holder
    if (this.filteredList.length > 0) {
      this.showNoSuggestion = false;
    }
    this.query = e.target.value;
    if (!e.target.value) {
      this.displayNames = [];
      this.filteredList = this.displayNames;
    } else {
      if (this.userNameSubscription) {
        this.userNameSubscription.unsubscribe();
      }
      this.userNameSubscription = this.userService.getUsersAndTeams(e.target.value, 5)
        .subscribe(
        data => {
          if (data) {
            this.users = data;
          }
          this.displayNames = [];
          if (this.users) {
            _.forEach(this.users, (item) => {
              const name = item.name;
              const email = item.id;
              this.displayNames.push({ 'name': name, 'email': email });
            });
            this.filteredList = _.orderBy(this.displayNames, [user => user['name'].toLowerCase()], ['asc']);
          }
          this.showNoSuggestion = true;
        },
        error => {
          console.log('get users error');
        }
        );
    }
    this.selectedInput = i;
  }

  isTeamId(email: string) {
    return !_.includes(email, '@');
  }

  getIcon(email, name?) {
    if (this.isTeamId(email) && name) {
      return name.charAt(0).toUpperCase();
    } else {
      return email.charAt(0).toUpperCase();
    }
  }

  selectName(item, filteredName, e, i) {
    e.preventDefault();
    e.stopPropagation();
    let assigneeEmail = null;
    let teamId = null;
    if (this.isTeamId(filteredName.email)) {
      teamId = filteredName.email;
    } else {
      assigneeEmail = filteredName.email;
    }

    const payload = {
      id: item.id,
      assigneeEmail: assigneeEmail,
      assignedByEmail: this.userService.getUserLoginInfo().email,
      teamId: teamId,
      item: item,
      index: i
    };

    this.selectedInput = i;
    this.filteredList = [];
    this.query = '';
    this.selectNameNotify.emit(payload);
    this.loadingUsersNotify.emit(i);
  }

  onBlur(e, item) {
    e.preventDefault();
    e.stopPropagation();
    this.showNoSuggestion = false;
    if (!item.assignedUserEmail || item.assignedUserEmail === 'UNASSIGNED') {
      if (item.teamName) {
        e.target.value = item.teamName;
      } else {
        e.target.value = '';
      }
    } else {
      e.target.value = item.assignedUserName;
    }
  }

  onFocus(e) {
    this.selectContent(e);
    this.filteredList = [];
  }

  clickEvent(e, i) {
    e.stopPropagation();
    this.showNoSuggestion = false;
  }

  uncheckClips() {
    if (this.assignCheckBox) {
      this.assignCheckBox.forEach((element) => {
        element.nativeElement.checked = false;
      });
    }
  }

  uncheckSelectAll() {
    if (this.selectAllCheckBox) {
      this.selectAllCheckBox.nativeElement.checked = false;
    }
  }

  ngOnChanges() {
    if (this.uncheckAssignBoxes) {
      this.uncheckClips();
    }
    if (this.uncheckSelectAllBox) {
      this.uncheckSelectAll();
    }
  }

  ngOnDestroy() {
    if (this.userNameSubscription) {
      this.userNameSubscription.unsubscribe();
    }
  }
}
