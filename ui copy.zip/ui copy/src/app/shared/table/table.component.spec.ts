import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { UserService } from '../../services/user.service';
import { LoginService } from '../../login/login.service';
import { AdalService } from 'ng2-adal/dist/core';
import { SecretService } from '../../services/secret.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';
import { TableComponent } from './table.component';

xdescribe('TableComponent', () => {
  let component: TableComponent;
  let fixture: ComponentFixture<TableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      declarations: [ TableComponent ],
      providers: [UserService, LoginService, AdalService, SecretService, ConfigurationManagerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
