import { Component, Input, OnChanges, SimpleChanges, TemplateRef } from '@angular/core';
import { CatalogService } from '../../catalog/catalog.service';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-create-order',
  templateUrl: './create-order.component.html',
  styleUrls: ['./create-order.component.scss']
})

/* TO DO: integrate create order in catalog pages with this component */

export class CreateOrderComponent implements OnChanges {
  @Input() contentDetails;
  @Input() mirrorOrderId; // when create order from another order, it is used as a mirror reference. Id is used for link orders
  orderContentType;
  orderType = '';
  orderName = '';
  isFullEpisode = false;

  constructor(
    private catalogService: CatalogService,
    private dialog: MatDialog
  ) { }

  openDialog(ref: TemplateRef<any>, width, height) {
    this.dialog.open(ref, {
      width: width + 'px',
      height: height + 'px'
    });
    this.orderName = '';
    this.isFullEpisode = false;
  }

  createNewOrderPayload() {
    if (this.orderType === 'video') {
      let lineItems = [];
      if (this.catalogService.catalogOrderClipsArr.length > 0) {
        if (this.isFullEpisode) {
          lineItems.push({
            'metadata': []
          });
          for (let i = 0; i < this.catalogService.catalogOrderClipsArr.length; i++) {
            lineItems[0].metadata.push(
              {
                'clipTitle': this.catalogService.catalogOrderClipsArr[i].title,
                'clipId': this.catalogService.catalogOrderClipsArr[i].id,
                'dsId': this.catalogService.catalogOrderClipsArr[i].dsid
              }
            );
          }
        } else {
          for (let i = 0; i < this.catalogService.catalogOrderClipsArr.length; i++) {
            lineItems.push({
              'metadata': [{
                'clipTitle': this.catalogService.catalogOrderClipsArr[i].title,
                'clipId': this.catalogService.catalogOrderClipsArr[i].id,
                'dsId': this.catalogService.catalogOrderClipsArr[i].dsid
              }]
            });
          }
        }
      }
      if (this.mirrorOrderId) {
        this.catalogService.createVideoOrder(this.orderName, this.contentDetails.vmid, this.orderContentType, this.isFullEpisode, lineItems, [this.mirrorOrderId]);
      } else {
        this.catalogService.createVideoOrder(this.orderName, this.contentDetails.vmid, this.orderContentType, this.isFullEpisode, lineItems);
      }
    } else {
      if (this.mirrorOrderId) {
        this.catalogService.createNonVideoOrder(this.orderName, this.contentDetails.vmid, this.orderContentType, this.orderType, [this.mirrorOrderId]);
      } else {
        this.catalogService.createNonVideoOrder(this.orderName, this.contentDetails.vmid, this.orderContentType, this.orderType);
      }
    }
    this.orderType = '';
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.contentDetails.currentValue) {
      if (this.contentDetails.contentType) {
        this.orderContentType = this.contentDetails.contentType.toUpperCase();
        if (this.orderContentType === 'EVENT' || this.orderContentType === 'MOVIE') {
          this.orderContentType = 'SPECIAL';
        }
      } else {
        this.orderContentType = 'BRAND';
      }
    }
  }
}
