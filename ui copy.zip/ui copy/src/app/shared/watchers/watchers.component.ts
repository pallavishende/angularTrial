import { Component, OnInit, Input, Output, EventEmitter, TemplateRef } from '@angular/core';
import { UserService } from '../../services/user.service';
import { MatDialog } from '@angular/material';
import { find, indexOf, forEach, remove } from 'lodash';

@Component({
  selector: 'app-watchers',
  templateUrl: './watchers.component.html',
  styleUrls: ['./watchers.component.scss']
})
export class WatchersComponent implements OnInit {
  userLoginInfo;
  editedWatchersList = [];
  emailsToBeAdded = [];
  emailsToBeRemoved = [];
  isWatcherDuplicated = false;
  showAddWatcher = false;
  @Input() watchers: Array<object>;
  @Input() orderName?: string;
  @Output() updateWatchersNotify: EventEmitter<any> = new EventEmitter<any>();
  constructor(
    private userService: UserService,
    private matDialog: MatDialog
  ) { }

  openDialog(dialogRef: TemplateRef<any>, width, height) {
    this.matDialog.open(dialogRef, {
      width: width + 'px',
      height: height + 'px',
      disableClose: true
    });
    forEach(this.watchers, watcher => {
      this.editedWatchersList.push({email: watcher['login'], name: watcher['displayName']});
    });
  }

  closeDialog() {
    this.editedWatchersList = [];
    this.emailsToBeAdded = [];
    this.emailsToBeRemoved = [];
    this.showAddWatcher = false;
    this.matDialog.closeAll();
  }

  addWatcher(email, name: string): void {
    const isWatcherExisting = find(this.editedWatchersList, watcher => watcher.email === email);
    if (!isWatcherExisting) {
      this.editedWatchersList.unshift({email: email, name: name});
      this.isWatcherDuplicated = false;
      if (indexOf(this.emailsToBeRemoved, email) < 0) {
        this.emailsToBeAdded.unshift(email);
      } else {
        this.emailsToBeRemoved.splice(indexOf(this.emailsToBeRemoved, email), 1);
      }
      this.showAddWatcher = false;
      return;
    }
    this.isWatcherDuplicated = true;
  }

  removeWatcher(email: string): void {
    remove(this.editedWatchersList, watcher => watcher.email === email);
    if (indexOf(this.emailsToBeAdded, email) > -1) {
      this.emailsToBeAdded.splice(indexOf(this.emailsToBeAdded, email), 1);
    } else {
      this.emailsToBeRemoved.push(email);
    }
  }

  submitWatchers() {
    this.updateWatchersNotify.emit({toBeAdded: this.emailsToBeAdded, toBeRemoved: this.emailsToBeRemoved});
  }

  isWatching(): boolean {
    return Boolean(find(this.watchers, watcher => watcher['login'] === this.userLoginInfo.email));
  }

  hideAddMyself(): boolean {
    return Boolean(find(this.editedWatchersList, watcher => watcher['email'] === this.userLoginInfo.email));
  }

  getNameIcon(name: string) {
    return name.substr(name.indexOf(',') + 2, 1).toUpperCase();
  }

  ngOnInit() {
    this.userLoginInfo = this.userService.getUserLoginInfo();
  }
}
