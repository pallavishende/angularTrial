import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { UserService } from '../../services/user.service';
import { StorageService } from '../../services/storage.service';

@Injectable()
export class ActivityListRouteGuard implements CanActivate {

  constructor(private router: Router, private userService: UserService, private storageService: StorageService) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
       return this.userService.getMyTeams().map(data => {
        if (state.url === '/tasks/my-teams-tasks' && data.length === 0) {
          this.storageService.resetActivitiesObjInLocal();
          this.router.navigateByUrl('/tasks/my-tasks');
        }
        return true;
      });
  }

}
