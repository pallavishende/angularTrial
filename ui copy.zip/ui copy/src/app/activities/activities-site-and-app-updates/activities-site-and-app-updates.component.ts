import { Component, OnInit, OnDestroy, AfterViewInit, QueryList, ViewChildren } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActivitiesService } from '../activities.service';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/toPromise';
import * as _ from 'lodash';
import { LineItem } from '../../models/line-item';
import { OrdersService } from '../../orders/orders/orders.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { ActivityHelperService } from '../activity-helper.service';
import { ActivitiesCommentsService } from '../activities-comments/activities-comments.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { UserService } from '../../services/user.service';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import { CustomEditorService } from '../../shared/custom-editor/custom-editor.service';

@Component({
  selector: 'app-activities-site-and-app-updates',
  templateUrl: './activities-site-and-app-updates.component.html',
  styleUrls: ['./activities-site-and-app-updates.component.scss', '../activities.scss'],
  providers: [ ActivitiesCommentsService, CustomEditorService ]
})
export class ActivitiesSiteAndAppUpdatesComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChildren('versions') versions: QueryList<any>;
  activityId;
  detailsObj;
  orderStatus;
  lineItem;
  endpointObj = [];
  endpointNames: Array<any> = [];
  attachmentsStatus: Array<any> = [];
  loggedInUser;
  subscriptions = new Subscription();
  dataSubscription: Subscription;
  updatedObj;
  selectedLineItem;
  submissionComment: string;
  activitySubmissionObj;
  allowSubmission = {};
  commentServiceInstances = {};
  initializeEditor: boolean;
  isValidDescription: boolean;
  activeActivitiesTab;
  fragment: string;
  oldSubmissionMsg = '';
  disableDataPolling = false;

  constructor(
    private ordersService: OrdersService,
    private activitiesService: ActivitiesService,
    private activeRoute: ActivatedRoute,
    private alerts: SystemAlertsService,
    private activityHelperService: ActivityHelperService,
    private loadingMaskService: LoadingMaskService,
    private userService: UserService,
    private customEditorService: CustomEditorService
  ) { }

  pollingFunction() {
    this.subscriptions.add(IntervalObservable.create(20000).subscribe(
      interval => {
        this.pollCurrentTaskStatus();
      }
    ));
  }

  pollCurrentTaskStatus() {
    const self = this;
    if (typeof this.dataSubscription !== 'undefined') {
      this.dataSubscription.unsubscribe();
    }
    this.dataSubscription = this.activitiesService.getActivityDetail(this.activityId)
      .subscribe( data => {
        if (!this.disableDataPolling) {
          const prevStatus = this.lineItem.composeStatus;
          this.lineItem.composeStatus = this.activityHelperService.getComposeActivityStatus(data.lineItems[0]);
          if (prevStatus !== this.lineItem.composeStatus) {
            self.getActivityInfo();
          }
          self.getOrderStatus();
        }
      });
  }

  getOrderStatus() {
    this.subscriptions.add(this.ordersService.getOrderDetails(this.detailsObj.activityBundle.orderId).subscribe(
      data => {
        this.orderStatus = data.currentMilestone.status;
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }));
  }

  getActivityInfo() {
    this.loadingMaskService.enableLoadingMask();
    this.subscriptions.add(this.activitiesService.getActivityDetail(this.activityId)
    .subscribe(
      data => {
        this.loadingMaskService.disableLoadingMask();
        console.log('...: ', data);
        this.detailsObj = data;
        this.getOrderStatus();
        Object.keys(this.commentServiceInstances).forEach(key => {
          this.commentServiceInstances[key].getActivityEvents(key);
        });
        const self = this;
        this.lineItem = this.detailsObj.lineItems[0];
        this.lineItem.composeStatus = self.activityHelperService.getComposeActivityStatus(this.lineItem);
      },
      error => {
        this.loadingMaskService.disableLoadingMask();
        if (error.status === 404) {
          this.alerts.redirectTo404Page();
        } else {
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        }
        console.log('all activities error', error);
      }
    ));
  }

  getSiteAndAppUpdatesActivity(item?: LineItem) {
    let lineItem;
    if (item) {
      lineItem = item;
    } else {
      lineItem = this.selectedLineItem;
    }
    return _.find(lineItem.activities, {'typeId': 14 });
  }

  updateFilesMetadata(event, lineItem?, activityType?) {
    if (activityType === 'SITE_AND_APP_UPDATES_ACTIVITY') {
      if (!event.uploadingInProgressQueue.length) {
        _.forEach(event.uploadedFileQueue, (uploadedFile) => {
          uploadedFile.source = 'S3';
          uploadedFile.activityId = this.getSiteAndAppUpdatesActivity(lineItem)['id'];
        });
        this.subscriptions.add(this.activitiesService.updateFilesMetadata(event.uploadedFileQueue).subscribe(
        (data) => {
          console.log('Successfully updated the metadata.');
          if (this.detailsObj.lineItems[0].activities[0].input) {
            this.detailsObj.lineItems[0].activities[0].input.attachments = data;
          } else {
            this.detailsObj.lineItems[0].activities[0].input = { attachments: data};
          }
        }));
      }
    } else {
      this.attachmentsStatus = event;
    }
  }

  getActivitiesForApproval(lineItem: any) {
    let tmp = _.filter(lineItem.activities, function(activity) {
      return _.get(activity, 'currentState.status') === 'TO_DO' || 'WAITING';
    });
  return tmp;
  }

  onSubmitForApproval(lineItem: any) {
   let activities = this.getActivitiesForApproval(lineItem);
   lineItem.composeStatus = 'Updating';
   // extracting the ids from activities
   for (let i = 0; i < activities.length; i++) {
     activities[i] = activities[i]['id'];
   }
   let siteAndAppUpdatesActivityId = this.getSiteAndAppUpdatesActivity(lineItem)['id'];
   let mentionsEmails = [];
    this.activitySubmissionObj['mentionedUsers'].forEach((element) => {
      mentionsEmails.push(element.email);
    });
   let submissionPayload = {
     activityIds: activities,
     activityIdForEvent: siteAndAppUpdatesActivityId,
     orderId: this.detailsObj.activityBundle.orderId,
     message: this.submissionComment || '',
     mentionedUserEmails: mentionsEmails,
     createdByEmail: this.userService.getUserLoginInfo().email,
     attachments: this.attachmentsStatus['uploadedFileQueue']
   };
   this.loadingMaskService.enableLoadingMask();
   this.disableDataPolling = true;
   this.subscriptions.add(this.activitiesService.submitActivityForApproval(submissionPayload).subscribe(
     data => {
       this.loadingMaskService.disableLoadingMask();
       console.log('SUCCESSFULLY SUBMITTED FOR APPROVAL');
       this.alerts.addSuccessAlerts('Success! Your work was submitted for approval.');
       this.submissionComment = '';
       setTimeout(() => {
        this.commentServiceInstances[siteAndAppUpdatesActivityId].getActivityEvents(siteAndAppUpdatesActivityId);
        this.disableDataPolling = false;
        this.pollCurrentTaskStatus();
       }, 2000);
      },
      error => {
        this.loadingMaskService.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      }
    ));
  }

  setAddingCommentEvent(value: any) {
    let activityId = value['activityId'];
    let isAddingComment = value['isAddingComment'];
    this.allowSubmission[activityId] = isAddingComment;
  }

  setCommentsServiceInstanceObj(event) {
   this.commentServiceInstances[event.id] = event.serviceInstance;
  }

  onOpen() {
    setTimeout(() => {
      this.initializeEditor = true;
  });
  }

  onClose() {
    this.initializeEditor = false;
    this.attachmentsStatus = [];
  }

  getCommentFromEditor() {
    this.customEditorService.getCommentFromEditor.emit();
    console.log('fetching comment..:');
  }

  setPreSubmitMsg(activityId) {
    this.oldSubmissionMsg = this.commentServiceInstances[activityId].getPreSubmitMsg();
  }

  contentChanged(event) {
    this.activitySubmissionObj = event;
    if (event.isValidContent) {
      // this.renderer.addClass(this.submitDescriptionBtn.nativeElement, 'ready');
      this.isValidDescription = true;
      this.submissionComment = event.content;
    } else {
      if (this.submissionComment) {
        this.submissionComment = event.content;
      }
      // this.renderer.removeClass(this.submitDescriptionBtn.nativeElement, 'ready');
      this.isValidDescription = false;
    }
    if (event.readyToPostComment) {
      this.onSubmitForApproval(this.selectedLineItem);
    }
  }

  ngOnInit() {
    this.activitiesService.setActivitiesPageTitle('Site & App Updates - Viacom Bridge');
    this.loggedInUser = this.userService.getUserLoginInfo();
    this.activityId = this.activeRoute.snapshot.params['id'];
    this.getActivityInfo();
    this.pollingFunction();
    this.activeRoute.fragment.subscribe((fragment) => {
      this.fragment = fragment;
    });
  }

  ngAfterViewInit(): void {
    // converting queryList observable to promise to trigger a callback when the versions are loaded in the DOM
    this.versions.changes.take(1).toPromise().then(data => {
      if (this.fragment) {
        this.versions.forEach((version) => {
        if (version.nativeElement.id === this.fragment) {
          document.querySelector('#' + this.fragment).scrollIntoView(true);
          let scrolledY = window.scrollY;
          // checking if this is not the last version on the page to substract the header height
          if (scrolledY && ('version' + (this.endpointObj[this.endpointNames[this.endpointNames.length - 1]]
          [this.endpointObj[this.endpointNames[this.endpointNames.length - 1]].length - 1].id)) !== this.fragment) {
            window.scroll(0, scrolledY - 200);
          }
          return;
        }
      });
    }
    });
  }

  ngOnDestroy() {
    if (this.dataSubscription) {
      this.dataSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
  }

}
