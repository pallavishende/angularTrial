import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesSiteAndAppUpdatesComponent } from './activities-site-and-app-updates.component';

xdescribe('ActivitiesSiteAndAppUpdatesComponent', () => {
  let component: ActivitiesSiteAndAppUpdatesComponent;
  let fixture: ComponentFixture<ActivitiesSiteAndAppUpdatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesSiteAndAppUpdatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesSiteAndAppUpdatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
