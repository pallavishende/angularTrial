import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { ActivitiesService } from '../activities.service';

@Component({
  selector: 'app-asset-restoration',
  templateUrl: './asset-restoration.component.html',
  styleUrls: ['./asset-restoration.component.scss', '../activities.scss']
})
export class AssetRestorationComponent implements OnInit, OnDestroy {
  assetInfoObj;
  status; // to do - put this in the object
  @Input() assetOptions: any;
  dataSubscription: Subscription;
  subscriptions = new Subscription();
  constructor(private activitiesService: ActivitiesService) { }

  getAssetInfo() {
    this.subscriptions.add(this.activitiesService.getAssetRestorationInfo(this.assetOptions.lineItemId).subscribe(
      data => {
        this.assetInfoObj = data;
        if ( this.assetInfoObj.percentage === '100' ) {
          this.ngOnDestroy();
        }
      },
      error => {
        console.log('Error loading data: ', error);
      }
    ));
  }

  ngOnInit() {
    // let self = this;
    // self.getAssetInfo();  // initial call
    // this.intervalSubscription = IntervalObservable.create(20000).subscribe(
    //   interval => {
    //     self.getAssetInfo();
    //   });
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
