import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesCreateGraphicsComponent } from './activities-create-graphics.component';

xdescribe('ActivitiesCreateGraphicsComponent', () => {
  let component: ActivitiesCreateGraphicsComponent;
  let fixture: ComponentFixture<ActivitiesCreateGraphicsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesCreateGraphicsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesCreateGraphicsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should be created', () => {
    expect(component).toBeTruthy();
  });
});
