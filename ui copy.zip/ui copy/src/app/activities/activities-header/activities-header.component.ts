import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivityHelperService } from '../activity-helper.service';
import { Subscription } from 'rxjs';
import { ActivitiesService } from '../activities.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import * as _ from 'lodash';
import { UtilityService } from '../../services/utility.service';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-activities-header',
  templateUrl: './activities-header.component.html',
  styleUrls: ['./activities-header.component.scss']
})
export class ActivitiesHeaderComponent implements OnInit {
  @Input() detailsObj;
  @Input() orderStatus;
  @Output() updateActivity = new EventEmitter<any>();
  subscriptions = new Subscription();
  previousPage: { url: string, name: string; };
  pageSubheader = '';
  loggedInUser;
  clipInfo;
  workflowRouteObj;
  isFullEpisode = false;
  isVideoPublishingActivity: boolean;
  showAssets = false;
  startWorkFlag = false;

  constructor(
    private userService: UserService,
    private activitiesService: ActivitiesService,
    private activityHelperService: ActivityHelperService,
    private utilityService: UtilityService,
    private alerts: SystemAlertsService,
    private router: Router
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  getActivityClipInfo() {
    const bundleId = this.detailsObj.activityBundle.id;
    const clipsInfo = this.detailsObj.orderClipsInfo;
    if (clipsInfo) {
      _.forEach(clipsInfo, clipInfo => {
        if (clipInfo.activityBundles) {
          if (_.find(clipInfo.activityBundles, bundle => bundle['bundleId'] === bundleId)) {
            this.clipInfo = clipInfo;
            return;
          }
        }
      });
    } else {
      this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page.');
      return;
    }
  }

  constructActivitiesWorkflowRoutes() {
    this.workflowRouteObj = [];
    if (this.isVideoPublishingActivity) {
      this.workflowRouteObj = this.clipInfo.activityBundles;
      this.workflowRouteObj = _.orderBy(this.workflowRouteObj, ['activityTypeId'], ['asc']);
      _.forEach(this.workflowRouteObj, workflow => {
        workflow['activityName'] = this.utilityService.getActivityNameByTypeId(workflow['activityTypeId']);
        workflow['activityRoute'] = this.utilityService.getActivityRouteByTypeId(workflow['activityTypeId']);
      });
      // change for combined approve and publish
      _.remove(this.workflowRouteObj, route => route['activityTypeId'] === 7);
    } else {
      if (this.detailsObj.lineItems[0] && this.detailsObj.lineItems[0].activities && this.detailsObj.lineItems[0].activities[0]) {
        const composeActivity = this.detailsObj.lineItems[0].activities[0];
        if (composeActivity.subActivities && composeActivity.subActivities[0]) {
          const approveActivity = composeActivity.subActivities[0];
          this.workflowRouteObj.push({
            'activityTypeId': composeActivity.typeId,
            'activityName': this.utilityService.getActivityNameByTypeId(composeActivity.typeId),
            'activityRoute': this.utilityService.getActivityRouteByTypeId(composeActivity.typeId),
            'bundleId': composeActivity.activityBundleId
          });
          this.workflowRouteObj.push({
            'activityTypeId': approveActivity.typeId,
            'activityName': this.utilityService.getActivityNameByTypeId(approveActivity.typeId),
            'activityRoute': this.utilityService.getActivityRouteByTypeId(approveActivity.typeId),
            'bundleId': approveActivity.activityBundleId
          });
        }
      }
    }
  }

  getClipRoute(clipInfo) {
    if (clipInfo.activityBundles) {
      let targetActivity = _.find(clipInfo.activityBundles, activity => activity['activityTypeId'] === this.detailsObj.activityBundle.activityTypeId);
      if (!targetActivity) {
        targetActivity = _.find(clipInfo.activityBundles, activity => activity['activityTypeId'] === 1); // if same type of activity is not found, route to compose video
      }
      if (targetActivity) {
        this.router.navigateByUrl('/tasks/' + targetActivity['bundleId'] + '/' + this.utilityService.getActivityRouteByTypeId(targetActivity['activityTypeId']));
      }
    }
  }

  getOrderOwner() {
    if (this.detailsObj.assigneeName && this.detailsObj.assigneeName !== 'UNASSIGNED') {
      return this.detailsObj.assigneeName;
    } else if (this.detailsObj.teamName) {
      return this.detailsObj.teamName;
    } else {
      return 'UNASSIGNED';
    }
  }

  onSelectNameNotify(payload: any) {
    this.subscriptions.add(this.activitiesService.assignActivity(payload)
    .subscribe(
      data => {
        this.updateActivity.emit();
      },
      error => {
        console.log('assing all activity error');
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      }
    ));
  }

  startWork() {
    this.startWorkFlag = true;
    const payload = {
      'groupedActivityIds': [this.detailsObj.activityBundle.id],
      'startWorkBy': this.detailsObj.assigneeEmail
    }
    this.subscriptions.add(this.activitiesService.startWork(payload)
      .subscribe(
        data => {
          this.detailsObj.activityBundle.status = 'IN_PROGRESS';
        },
        error => {
          console.log('start work error');
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }
      ));
  }

  toggleTask(isReopen: boolean) {
    const activityBundleIds = [];
    if (this.detailsObj.orderClipsInfo.length !== 0) {
      this.detailsObj.orderClipsInfo.forEach((element) => {
        element.activityBundles.forEach((item) => {
          if (item.activityTypeId !== 7) {
            activityBundleIds.push(item.bundleId);
          }
        });
      });
    } else {
      this.workflowRouteObj.forEach((element) => {
        activityBundleIds.push(element.bundleId);
      });
    }
    const payload = {
      'reOpenedActivityBundleId': this.detailsObj.activityBundle.id,
      'createdBy': this.loggedInUser.email,
      'orderId': this.detailsObj.activityBundle.orderId,
      'activityStatus': isReopen ? 'REOPENED' : 'COMPLETED',
      'activityIdForEvent': this.detailsObj.activityBundle.activityIds[0],
      'activityBundleIds': activityBundleIds
    }
    this.subscriptions.add(this.activitiesService.toggleTask(payload)
      .subscribe(
        data => {
          this.updateActivity.emit();
        },
        error => {
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page!');
        }
      ));
  }

  ngOnInit() {
    this.loggedInUser = this.userService.getUserLoginInfo();
    this.previousPage = this.activityHelperService.setActivityDetailsBackToNavigationRoute();
    if (this.detailsObj.activityBundle.isFullEpisode) {
      this.isFullEpisode = this.detailsObj.activityBundle.isFullEpisode;
    }
    this.pageSubheader = this.activityHelperService.getHeaderBundleInfo(this.detailsObj.metadata);
    this.isVideoPublishingActivity = this.detailsObj.activityBundle.activityTypeId === 1
    || this.detailsObj.activityBundle.activityTypeId === 7
    || this.detailsObj.activityBundle.activityTypeId === 13
    || this.detailsObj.activityBundle.activityTypeId === 16;
    this.getActivityClipInfo();
    this.constructActivitiesWorkflowRoutes();
  }
}
