import { Component, OnInit, OnDestroy, AfterViewChecked, Input, Output, EventEmitter, ViewChild, Renderer2, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material';
import { UserService } from '../../services/user.service';
import { UtilityService } from '../../services/utility.service';
import { ActivitiesCommentsService } from './activities-comments.service';
import { CustomEditorService } from '../../shared/custom-editor/custom-editor.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-activities-comments',
  templateUrl: './activities-comments.component.html',
  providers: [ ActivitiesCommentsService, CustomEditorService ],
  styleUrls: ['../activities.scss', './activities-comments.component.scss']
})
export class ActivitiesCommentsComponent implements OnInit, OnDestroy, AfterViewChecked {

  @Input() activityId: any;
  @Input() isSubActivity;
  @ViewChild('postCommentBtn') postCommentBtn;
  @ViewChild('deleteCommentDialog') deleteCommentDialog: TemplateRef<any>;
  @Output() addingComment = new EventEmitter<any>();
  @Output() numberOfComments = new EventEmitter<any>();
  @Output() serviceIntance = new EventEmitter<any>();

  isCommentValid: boolean;
  showCommentArea: boolean;
  comment: string;
  commentObj: any;
  selectedComment: any;
  commentEditorObj: any;
  commentsCount = 0;
  activityTypesList;
  activityTypes: Array<string>;
  mentionedUsers = [];
  loggedInUser: any;
  subscriptions = new Subscription();
  scrolled = false;

  constructor(private userService: UserService,
              private utilityService: UtilityService,
              private activitiesCommentsService: ActivitiesCommentsService,
              private customEditorService: CustomEditorService,
              private renderer: Renderer2,
              private dialog: MatDialog) {}

  ngOnInit() {
    this.subscriptions.add(this.activitiesCommentsService.commentStream.subscribe(
      (obj) => {
        this.commentsCount = obj['commentsCount'];
        this.numberOfComments.emit ({
          count: this.commentsCount,
          activityId: this.activityId});
      }
    ));

    this.addingComment.emit({
        isAddingComment: false,
        activityId: this.activityId
    });
    this.activitiesCommentsService.getActivityEvents(this.activityId);
    this.activityTypesList = this.utilityService.getActivityTypesList();
    this.serviceIntance.emit({
      id: this.activityId,
      serviceInstance: this.activitiesCommentsService});
    this.loggedInUser = this.userService.getUserLoginInfo();
  }

  getCommentFromEditor() {
    this.customEditorService.getCommentFromEditor.emit();
    console.log('fetching comment..:');
  }

  postComment() {
    const email = [];
    for (const user of this.commentEditorObj.mentionedUsers) {
        email.push(user.email);
    }
    this.commentObj = {
      body: this.comment,
      createdByEmail: this.userService.getUserLoginInfo().email,
      activityId: this.activityId,
      mentionedUserEmails: email
    };
    this.activitiesCommentsService.postComment(this.commentObj, this.isSubActivity);
  }

  addCommentEvent(isAddingComment: boolean) {
    this.addingComment.emit(
      {
        isAddingComment: !this.showCommentArea,
        activityId: this.activityId
      });
    this.showCommentArea = isAddingComment;
  }

  contentChanged(event) {
    this.commentEditorObj = event;
    this.comment = this.commentEditorObj.content;
    if (event.isValidContent) {
    this.renderer.addClass(this.postCommentBtn.nativeElement, 'ready');
    } else {
      this.renderer.removeClass(this.postCommentBtn.nativeElement, 'ready');
    }
    this.isCommentValid = this.isValidComment();
  }

  isValidComment(): boolean {
    if (this.comment) {
      return true;
    } else {
      return false;
    }
  }

  openDeleteCommentDialog(userComment: any): void {
    this.selectedComment = userComment;
    userComment.activityId = this.activityId;
    this.dialog.open(this.deleteCommentDialog, {
      width: '560px',
      height: '200px'
    });
  }

  deleteUserComment() {
    this.selectedComment.isDeleted = true;
    this.activitiesCommentsService.deleteComment(this.selectedComment);
    delete this.selectedComment;
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  ngAfterViewChecked() {
    const currentURL = window.location.href;
    if (currentURL.indexOf('#') !== -1) {
      const commentID = currentURL.slice(currentURL.indexOf('#') + 1);
      const pointedComment = document.getElementById(commentID);
      if (pointedComment && !this.scrolled) {
        pointedComment.scrollIntoView();
        setTimeout(() => {
          pointedComment.removeAttribute('id');
          this.scrolled = true;
          history.pushState('', document.title, window.location.pathname + window.location.search);
        }, 300);
      }
    }
  }
}
