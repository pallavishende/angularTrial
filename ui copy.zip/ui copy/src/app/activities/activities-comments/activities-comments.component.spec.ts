import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesCommentsComponent } from './activities-comments.component';

xdescribe('ActivitiesCommentsComponent', () => {
  let component: ActivitiesCommentsComponent;
  let fixture: ComponentFixture<ActivitiesCommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesCommentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesCommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should be created', () => {
    expect(component).toBeTruthy();
  });
});
