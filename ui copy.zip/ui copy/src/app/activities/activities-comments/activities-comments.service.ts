import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { Comment } from '../../models/comment';
import { ActivitiesService } from '../activities.service';
import { SystemAlertsService } from '../../services/system-alerts.service';

@Injectable()
export class ActivitiesCommentsService implements OnDestroy {

  private notifyChanges: BehaviorSubject<{}> = new BehaviorSubject(new Object());
  commentStream = this.notifyChanges.asObservable();
  subscriptions = new Subscription();
  comment: string;
  userCommentCollection = [];
  commentsCount = 0;
  activityTypesList;
  activityTypes: Array<string>;
  updatedData = {};
  isCommentsLoading: boolean;
  isCommentsPosting: boolean;
  preSubmitMsg = '';

  constructor(private activitiesService: ActivitiesService,
              private alerts: SystemAlertsService) { }


postComment(commentObj: Comment, isSubActivity?: boolean) {
    this.isCommentsPosting = true;
    this.subscriptions.add(this.activitiesService.postComment(commentObj, isSubActivity)
    .subscribe(
      data => {
        this.isCommentsPosting = false;
        this.getActivityEvents(commentObj.activityId);
      },
      error => {
        console.log('Error posting the comment on Activity:', commentObj.activityId);
        this.isCommentsPosting = false;
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      }
    ));
  }

  deleteComment(commentObj) {
    this.subscriptions.add(this.activitiesService.deleteComment(commentObj.id).subscribe(
      (data) => {
        console.log('The selected comment has been successfully deleted.');
        this.getActivityEvents(commentObj.activityId);
      },
      (error) => {
        this.alerts.addErrorAlerts('The comment could not be deleted. Please try again.');
        commentObj.isDeleted = false;
      }
    ));
  }

  notify() {
    this.notifyChanges.next(this.updatedData);
  }

  getActivityEvents(activityId) {
    this.isCommentsLoading = true;
    this.subscriptions.add(this.activitiesService.getActivityEvents(activityId)
    .subscribe(
      data => {
        this.isCommentsLoading = false;
        this.userCommentCollection = data;
        this.setPreSubmitMsg(data);
        this.commentsCount = this.getCommentsCount();
        this.updatedData = {
           commentsCount: this.commentsCount,
           commentsThread: this.userCommentCollection
         };
        this.notify();
      },
      error => {
        console.log('Error: couldn\'nt get the events from timeline');
        this.isCommentsLoading = false;
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  getLatestCommentEvent(event, type: string) {
    let resultEvent;
    event.forEach(comment => {
      if (comment.type === type) {
        // TO DO: remove this condition check when backend fixes duplicated events for edit copy
        if (comment.activityTypeId === 3) {
          if (comment.commentId) {
            resultEvent = comment;
          }
        } else {
          resultEvent = comment;
        }
      }
    });
    return resultEvent;
  }

  getCommentsCount(): number {
    let count = 0;
    this.userCommentCollection.forEach((element) => {
      if (element.type === 'COMMENTED' || element.type === 'CONTENT_SUBMITTED' || element.type === 'PUBLISHED') {
        count++;
      }
    });
    return count;
  }

  setPreSubmitMsg(data) {
    const submissionLineItems = data.filter(lineItem => lineItem.type === 'CONTENT_SUBMITTED');
    if (submissionLineItems.length > 0) {
      this.preSubmitMsg = submissionLineItems[submissionLineItems.length - 1].comment.message;
    }
  }

  getPreSubmitMsg() {
    return this.preSubmitMsg;
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
