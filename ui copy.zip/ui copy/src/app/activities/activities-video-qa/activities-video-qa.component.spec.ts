import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesVideoQaComponent } from './activities-video-qa.component';

describe('ActivitiesVideoQaComponent', () => {
  let component: ActivitiesVideoQaComponent;
  let fixture: ComponentFixture<ActivitiesVideoQaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesVideoQaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesVideoQaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should be created', () => {
    expect(component).toBeTruthy();
  });
});
