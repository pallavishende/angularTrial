import { Component, OnInit, OnDestroy, AfterViewInit, QueryList, ViewChildren } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActivitiesService } from '../activities.service';
import { Subscription } from 'rxjs/Subscription';
import * as _ from 'lodash';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/mergeMap';
import { UtilityService } from '../../services/utility.service';
import { Activity } from '../../models/activity';
import { LineItem } from '../../models/line-item';
import { ActivityHelperService } from '../activity-helper.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { OrdersService } from '../../orders/orders/orders.service';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';

@Component({
  selector: 'app-activities-qa',
  templateUrl: './activities-qa.component.html',
  styleUrls: ['./activities-qa.component.scss', '../activities.scss']
})
export class ActivitiesQaComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChildren('versions') versions: QueryList<any>;
  activityId;
  detailsObj;
  orderStatus;
  lineItem;
  endpointObj = [];
  endpointNames: Array<any> = [];
  approvalSubmitted = false;
  submitForApproval = false;
  commentsCount = {};
  dataSubscription: Subscription;
  subscriptions = new Subscription();
  updatedObj;
  commentServiceInstances = {};
  activeActivitiesTab;
  pageFragment: string;
  disableDataPolling = false;
  attachmentsStatus: Array<any> = [];

  constructor(
    private activitiesService: ActivitiesService,
    private activeRoute: ActivatedRoute,
    private utilityService: UtilityService,
    private activityHelperService: ActivityHelperService,
    private loadingMaskService: LoadingMaskService,
    private ordersService: OrdersService,
    private alerts: SystemAlertsService
  ) { }

  ngOnInit() {
    this.activitiesService.setActivitiesPageTitle('QA - Site & App Updates - Viacom Bridge');
    this.activityId = this.activeRoute.snapshot.params['id'];
    this.getActivityInfo();
    this.pollingFunction();
    this.activeRoute.fragment.subscribe((fragment) => {
      this.pageFragment = fragment;
    });
  }

  ngAfterViewInit(): void {
    // converting queryList observable to promise to trigger a callback when the versions are loaded in the DOM
    this.versions.changes.take(1).toPromise().then(data => {
      if (this.pageFragment) {
        this.versions.forEach((version) => {
        if (version.nativeElement.id === this.pageFragment) {
          document.querySelector('#' + this.pageFragment).scrollIntoView(true);
          let scrolledY = window.scrollY;
          // checking if this is not the last version on the page to substract the header height
          if (scrolledY && ('version' + (this.endpointObj[this.endpointNames[this.endpointNames.length - 1]]
          [this.endpointObj[this.endpointNames[this.endpointNames.length - 1]].length - 1].id)) !== this.pageFragment) {
            window.scroll(0, scrolledY - 200);
          }
          return;
        }
      });
    }
    });
  }

  pollingFunction() {
    this.subscriptions.add(IntervalObservable.create(20000).subscribe(
      interval => {
        this.pollCurrentTaskStatus();
      }
    ));
  }

  pollCurrentTaskStatus(targetLineItem?) {
    const self = this;
    if (typeof this.dataSubscription !== 'undefined') {
      this.dataSubscription.unsubscribe();
    }
    this.dataSubscription = this.activitiesService.getActivityDetail(this.activityId)
    .subscribe( data => {
      if (!this.disableDataPolling || targetLineItem) {
        if (targetLineItem) {
          if (this.activityHelperService.getApproveActivityStatus(data.lineItems[0]).status !== targetLineItem.targetStatus
              && this.lineItem.approveStatus === 'Updating') {
            return; // keep state as updating while retrying
          }
        }
        const prevStatus = this.lineItem.approveStatus;
        this.lineItem.approveStatus = this.activityHelperService.getApproveActivityStatus(data.lineItems[0]).status;
        if (prevStatus !== this.lineItem.approveStatus) {
          self.getActivityInfo();
        }
        self.getOrderStatus();
      }
    });
  }

  getOrderStatus() {
    this.subscriptions.add(this.ordersService.getOrderDetails(this.detailsObj.activityBundle.orderId).subscribe(
      data => {
        this.orderStatus = data.currentMilestone.status;
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }));
  }

  getActivityInfo() {
    this.loadingMaskService.enableLoadingMask();
    this.subscriptions.add(this.activitiesService.getActivityDetail(this.activityId)
    .flatMap(
      data => {
        this.loadingMaskService.disableLoadingMask();
        console.log('....: ', data);
        this.detailsObj = data;
        this.getOrderStatus();
        Object.keys(this.commentServiceInstances).forEach(key => {
          this.commentServiceInstances[key].getActivityEvents(key);
        });
        const self = this;
        this.lineItem = this.detailsObj.lineItems[0];
        this.lineItem.approveStatus = self.activityHelperService.getApproveActivityStatus(this.lineItem).status;
        // getting the order info for status
        return this.ordersService.getOrder(this.detailsObj.activityBundle.orderId);
      }
    )
    .subscribe(
      data => {
        this.detailsObj.orderInfo = data;
        console.log('QA - Site & App Updates > orders data: ', this.detailsObj);
      },
      error => {
        this.loadingMaskService.disableLoadingMask();
        if (error.status === 404) {
          this.alerts.redirectTo404Page();
        } else {
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        }
      }
    ));
  }

  versionIsPublished(version) {
    let currentVersion;
    let publishActivity;
    let status;
    if (this.detailsObj.orderInfo) {
      currentVersion = _.find(this.detailsObj.orderInfo.lineItems, {'id': version.id });
    }
    if (currentVersion) {
      publishActivity = _.find(currentVersion.activities, {'typeId': 13});
    }
    if (publishActivity) {
      status = publishActivity.currentState.status === 'COMPLETED';
    }
    return status;
  }

  orderIsCompleted() {
    if (_.get(this.detailsObj, 'orderInfo.currentMilestone.status')) {
      return _.get(this.detailsObj, 'orderInfo.currentMilestone.status').toString() === 'COMPLETED';
    } else {
      return '';
    }
  }

  getApprovableActivities(activities: Array<Activity>) {
    // return _.sortBy(activities, ['typeId']); // changed to one approval for all activities
    if (_.find(activities, {'typeId': 14})) {
      return [_.find(activities, {'typeId': 14})];
    } else {
      return [];
    }
  }

  getToggleOptions(activity: Activity, lineItem: LineItem) {
    let qaActivity = this.getSiteAndAppUpdatesActivity(lineItem)['id'];
    let siteAndAppUpdatesActivity = this.getQaApproveActivity(activity);
    let correspondingApprovalTypeObj = _.find(this.utilityService.getActivityTypesList(), function(item) {
      return item.map === activity.typeId && item.type !== activity.typeId;
    });
    let correspondingApprovalActivity = _.find(activity.subActivities, function(subActivity) {
      return subActivity.typeId === correspondingApprovalTypeObj.type;
        // &&  subActivity.assignedUserEmail === userServiceRef.getUserLoginInfo().email;
    });
    if ( correspondingApprovalActivity ) {
      return {
        activity: siteAndAppUpdatesActivity,
        commentActivityId: qaActivity,
        subActivity: correspondingApprovalActivity,
        lineItem: lineItem,
        episode: this.detailsObj.metadata.title,
        isOrderComplete: this.orderIsCompleted(),
        isVersionPublished: this.versionIsPublished(lineItem)
      };
    } else {
      return {};
    }
  }

  onStatusChange(e) {
    let publishActivityId = e.activityId;
    let lineItem = e.lineItem;
    let activityId = this.getSiteAndAppUpdatesActivity(lineItem)['id'];
    delete e.lineItem;
    //delete more params
    e['orderId'] = this.detailsObj.activityBundle.orderId;
    this.onActionTaken(lineItem);
    if(e.status === 'APPROVED') {
      this.handleSubmission('submitting');
      const submissionPayload = {
        subActivityId: e.subActivityId
      };
      this.subscriptions.add(this.activitiesService.submitApprovalActivity('/approve', e.subActivityId, submissionPayload)
      .subscribe(
        data => {
          console.log('APPROVALS: Approved Successfully', e);
          this.retrySubmission(lineItem, 1, 'COMPLETED');
          this.commentServiceInstances[activityId].getActivityEvents(activityId);
        },
        error => {
          console.log('APPROVALS: Status not updated');
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }
      ));
    } else if (e.status === 'REJECTED') {
      this.handleSubmission('submitting');
      const submissionPayload = {
        activityId: e.activityId,
        activityIdForEvent: e.activityIdForEvent,
        message: e.message,
        mentionedUserEmails: e.mentionedUserEmails,
        createdByEmail: e.createdByEmail
      };
      this.subscriptions.add(this.activitiesService.submitApprovalActivity('/reject', e.subActivityId, submissionPayload)
      .subscribe(
        data => {
          console.log('APPROVALS: Rejected Successfully', e);
          this.retrySubmission(lineItem, 1, 'WAITING');
          this.commentServiceInstances[activityId].getActivityEvents(activityId);
        },
        error => {
          console.log('APPROVALS: Status not updated');
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }
      ));
    }
  }

  handleSubmission(e) {
    if (e === 'submitting') { // when user hit approve toggle
      this.disableDataPolling = true;
    } else if (e === 'submitted') { // when lineitem polled correct status or when 3 retries failed
      this.disableDataPolling = false;
    } else { // event to poll status of a target lineitem
      this.pollCurrentTaskStatus(e);
    }
  }

  onActionTaken(lineItem, activity?) {
    lineItem['approveStatus'] = 'Updating';
  }

  retrySubmission(lineItem, retry, targetStatus) {
    setTimeout(() => {
      if (lineItem.approveStatus === targetStatus || retry > 3) {
        /*if (this.toggleOptions.lineItem.approveStatus !== targetStatus) {
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error updating task status. Try again, or refresh the page.');
        }*/
        this.handleSubmission('submitted');
        return;
      }
      lineItem['approveStatus'] = 'Updating';
      //this.toggleOptions.commentsServiceInstance.getActivityEvents(this.toggleOptions.commentActivityId);
      this.handleSubmission({targetStatus: targetStatus, id: lineItem.id});
      this.retrySubmission(lineItem, retry + 1, targetStatus);
    }, 2000);
  }

  getSiteAndAppUpdatesActivity(lineItem: LineItem) {
    return _.find(lineItem.activities, {'typeId': 14 });
  }

  getQaApproveActivity(activity: Activity) {
    return _.find(activity.subActivities, {'typeId': 15 });
  }

  updateFilesMetadata(event, lineItem, activityType) {
    this.attachmentsStatus = event;
    if (activityType === 'SITE_AND_APP_UPDATES_ACTIVITY' && !event.uploadingInProgressQueue.length) {
      _.forEach(event.uploadedFileQueue, (uploadedFile) => {
        uploadedFile.source = 'S3';
        uploadedFile.activityId = this.getSiteAndAppUpdatesActivity(lineItem)['id'];
      });
      this.subscriptions.add(this.activitiesService.updateFilesMetadata(event.uploadedFileQueue).subscribe(
      (data) => {
        console.log('Successfully updated the metadata.');
        this.attachmentsStatus = [];
        if (this.detailsObj.lineItems[0].activities[0].input) {
          this.detailsObj.lineItems[0].activities[0].input.attachments = data;
        } else {
          this.detailsObj.lineItems[0].activities[0].input = { attachments: data};
        }
      }));
    }
  }

  setCommentsServiceInstanceObj(event) {
   this.commentServiceInstances[event.id] = event.serviceInstance;
  }

  ngOnDestroy() {
    if (this.dataSubscription) {
      this.dataSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
  }

}
