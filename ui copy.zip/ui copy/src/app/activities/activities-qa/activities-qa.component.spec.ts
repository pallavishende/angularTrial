import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesQaComponent } from './activities-qa.component';

xdescribe('ActivitiesQaComponent', () => {
  let component: ActivitiesQaComponent;
  let fixture: ComponentFixture<ActivitiesQaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesQaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesQaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
