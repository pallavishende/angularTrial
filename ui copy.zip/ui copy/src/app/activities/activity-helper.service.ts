import { Injectable } from '@angular/core';
import { LineItem } from '../models/line-item';
import { Activity } from '../models/activity';
import { UserService } from '../services/user.service';
import { NavigationService } from '../services/navigation.service';
import { OrdersService } from '../orders/orders/orders.service';

import * as _ from 'lodash';

@Injectable()
export class ActivityHelperService {
  showApprovalMessage: Boolean = false;
  subActivityStatuses = {
    NONE: 'NONE',
    TO_DO: 'TO_DO',
    WAITING: 'WAITING',
    REJECTED: 'REJECTED',
    COMPLETED: 'COMPLETED',
    APPROVED: 'APPROVED'
  };

  constructor(
    private userService: UserService,
    private ordersService: OrdersService,
    private navigationService: NavigationService
  ) { }

  getHeaderBundleInfo(metadata) {
    if (!metadata) {
      return '';
    }
    const contentType = metadata.contentType.toUpperCase();
    if (contentType === 'BRAND') {
      return metadata.name;
    } else if (contentType === 'SERIES' || contentType === 'SEASON' || contentType === 'SPECIAL' || contentType === 'MOVIE') {
      return metadata.title;
    } else if (contentType === 'EPISODE') {
      if (metadata.episodeNumber && metadata.title) {
        if (!metadata.seriesTitle) {
          return '#' + metadata.episodeNumber + ': ' + metadata.title; // only missing series title
        } else {
          return metadata.seriesTitle + ' #' + metadata.episodeNumber + ': ' + metadata.title; // standard
        }
      } else if (metadata.seriesTitle && metadata.episodeNumber) {
        return metadata.seriesTitle + ' #' + metadata.episodeNumber; // missing episode name
      } else if (metadata.seriesTitle && metadata.title) {
        return metadata.seriesTitle + ': ' + metadata.title; // missing episode number
      }
    }
    return '';
  }

  parentActivityStatus(lineItem: LineItem, type) {
    let localType = type;
    let tmp = _.find(lineItem.activities, function(activity) {
      return activity['typeId'] == localType;
    });
    return _.get(tmp, 'currentState.status');
  }

  getComposeActivityStatus(lineItem: LineItem) {
    const composeActivity = _.find(lineItem.activities, (activity) => activity.typeId === 1 || activity.typeId === 3 || activity.typeId === 5 || activity.typeId === 14);
    if (composeActivity) {
      return composeActivity.currentState['status'].toString();
    }
  }

  getApproveActivityStatus(lineItem: LineItem) {
    const composeActivity = _.find(lineItem.activities, (activity) => activity.typeId === 1 || activity.typeId === 3 || activity.typeId === 5 || activity.typeId === 14);
    let approveActivity;
    let statusObj = {
      status,
      showMsg: this.getComposeActivityStatus(lineItem) === 'TO_DO'
    };
    if (composeActivity && composeActivity.subActivities && composeActivity.subActivities.length > 0) {
      approveActivity = composeActivity.subActivities[0];
      statusObj.status = approveActivity.currentState['status'].toString();
      return statusObj;
    }
  }

  getPublishStatus(lineItem: LineItem) {
    return _.get(_.find(lineItem.activities, (activity: Activity) => {
      if (activity.typeId === 13) {
        return activity;
      }
     }), 'currentState.status').toString();
  }

  getVideoQaStatus(lineItem: LineItem) {
    return _.get(_.find(lineItem.activities, (activity: Activity) => {
      if (activity.typeId === 16) {
        return activity;
      }
     }), 'currentState.status').toString();
  }

  // this is a workaround right now
  canApprove(activityBundle, isVersionPublished) {
    if (!isVersionPublished) {
      return activityBundle['assignedUserEmail'] ===  this.userService.getUserLoginInfo().email;
    } else {
      return activityBundle['assignedUserEmail'] !== 'UNASSIGNED';
    }
  }

  orderInfo(orderId: number) {
    return this.ordersService.getOrder(orderId);
  }

  setActivityDetailsBackToNavigationRoute() {
    let url, name;
    url = this.navigationService.getActivityDetailsPreviousUrl();
    if (url === null) {
      url = this.navigationService.getActiveActivitiesTab();
    }
    // setting the page name
    url.startsWith('tasks', 1) ? name = 'Tasks' : name = 'Order';
    return { url, name };
  }

}
