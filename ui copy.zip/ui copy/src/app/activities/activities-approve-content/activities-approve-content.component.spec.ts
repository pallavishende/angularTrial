import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesApproveContentComponent } from './activities-approve-content.component';

xdescribe('ActivitiesApproveContentComponent', () => {
  let component: ActivitiesApproveContentComponent;
  let fixture: ComponentFixture<ActivitiesApproveContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesApproveContentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesApproveContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
