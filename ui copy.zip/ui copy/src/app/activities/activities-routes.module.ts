import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActivitiesBaseComponent } from './activities-base/activities-base.component';
import { SiteHeaderComponent } from '../shared/site-header/site-header.component';
import { ActivitiesViewComponent } from './activities-view/activities-view.component';
import { ActivitiesComponent } from './activities/activities.component';
import { ActivitiesComposeContentComponent } from './activities-compose-content/activities-compose-content.component';
import { ActivitiesApproveContentComponent } from './activities-approve-content/activities-approve-content.component';
import { ActivitiesComposeCopyComponent } from './activities-compose-copy/activities-compose-copy.component';
import { ActivitiesApproveCopyComponent } from './activities-approve-copy/activities-approve-copy.component';
import { ActivitiesCreateGraphicsComponent } from './activities-create-graphics/activities-create-graphics.component';
import { ActivitiesApproveGraphicsComponent } from './activities-approve-graphics/activities-approve-graphics.component';
import { ActivitiesPublishComponent } from './activities-publish/activities-publish.component';
import { ActivitiesSiteAndAppUpdatesComponent } from './activities-site-and-app-updates/activities-site-and-app-updates.component';
import { ActivitiesQaComponent } from './activities-qa/activities-qa.component';
import { ActivitiesVideoQaComponent } from './activities-video-qa/activities-video-qa.component';
import { ActivityListRouteGuard } from './route-guard/activity-list-route-guard';

const ActivityRoutes: Routes = [
  {
    path: '', component: ActivitiesBaseComponent, canActivate: [ ActivityListRouteGuard ], data: {title: 'Tasks'},
    children: [
      { path: '', component: SiteHeaderComponent, outlet: 'header' },
      { path: '', component: ActivitiesViewComponent,
         children: [
          { path: '', redirectTo: 'all-tasks', pathMatch: 'full' },
          { path: 'my-tasks', component: ActivitiesComponent},
          { path: 'my-teams-tasks', component: ActivitiesComponent},
          { path: 'all-tasks', component: ActivitiesComponent}
        ],
      },
    ],
  },
  { path: ':id/create-video', component: ActivitiesBaseComponent , data: {title: 'Create Video'},
    children: [
      { path: '', component: ActivitiesComposeContentComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  },
  { path: ':id/approve-video', component: ActivitiesBaseComponent , data: {title: 'Approve Video'},
    children: [
      { path: '', component: ActivitiesApproveContentComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  },
  { path: ':id/write-copy', component: ActivitiesBaseComponent , data: {title: 'Write Copy'},
    children: [
      { path: '', component: ActivitiesComposeCopyComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  },
  { path: ':id/edit-copy', component: ActivitiesBaseComponent , data: {title: 'Edit Copy'},
    children: [
      { path: '', component: ActivitiesApproveCopyComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  },
  { path: ':id/create-graphics', component: ActivitiesBaseComponent , data: {title: 'Create Graphics'},
    children: [
      { path: '', component: ActivitiesCreateGraphicsComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  },
  { path: ':id/approve-graphics', component: ActivitiesBaseComponent , data: {title: 'Approve Graphics'},
    children: [
      { path: '', component: ActivitiesApproveGraphicsComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  },
  { path: ':id/publish-video', component: ActivitiesBaseComponent , data: {title: 'Publish Video'},
    children: [
      { path: '', component: ActivitiesPublishComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  },
  { path: ':id/site-and-app-updates', component: ActivitiesBaseComponent , data: {title: 'Site & App Updates'},
    children: [
      { path: '', component: ActivitiesSiteAndAppUpdatesComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  },
  { path: ':id/qa-site-and-app-updates', component: ActivitiesBaseComponent , data: {title: 'QA - Site & App Updates'},
    children: [
      { path: '', component: ActivitiesQaComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  },
  { path: ':id/qa-video', component: ActivitiesBaseComponent , data: {title: 'QA - Video'},
    children: [
      { path: '', component: ActivitiesVideoQaComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(ActivityRoutes)],
  exports: [RouterModule]
})
export class ActivitiesRoutesModule { }
