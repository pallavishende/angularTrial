import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverTogglesComponent } from './approver-toggles.component';

xdescribe('ApproverTogglesComponent', () => {
  let component: ApproverTogglesComponent;
  let fixture: ComponentFixture<ApproverTogglesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproverTogglesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverTogglesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
