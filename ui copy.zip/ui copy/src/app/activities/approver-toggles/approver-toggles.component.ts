import { Component, OnInit, OnDestroy, Renderer2, Input, Output, EventEmitter, ViewChild } from '@angular/core';

import { ActivitiesService } from '../activities.service';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import * as _ from 'lodash';
import { UtilityService } from '../../services/utility.service';
import { UserService } from '../../services/user.service';
import 'rxjs/add/operator/mergeMap';
import { CustomEditorService } from '../../shared/custom-editor/custom-editor.service';
import { SystemAlertsService } from '../../services/system-alerts.service';

@Component({
  selector: 'app-approver-toggles',
  templateUrl: './approver-toggles.component.html',
  styleUrls: ['./approver-toggles.component.scss', '../activities.scss'],
  providers: [ CustomEditorService ]
})
export class ApproverTogglesComponent implements OnInit, OnDestroy {
  @Input() toggleOptions: any;
  @Input() title: any;

  @Output() onStatusChange = new EventEmitter<any>();
  @ViewChild('neutralRadio') neutralRadio;
  @ViewChild('approvedRadio') approvedRadio;
  @ViewChild('rejectedRadio') rejectedRadio;
  @ViewChild('submitRejectionBtn') submitRejectionBtn;

  commentsObservable: Observable<{}>;
  subscriptions = new Subscription();
  activityTypesList;
  orderType: string;
  activityRejectionObj;
  userComment: string;
  isValidDescription: boolean;
  originalState;
  toggleConfirmedState = '';
  initializeEditor: boolean;
  isComplete = false;

  activityStatuses = {
    TO_DO: 'TO_DO',
    WAITING: 'WAITING',
    COMPLETED: 'COMPLETED',
    REJECTED: 'REJECTED',
    APPROVED: 'APPROVED'
  };

  constructor(
    private renderer: Renderer2,
    private activitiesService: ActivitiesService,
    private userService: UserService,
    private utilityService: UtilityService,
    private customEditorService: CustomEditorService,
    private alerts: SystemAlertsService
  ) { }

  ngOnInit() {
    let internalToggle = {
      switchToggleRejected: false,
      switchToggleApproved: false,
      statusText: '',
      openModalType: '',
      isNeutral: false,
      status: this.activityStatuses.TO_DO,
      parentRejected: this.toggleOptions.activity.currentState.status === this.activityStatuses.REJECTED
    };
    if ( this.toggleOptions.activity ) {
      this.toggleOptions.activity['internalToggle'] = _.cloneDeep(internalToggle);
      let currentStatus = this.getToggleStatus(this.toggleOptions.activity);
      switch ( currentStatus ) {
        case this.activityStatuses.COMPLETED:
          this.switchToggleAccept(this.toggleOptions.activity);
          this.toggleConfirmedState = 'approved';
          break;
        case this.activityStatuses.REJECTED:
          this.switchToggleReject(this.toggleOptions.activity);
          this.toggleConfirmedState = 'rejected';
          break;
        case this.activityStatuses.TO_DO:
          this.switchToggleNeutral(this.toggleOptions.activity);
          this.toggleConfirmedState = '';
          break;
      }
    }
    this.originalState = this.toggleOptions;
    this.activityTypesList = this.utilityService.getActivityTypesList();
    if (this.toggleOptions.activity.typeId === 10) {
      this.orderType = 'copy';
    } else if (this.toggleOptions.activity.typeId === 11) {
      this.orderType = 'graphics';
    } else if (this.toggleOptions.activity.typeId === 15) {
      this.orderType = 'siteAndAppUpdates';
    } else {
      this.orderType = 'video';
    }
  }

  isActionDisabled() {
    return (this.toggleOptions.activity.internalToggle.status === this.activityStatuses.WAITING) ||
           (this.toggleOptions.activity.internalToggle.status === this.activityStatuses.COMPLETED) ||
           (this.toggleOptions.activity.internalToggle.status === 'Updating') ||
           (this.toggleOptions.activity.internalToggle.statusText === 'submitting...') ||
           this.toggleOptions.isVersionPublished;
  }

  getToggleStatus(activity) {
    let s = '';
    if ( activity.currentState.status === 'TO_DO' ) {
      s = 'TO_DO';
    }
    if ( activity.currentState.status === 'REJECTED' || activity.currentState.status === 'WAITING') {
      s = 'REJECTED';
    }
    if ( activity.currentState.status === 'APPROVED' || activity.currentState.status === 'COMPLETED' ) {
      s = 'COMPLETED';
    }
    return s;
  };

  submitApproval(activity, isApproved?: any) {
    // block api call for reapproving an approved subtask
    if (isApproved) {
      return;
    }
    this.toggleOptions.activity.internalToggle.statusText = 'approved';

    const submissionPayload = {
      activityId: activity.id,
      subActivityId: this.toggleOptions.subActivity.id,
      orderId: this.toggleOptions.orderId,
      lineItem: this.toggleOptions.lineItem,
      status: this.activityStatuses.APPROVED,
      message: this.userComment,
      createdByEmail: this.userService.getUserLoginInfo().email
    };

    this.onStatusChange.emit(submissionPayload);
  }

  rejectActivity(activity) {
    const mentionsEmails = [];
    this.activityRejectionObj.mentionedUsers.forEach((element) => {
      mentionsEmails.push(element.email);
    });
    this.toggleOptions.activity.internalToggle.statusText = 'rejected';
    const submissionPayload = {
     activityId: activity.id,
     subActivityId: this.toggleOptions.subActivity.id,
     activityIdForEvent: this.toggleOptions.commentActivityId,
     status: this.activityStatuses.REJECTED,
     lineItem: this.toggleOptions.lineItem,
     message: this.userComment,
     mentionedUserEmails: mentionsEmails,
     createdByEmail: this.userService.getUserLoginInfo().email
   };
    this.onStatusChange.emit(submissionPayload);
  }

  resetToOriginalState(activity) {
    if ( this.toggleConfirmedState === '' ) {
      this.switchToggleNeutral(activity);
    }
    if ( this.toggleConfirmedState === 'approved' ) {
      this.switchToggleAccept(activity);
    }
    if ( this.toggleConfirmedState === 'rejected' ) {
      this.switchToggleReject(activity);
    }
  }

  switchToggleReject(activity) {
    activity.internalToggle.status = this.activityStatuses.WAITING;
    activity.internalToggle.switchToggleRejected =  true;
    activity.internalToggle.switchToggleApproved =  false;
    activity.internalToggle.statusText = 'rejected';
  }

  switchToggleAccept(activity) {
    activity.internalToggle.status = this.activityStatuses.COMPLETED;
    activity.internalToggle.switchToggleRejected =  false;
    activity.internalToggle.switchToggleApproved =  true;
    activity.internalToggle.statusText = 'approved';
  }

  switchToggleNeutral(activity) {
    if (this.toggleConfirmedState === 'approved' || this.toggleConfirmedState === 'rejected') {
      return;
    }
    activity.internalToggle.status = this.activityStatuses.TO_DO;
    activity.internalToggle.switchToggleRejected =  false;
    activity.internalToggle.switchToggleApproved =  false;
    activity.internalToggle.statusText = '';
  }

  onOpen() {
    setTimeout(() => {
      this.initializeEditor = true;
    });
  }

  onClose() {
    this.initializeEditor = false;
  }

  getCommentFromEditor() {
    this.customEditorService.getCommentFromEditor.emit();
    console.log('fetching comment..:');
  }

  contentChanged(event) {
    this.activityRejectionObj = event;
    if (event.isValidContent) {
      this.renderer.addClass(this.submitRejectionBtn.nativeElement, 'ready');
      this.isValidDescription = true;
      this.userComment = event.content;
    } else {
      if (this.userComment) {
        this.userComment = event.content;
      }
      this.renderer.removeClass(this.submitRejectionBtn.nativeElement, 'ready');
      this.isValidDescription = false;
    }
    if (this.isValidDescription && event.readyToPostComment) {
      this.rejectActivity(this.toggleOptions.activity);
    }
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
