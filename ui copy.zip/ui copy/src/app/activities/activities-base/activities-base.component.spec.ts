import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesBaseComponent } from './activities-base.component';

describe('ActivitiesBaseComponent', () => {
  let component: ActivitiesBaseComponent;
  let fixture: ComponentFixture<ActivitiesBaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesBaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
