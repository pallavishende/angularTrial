import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { HttpHeaders } from '@angular/common/http';
import { Title } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import { ConfigService } from '../services/config.service';
import { HttpClient } from '@angular/common/http';
import { UtilityService } from '../services/utility.service';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import * as _ from 'lodash';

@Injectable()
export class ActivitiesService {

  constructor(
    private title: Title,
    private configService: ConfigService,
    private authHttp: HttpClient,
    private utilityService: UtilityService
  ) { }

  submitApprovalActivity(subUrl, activityId, approvePayload) {
    return this.authHttp.put(this.configService.activityUrl + activityId + subUrl, approvePayload)
      .map((response: any) => response);
  }

  getFilters(query?: string) {
    if (query) {
      return this.authHttp.get(this.configService.activitiesFiltersUrl + query)
      .map((response: any) => response);
    } else {
      return this.authHttp.get(this.configService.activitiesFiltersUrl)
      .map((response: any) => response);
    }
  }

  getActivities(page, filterString?, pageSize?) {
    let size: number;
    if (!pageSize) {
      if (page === 0) {
        size = 50;
      } else {
        size = 25;
      }
    } else {
      page = 0;
      size = pageSize;
    }

    if (filterString) {
      return this.authHttp.get(this.configService.activitiesUrl + '?' + filterString + '&size=' + size + '&page=' + page + '&sort=lastModifiedDate,desc')
        .map((response: any) => response);
    } else {
      return this.authHttp.get(this.configService.activitiesUrl + '?size=' + size + '&page=' + page + '&sort=lastModifiedDate,desc')
        .map((response: any) => response);
    }
  }

  getActivityDetail(id) {
    return this.authHttp.get(this.configService.activityDetailUrl + id)
      .map((response: any) => response);
  }

  getCopyOrderInfo(vmid: string) {
    return this.authHttp.get(this.configService.publishCopyOrdersUrl + vmid)
      .map((response: any) => response);
  }


  getActivityEvents(activityId: number) {
    return this.authHttp.get(this.configService.activityUrl + activityId + '/events')
      .map((response: any) => response);
  }

  filterActivities(filterString, page) {
    let size: number;
    if (page === 0) {
      size = 50;
    } else {
      size = 25;
    }
    if (filterString) {
      return this.authHttp.get(this.configService.activitiesUrl + '?' + filterString + '&size=' + size + '&page=' + page + '&sort=lastModifiedDate,desc')
        .map((response: any) => response);
    } else {
      return this.authHttp.get(this.configService.activitiesUrl + '?size=' + size + '&page=' + page + '&sort=lastModifiedDate,desc')
        .map((response: any) => response);
    }
  }

  bulkAssignActivity(assigneeId, bulkArr, assignedByEmail, isTeamAssignment?: boolean) {
    const header = new Headers();
    const activityIds = _.map(bulkArr, 'id');
    const payload = {
      'groupedActivityIds': activityIds,
      'assignedByEmail': assignedByEmail,
      ...!isTeamAssignment && { 'userEmail': assigneeId },
      ...isTeamAssignment && { 'teamId': assigneeId }
    };
    header.append(`Content-type`, `application/json`);
    return this.authHttp.put(this.configService.assignActivitiesUrl, payload)
      .map((response: any) => response);
  }

  startWork(payload) {
    const header = new Headers();
    header.append(`Content-type`, `application/json`);
    return this.authHttp.put(this.configService.startWorkUrl, payload)
      .map((response: any) => response);
  }

  toggleTask(payload) {
    return this.authHttp.put(this.configService.reopenTaskUrl + payload.orderId, payload)
      .map((response: any) => response);
  }

  assignActivity(payload) {
    const header = new Headers();
    const newPayload = {
      'groupedActivityIds': [payload.id],
      'userEmail': payload.assigneeEmail,
      'teamId': payload.teamId,
      'assignedByEmail': payload.assignedByEmail
    };
    header.append(`Content-type`, `application/json`);
    return this.authHttp.put(this.configService.assignActivitiesUrl, newPayload)
      .map((response: any) => response);
  }

  unassignActivity(payload, unassignQty) {
    const header = new Headers();
    let newPayload = {};
    if (unassignQty === 'bulk') {
      const activityIds = _.map(payload, 'id');
      newPayload = {
        'groupedActivityIds': activityIds,
        'userEmail': '',
        'teamId': ''
      };
    } else {
      newPayload = {
        'groupedActivityIds': [payload.id],
        'userEmail': '',
        'teamId': ''
      };
    }

    header.append(`Content-type`, `application/json`);
    return this.authHttp.put(this.configService.unassignActivitiesUrl, newPayload)
      .map((response: any) => response);
  }

  postComment(commentObj, isChildEvent?) {
    let header = new Headers();
    header.append(`Content-type`, `application/json`);
    let payload = {
      message: commentObj.body,
      createdByEmail: commentObj.createdByEmail,
      mentionedUserEmails: commentObj.mentionedUserEmails,
      isChildEvent: isChildEvent
    };
    const activityId = commentObj.activityId;
    return this.authHttp.post(this.configService.activityUrl + activityId + '/comments', payload);
  }

  deleteComment(commentId: string) {
    return this.authHttp.delete(`${this.configService.activityUrl}/${commentId}/comments`);
  }

  submitActivityForApproval(submissionPayload) {
    const header = new Headers();
    header.append(`Content-type`, `application/json`);
    return this.authHttp.put(this.configService.activityUrl + 'submit_for_approval', submissionPayload);
  }

  markAsPublished(publishActivityPayload) {
    const activityId = publishActivityPayload.activityId;
    const header = new Headers();
    delete publishActivityPayload.activityId;
    header.append(`Content-type`, `application/json`);
    return this.authHttp.put(this.configService.activityUrl +
      activityId + '/mark-as-published', publishActivityPayload);
  }

  updateFilesMetadata(filesMetadata) {
    const headers = new HttpHeaders();
    const payload = filesMetadata;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };
    headers.append('Content-type', 'application/json');
    return this.authHttp.post(`${this.configService.fileHandlerUrl}-metadata`, payload).retryWhen(error => {
      return error.flatMap((error) => {
        return Observable.of(error.status).delay(200);
      }).take(5).concat(Observable.throw({error: 'Couldn\'t update the metadata'}));
    });
  }

  getAssetRestorationInfo(lineItemId: number) {
    return this.authHttp.get(this.configService.assetRestorationUrl + lineItemId + '/asset-restoration-progress')
      .map((response: any) => response);
  }

  setActivitiesPageTitle(title: string) {
    this.title.setTitle(title);
  }

  getContentDetails(metadata) {
    const contentMetadata = {};
    contentMetadata['originBrandName'] = metadata['brandTitle'];
    contentMetadata['seriesTitle'] = metadata['orderSeries'];
    contentMetadata['seasonTitle'] = metadata['seasonTitle'];
    contentMetadata['episodeNumber'] = metadata['orderEpisode'];
    contentMetadata['title'] = metadata['episodeTitle'];
    contentMetadata['movieAndSpecial'] = metadata['movieAndSpecialTitle'];
    return this.utilityService.getHeaderForContentType(contentMetadata, metadata['contentType']);
  }
}
