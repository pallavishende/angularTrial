import { BridgeUiPage } from './app.po';

describe('bridge-ui App', () => {
  let page: BridgeUiPage;

  beforeEach(() => {
    page = new BridgeUiPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
